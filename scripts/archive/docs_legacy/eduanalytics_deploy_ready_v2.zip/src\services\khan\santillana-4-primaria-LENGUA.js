// CONTENIDO SANTILLANA 4º PRIMARIA - LENGUA CASTELLANA
// Basado en el temario típico de Santillana
// Creado para niños de 9 años

export const SANTILLANA_LENGUA_4 = {
    'Lengua Castellana': {
        'Palabras Agudas, Llanas y Esdrújulas': {
            source: 'Santillana 4º Primaria - Ortografía',
            nivel: '4º Primaria',
            ejercicios: [
                { tipo: 'Concepto agudas', ejercicio: '¿Qué son las palabras agudas?', respuesta: 'Palabras que tienen la sílaba tónica en la última sílaba', explicacion: 'Aguda = acento al final. Ejemplo: café, reloj' },
                { tipo: 'Tilde aguda', ejercicio: '¿Cuándo llevan tilde las palabras agudas?', respuesta: 'Cuando terminan en n, s o vocal', explicacion: 'Ejemplos: león, compás, café' },
                { tipo: 'Identificar aguda', ejercicio: '¿Es aguda la palabra "ratón"?', respuesta: 'Sí', explicacion: 'Ra-TÓN: el acento está en la última sílaba' },
                { tipo: 'Concepto llanas', ejercicio: '¿Qué son las palabras llanas?', respuesta: 'Palabras que tienen la sílaba tónica en la penúltima sílaba', explicacion: 'Llana = acento en penúltima. Ejemplo: casa, árbol' },
                { tipo: 'Tilde llana', ejercicio: '¿Cuándo llevan tilde las palabras llanas?', respuesta: 'Cuando NO terminan en n, s o vocal', explicacion: 'Ejemplos: árbol, lápiz, fácil' },
                { tipo: 'Identificar llana', ejercicio: '¿Es llana la palabra "mesa"?', respuesta: 'Sí', explicacion: 'ME-sa: el acento está en la penúltima sílaba' },
                { tipo: 'Concepto esdrújulas', ejercicio: '¿Qué son las palabras esdrújulas?', respuesta: 'Palabras que tienen la sílaba tónica en la antepenúltima', explicacion: 'Esdrújula = acento antes de penúltima. Ejemplo: músico' },
                { tipo: 'Tilde esdrújula', ejercicio: '¿Cuándo llevan tilde las palabras esdrújulas?', respuesta: 'Siempre', explicacion: 'TODAS las esdrújulas llevan tilde: pájaro, médico' },
                { tipo: 'Clasificar 1', ejercicio: 'Clasifica "pájaro"', respuesta: 'Esdrújula', explicacion: 'PÁ-ja-ro: acento en antepenúltima, siempre lleva tilde' },
                { tipo: 'Clasificar 2', ejercicio: 'Clasifica "canción"', respuesta: 'Aguda', explicacion: 'Can-CIÓN: acento en última, termina en n' },
                { tipo: 'Añadir tildes', ejercicio: 'Añade la tilde si hace falta: "lapiz"', respuesta: 'lápiz', explicacion: 'Llana terminada en z, lleva tilde' },
                { tipo: 'Desafío', ejercicio: 'Escribe 3 palabras agudas con tilde', respuesta: 'Ejemplos: león, compás, café', explicacion: 'Agudas terminadas en n, s o vocal' }
            ]
        },

        'El Verbo - Tiempos Verbales': {
            source: 'Santillana 4º Primaria - Gramática',
            nivel: '4º Primaria',
            ejercicios: [
                { tipo: 'Concepto verbo', ejercicio: '¿Qué es un verbo?', respuesta: 'Palabra que indica acción o estado', explicacion: 'Verbos: correr, saltar, ser, estar' },
                { tipo: 'Presente', ejercicio: 'En "Yo como manzanas", ¿en qué tiempo está el verbo?', respuesta: 'Presente', explicacion: 'Está sucediendo ahora' },
                { tipo: 'Pasado', ejercicio: 'En "Ayer jugué al fútbol", ¿en qué tiempo está el verbo?', respuesta: 'Pasado (pretérito)', explicacion: 'Ya sucedió (ayer)' },
                { tipo: 'Futuro', ejercicio: 'En "Mañana iré al parque", ¿en qué tiempo está el verbo?', respuesta: 'Futuro', explicacion: 'Todavía no ha sucedido (mañana)' },
                { tipo: 'Conjugar presente', ejercicio: 'Completa: Yo ____ (comer) una manzana', respuesta: 'como', explicacion: 'Presente: yo como' },
                { tipo: 'Conjugar pasado', ejercicio: 'Completa: Ayer yo ____ (comer) una manzana', respuesta: 'comí', explicacion: 'Pasado: yo comí' },
                { tipo: 'Conjugar futuro', ejercicio: 'Completa: Mañana yo ____ (comer) una manzana', respuesta: 'comeré', explicacion: 'Futuro: yo comeré' },
                { tipo: 'Identificar', ejercicio: '¿Cuál es el verbo en "María estudia mucho"?', respuesta: 'estudia', explicacion: 'Estudia es la acción que realiza María' },
                { tipo: 'Infinitivo', ejercicio: '¿Cuál es el infinitivo de "corremos"?', respuesta: 'correr', explicacion: 'El infinitivo es la forma sin conjugar' },
                { tipo: 'Persona', ejercicio: 'En "Nosotros jugamos", ¿qué persona es?', respuesta: 'Primera persona del plural', explicacion: 'Nosotros = 1ª persona plural' },
                { tipo: 'Cambiar tiempo', ejercicio: 'Cambia a futuro: "Hoy juego al fútbol"', respuesta: 'Mañana jugaré al fútbol', explicacion: 'Juego (presente) → jugaré (futuro)' },
                { tipo: 'Problema', ejercicio: '¿Qué tienen en común: cantar, comer, vivir?', respuesta: 'Son verbos en infinitivo', explicacion: 'Todos terminan en -ar, -er, -ir' }
            ]
        },

        'Sustantivos y Adjetivos': {
            source: 'Santillana 4º Primaria - Gramática',
            nivel: '4º Primaria',
            ejercicios: [
                { tipo: 'Concepto sustantivo', ejercicio: '¿Qué es un sustantivo?', respuesta: 'Palabra que nombra personas, animales, cosas o lugares', explicacion: 'Ejemplos: niño, perro, mesa, Madrid' },
                { tipo: 'Concepto adjetivo', ejercicio: '¿Qué es un adjetivo?', respuesta: 'Palabra que describe cómo es un sustantivo', explicacion: 'Ejemplos: grande, bonito, rápido' },
                { tipo: 'Identificar sustantivo', ejercicio: 'En "El perro grande", ¿cuál es el sustantivo?', respuesta: 'perro', explicacion: 'Perro es el nombre del animal' },
                { tipo: 'Identificar adjetivo', ejercicio: 'En "El perro grande", ¿cuál es el adjetivo?', respuesta: 'grande', explicacion: 'Grande describe cómo es el perro' },
                { tipo: 'Género', ejercicio: '¿Es masculino o femenino "la casa"?', respuesta: 'Femenino', explicacion: 'Lleva el artículo "la"' },
                { tipo: 'Número', ejercicio: '¿Es singular o plural "los niños"?', respuesta: 'Plural', explicacion: 'Hay más de uno (niños)' },
                { tipo: 'Concordancia', ejercicio: 'Completa: "La niña ____" (alto/alta)', respuesta: 'alta', explicacion: 'Femenino singular: la niña alta' },
                { tipo: 'Tipos de sustantivo', ejercicio: '¿"Madrid" es sustantivo común o propio?', respuesta: 'Sustantivo propio', explicacion: 'Madrid va con mayúscula, es nombre propio' },
                { tipo: 'Añadir adjetivo', ejercicio: 'Añade un adjetivo: "El gato ____"', respuesta: 'Ejemplos: negro, pequeño, bonito', explicacion: 'Cualquier adjetivo que describa al gato' },
                { tipo: 'Plural', ejercicio: '¿Cuál es el plural de "pez"?', respuesta: 'peces', explicacion: 'Pez → peces (cambia z por c)' },
                { tipo: 'Femenino', ejercicio: '¿Cuál es el femenino de "gato"?', respuesta: 'gata', explicacion: 'Gato (masculino) → gata (femenino)' },
                { tipo: 'Desafío', ejercicio: 'En "Los libros interesantes", identifica sustantivo y adjetivo', respuesta: 'Sustantivo: libros, Adjetivo: interesantes', explicacion: 'Libros = cosa, interesantes = cómo son' }
            ]
        },

        'La Oración Simple': {
            source: 'Santillana 4º Primaria - Gramática',
            nivel: '4º Primaria',
            ejercicios: [
                { tipo: 'Concepto', ejercicio: '¿Qué es una oración?', respuesta: 'Conjunto de palabras con sentido completo', explicacion: 'Empieza con mayúscula y termina en punto' },
                { tipo: 'Sujeto', ejercicio: '¿Qué es el sujeto de una oración?', respuesta: 'Quién realiza la acción', explicacion: 'Ejemplo: "El niño corre" → sujeto: el niño' },
                { tipo: 'Predicado', ejercicio: '¿Qué es el predicado?', respuesta: 'Lo que se dice del sujeto', explicacion: 'Ejemplo: "El niño corre" → predicado: corre' },
                { tipo: 'Identificar sujeto', ejercicio: 'En "María estudia mucho", ¿quién es el sujeto?', respuesta: 'María', explicacion: 'María es quien realiza la acción (estudiar)' },
                { tipo: 'Identificar predicado', ejercicio: 'En "María estudia mucho", ¿cuál es el predicado?', respuesta: 'estudia mucho', explicacion: 'Es lo que se dice de María' },
                { tipo: 'Núcleo del sujeto', ejercicio: 'En "El perro grande", ¿cuál es el núcleo del sujeto?', respuesta: 'perro', explicacion: 'Perro es la palabra principal del sujeto' },
                { tipo: 'Núcleo del predicado', ejercicio: 'En "corre rápidamente", ¿cuál es el núcleo del predicado?', respuesta: 'corre', explicacion: 'Corre es el verbo, núcleo del predicado' },
                { tipo: 'Completar', ejercicio: 'Completa la oración: "Los niños ____ en el parque"', respuesta: 'Ejemplos: juegan, corren, están', explicacion: 'Necesita un verbo' },
                { tipo: 'Separar', ejercicio: 'Separa sujeto y predicado: "El gato duerme en el sofá"', respuesta: 'Sujeto: El gato / Predicado: duerme en el sofá', explicacion: '¿Quién? El gato. ¿Qué hace? duerme en el sofá' },
                { tipo: 'Crear oración', ejercicio: 'Crea una oración con: perro - ladra', respuesta: 'Ejemplo: El perro ladra fuerte', explicacion: 'Sujeto (perro) + predicado (ladra)' },
                { tipo: 'Tipos', ejercicio: '¿Qué tipo de oración es "¿Cómo te llamas?"?', respuesta: 'Interrogativa', explicacion: 'Hace una pregunta, lleva ¿?' },
                { tipo: 'Desafío', ejercicio: 'Inventa una oración con sujeto y predicado sobre el cole', respuesta: 'Ejemplo: Los profesores enseñan bien', explicacion: 'Sujeto: los profesores, Predicado: enseñan bien' }
            ]
        },

        'Tipos de Texto': {
            source: 'Santillana 4º Primaria - Comprensión',
            nivel: '4º Primaria',
            ejercicios: [
                { tipo: 'Texto narrativo', ejercicio: '¿Qué es un texto narrativo?', respuesta: 'Texto que cuenta una historia', explicacion: 'Ejemplo: cuentos, novelas' },
                { tipo: 'Texto descriptivo', ejercicio: '¿Qué es un texto descriptivo?', respuesta: 'Texto que describe cómo es algo o alguien', explicacion: 'Dice características: alto, rubio, grande' },
                { tipo: 'Texto instructivo', ejercicio: '¿Qué es un texto instructivo?', respuesta: 'Texto que da instrucciones o explica cómo hacer algo', explicacion: 'Ejemplo: recetas, manuales' },
                { tipo: 'Texto informativo', ejercicio: '¿Qué es un texto informativo?', respuesta: 'Texto que da información sobre un tema', explicacion: 'Ejemplo: noticias, artículos' },
                { tipo: 'Identificar 1', ejercicio: 'Una receta de cocina es un texto...', respuesta: 'Instructivo', explicacion: 'Da pasos para cocinar algo' },
                { tipo: 'Identificar 2', ejercicio: 'Un cuento es un texto...', respuesta: 'Narrativo', explicacion: 'Cuenta una historia' },
                { tipo: 'Identificar 3', ejercicio: 'Una noticia del periódico es un texto...', respuesta: 'Informativo', explicacion: 'Informa sobre algo que pasó' },
                { tipo: 'Partes narrativo', ejercicio: '¿Cuáles son las partes de un cuento?', respuesta: 'Inicio, nudo (desarrollo) y desenlace (final)', explicacion: 'Empieza, pasan cosas, termina' },
                { tipo: 'Características', ejercicio: '¿Los textos instructivos usan verbos en imperativo (haz, mezcla, corta)?', respuesta: 'Sí', explicacion: 'Dan órdenes: añade, bate, hornea' },
                { tipo: 'Ejemplo', ejercicio: 'Da un ejemplo de texto descriptivo', respuesta: 'Ejemplo: descripción de una persona o lugar', explicacion: 'Mi casa es grande, tiene 3 habitaciones...' },
                { tipo: 'Crear', ejercicio: 'Escribe el inicio de un cuento', respuesta: 'Ejemplo: Había una vez un niño que...', explicacion: 'Los cuentos suelen empezar así' },
                { tipo: 'Desafío', ejercicio: '¿Qué tipo de texto es una carta a un amigo?', respuesta: 'Texto personal/epistolar', explicacion: 'Las cartas son un tipo especial de texto' }
            ]
        }
    }
};

export default { SANTILLANA_LENGUA_4 };
