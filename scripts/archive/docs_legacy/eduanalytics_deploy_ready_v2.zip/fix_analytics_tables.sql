-- TABLAS DE ANALÍTICA AVANZADA
-- ⚠️ Ejecuta esto en el SQL Editor de Supabase

-- 1. Tabla de Sesiones de Evaluación (Resumen por ficha)
CREATE TABLE IF NOT EXISTS public.resultados_evaluacion (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    student_id UUID REFERENCES public.students(id) ON DELETE CASCADE,
    subject_name TEXT NOT NULL,
    topic TEXT,
    score DECIMAL(5,2), -- Puntuación de 0 a 10
    total_questions INTEGER,
    correct_questions INTEGER,
    time_spent_seconds INTEGER,
    perfil_cognitivo_id TEXT, -- ID del perfil detectado (working_memory, etc)
    created_at TIMESTAMPTZ DEFAULT NOW()
);

-- 2. Tabla de Detalle por Pregunta (Para analítica granular)
CREATE TABLE IF NOT EXISTS public.evaluacion_detallada (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    resultado_id UUID REFERENCES public.resultados_evaluacion(id) ON DELETE CASCADE,
    student_id UUID REFERENCES public.students(id) ON DELETE CASCADE,
    question_id TEXT,
    criterio_evaluacion TEXT,
    competencias TEXT[],
    es_correcto BOOLEAN,
    respuesta_estudiante TEXT,
    respuesta_correcta TEXT,
    feedback_ia TEXT,
    tiempo_respuesta_segundos INTEGER,
    created_at TIMESTAMPTZ DEFAULT NOW()
);

-- 3. Habilitar RLS
ALTER TABLE public.resultados_evaluacion ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.evaluacion_detallada ENABLE ROW LEVEL SECURITY;

-- 4. Políticas RLS
DROP POLICY IF EXISTS "Parents can view their children's results" ON public.resultados_evaluacion;
CREATE POLICY "Parents can view their children's results" ON public.resultados_evaluacion
    FOR SELECT USING (
        student_id IN (SELECT id FROM public.students WHERE parent_id = auth.uid())
    );

DROP POLICY IF EXISTS "Parents can insert results" ON public.resultados_evaluacion;
CREATE POLICY "Parents can insert results" ON public.resultados_evaluacion
    FOR INSERT WITH CHECK (
        student_id IN (SELECT id FROM public.students WHERE parent_id = auth.uid())
    );

DROP POLICY IF EXISTS "Parents can view detailed results" ON public.evaluacion_detallada;
CREATE POLICY "Parents can view detailed results" ON public.evaluacion_detallada
    FOR SELECT USING (
        student_id IN (SELECT id FROM public.students WHERE parent_id = auth.uid())
    );

DROP POLICY IF EXISTS "Parents can insert detailed results" ON public.evaluacion_detallada;
CREATE POLICY "Parents can insert detailed results" ON public.evaluacion_detallada
    FOR INSERT WITH CHECK (
        student_id IN (SELECT id FROM public.students WHERE parent_id = auth.uid())
    );

-- Índices
CREATE INDEX IF NOT EXISTS idx_resultados_student ON public.resultados_evaluacion(student_id);
CREATE INDEX IF NOT EXISTS idx_detallada_resultado ON public.evaluacion_detallada(resultado_id);
