// GENERADOR DE FICHAS PERSONALIZADAS
// Crea fichas enfocadas basadas en el análisis histórico del estudiante

import { analizarTendencias } from './analisis-historico-service';
import { PATRONES_ERROR_TIER1, obtenerCriterioLOMLOE } from './taxonomia-errores-avanzada';
import { obtenerPreguntasPorTema } from './banco-preguntas';

/**
 * Generar ficha personalizada basada en historial del estudiante
 */
export async function generarFichaPersonalizada(historial, configuracion = {}) {
    const {
        asignatura,
        tema,
        curso = '4º Primaria',
        numPreguntas = 10
    } = configuracion;

    // Analizar historial
    const analisis = analizarTendencias(historial);

    if (!analisis.hayDatos) {
        // Sin historial, generar ficha normal
        return await generarFichaNormal(asignatura, tema, curso, numPreguntas);
    }

    // Identificar área de enfoque
    const enfoque = identificarEnfoque(analisis);

    // Generar ficha según el enfoque
    const ficha = await generarFichaEnfocada(enfoque, asignatura, tema, curso, numPreguntas);

    return ficha;
}

/**
 * Identificar en qué debe enfocarse la ficha
 */
function identificarEnfoque(analisis) {
    const enfoque = {
        tipo: 'general',
        patronPrincipal: null,
        criteriosProblematicos: [],
        dificultadSugerida: 'media',
        prioridad: 'MEDIA',
        razon: ''
    };

    // 1. Verificar alertas críticas
    const alertasCriticas = analisis.alertas.filter(a => a.gravedad === 'ALTA');
    if (alertasCriticas.length > 0) {
        enfoque.prioridad = 'ALTA';
    }

    // 2. Identificar patrón de error dominante
    if (analisis.patronesRecurrentes.length > 0) {
        const patronDominante = analisis.patronesRecurrentes[0];
        enfoque.patronPrincipal = patronDominante.patron;
        enfoque.tipo = 'patron_especifico';
        enfoque.razon = `Refuerzo de ${patronDominante.info.nombre} (aparece en ${patronDominante.frecuencia}% de evaluaciones)`;

        // Ajustar dificultad según el patrón
        if (patronDominante.patron === 'EC') {
            // Error conceptual → Empezar desde lo básico
            enfoque.dificultadSugerida = 'facil';
        } else if (patronDominante.patron === 'EP') {
            // Error procedimental → Nivel medio con guía
            enfoque.dificultadSugerida = 'media';
        } else if (patronDominante.patron === 'EAC') {
            // Error de aplicación → Casos prácticos variados
            enfoque.dificultadSugerida = 'media';
        }
    }

    // 3. Criterios LOMLOE problemáticos
    if (analisis.criteriosProblematicos.length > 0) {
        enfoque.criteriosProblematicos = analisis.criteriosProblematicos.map(c => c.codigo);
        if (enfoque.tipo === 'general') {
            enfoque.tipo = 'criterio_especifico';
            enfoque.razon = `Refuerzo de criterios LOMLOE: ${enfoque.criteriosProblematicos.join(', ')}`;
        }
    }

    // 4. Ajustar según tendencia
    if (analisis.tendenciaGeneral.tipo === 'empeorando' ||
        analisis.tendenciaGeneral.tipo === 'empeorando_rapido') {
        enfoque.dificultadSugerida = 'facil';
        enfoque.prioridad = 'ALTA';
        if (!enfoque.razon) {
            enfoque.razon = 'Refuerzo básico por tendencia negativa';
        }
    }

    // 5. Si va bien, aumentar desafío
    if (analisis.evolucionPuntuacion.promedio >= 85 &&
        analisis.tendenciaGeneral.tipo.includes('mejorando')) {
        enfoque.dificultadSugerida = 'dificil';
        enfoque.tipo = 'desafio';
        enfoque.razon = 'Desafío avanzado por excelente rendimiento';
    }

    return enfoque;
}

/**
 * Generar ficha enfocada según el análisis
 */
async function generarFichaEnfocada(enfoque, asignatura, tema, curso, numPreguntas) {
    // Obtener preguntas del banco
    let preguntas = await obtenerPreguntasPorTema(asignatura, tema, numPreguntas * 3, curso);

    // Filtrar y seleccionar preguntas según el enfoque
    let preguntasSeleccionadas = [];

    if (enfoque.tipo === 'patron_especifico') {
        preguntasSeleccionadas = seleccionarPorPatron(
            preguntas,
            enfoque.patronPrincipal,
            enfoque.dificultadSugerida,
            numPreguntas
        );
    } else if (enfoque.tipo === 'criterio_especifico') {
        preguntasSeleccionadas = seleccionarPorCriterio(
            preguntas,
            enfoque.criteriosProblematicos,
            enfoque.dificultadSugerida,
            numPreguntas
        );
    } else if (enfoque.tipo === 'desafio') {
        preguntasSeleccionadas = seleccionarDesafio(
            preguntas,
            numPreguntas
        );
    } else {
        // General: mezcla equilibrada con dificultad preferida
        preguntasSeleccionadas = seleccionarEquilibrada(
            preguntas,
            enfoque.dificultadSugerida,
            numPreguntas
        );
    }

    return {
        titulo: generarTitulo(enfoque, asignatura, tema),
        descripcion: generarDescripcion(enfoque),
        preguntas: preguntasSeleccionadas.slice(0, numPreguntas),
        enfoque,
        metadata: {
            asignatura,
            tema,
            curso,
            personalizada: true,
            patronEnfoque: enfoque.patronPrincipal,
            dificultad: enfoque.dificultadSugerida,
            prioridad: enfoque.prioridad,
            fechaGeneracion: new Date().toISOString()
        }
    };
}

/**
 * Seleccionar preguntas específicas para un patrón de error
 */
function seleccionarPorPatron(preguntas, patron, dificultad, cantidad) {
    const patronInfo = PATRONES_ERROR_TIER1[patron];

    // Estrategia según patrón
    let preguntasFiltradas = [...preguntas];

    if (patron === 'EC') {
        // Error Conceptual → Preguntas de definición y comprensión
        preguntasFiltradas = preguntas.filter(p =>
            p.tipo === 'definition' ||
            p.tipo === 'short_answer' ||
            p.pregunta?.toLowerCase().includes('qué es') ||
            p.pregunta?.toLowerCase().includes('define') ||
            p.pregunta?.toLowerCase().includes('explica')
        );
        // Priorizar nivel Bloom: RECORDAR y COMPRENDER
        preguntasFiltradas.sort((a, b) => {
            const ordenBloom = { 'RECORDAR': 0, 'COMPRENDER': 1, 'APLICAR': 2 };
            return (ordenBloom[a.nivelBloom] || 5) - (ordenBloom[b.nivelBloom] || 5);
        });
    } else if (patron === 'EP') {
        // Error Procedimental → Preguntas paso a paso, ejercicios guiados
        preguntasFiltradas = preguntas.filter(p =>
            p.tipo === 'calculo' ||
            p.tipo === 'procedimiento' ||
            p.pregunta?.toLowerCase().includes('calcula') ||
            p.pregunta?.toLowerCase().includes('resuelve') ||
            p.pregunta?.toLowerCase().includes('paso')
        );
        // Nivel Bloom: APLICAR
    } else if (patron === 'EAC') {
        // Error de Aplicación → Problemas contextuales, casos prác ticos
        preguntasFiltradas = preguntas.filter(p =>
            p.tipo === 'problema' ||
            p.tipo === 'aplicacion' ||
            p.pregunta?.toLowerCase().includes('problema') ||
            p.pregunta?.toLowerCase().includes('situación') ||
            p.pregunta?.toLowerCase().includes('vida real')
        );
        // Nivel Bloom: APLICAR, ANALIZAR
    } else if (patron === 'ETF') {
        // Error de Forma → Variedad de preguntas con énfasis en revisión
        preguntasFiltradas = preguntas;
    }

    // Filtrar por dificultad
    preguntasFiltradas = filtrarPorDificultad(preguntasFiltradas, dificultad);

    // Si no hay suficientes, completar con preguntas generales
    if (preguntasFiltradas.length < cantidad) {
        const faltantes = cantidad - preguntasFiltradas.length;
        const adicionales = preguntas
            .filter(p => !preguntasFiltradas.includes(p))
            .slice(0, faltantes);
        preguntasFiltradas = [...preguntasFiltradas, ...adicionales];
    }

    return preguntasFiltradas;
}

/**
 * Seleccionar preguntas por criterio LOMLOE
 */
function seleccionarPorCriterio(preguntas, criterios, dificultad, cantidad) {
    // Filtrar preguntas que estén relacionadas con los criterios
    // (En futuro, se puede etiquetar cada pregunta con su criterio)
    let preguntasFiltradas = filtrarPorDificultad(preguntas, dificultad);

    return preguntasFiltradas.slice(0, cantidad);
}

/**
 * Seleccionar preguntas de desafío (para estudiantes avanzados)
 */
function seleccionarDesafio(preguntas, cantidad) {
    // Solo preguntas difíciles y de niveles Bloom altos
    const desafiantes = preguntas.filter(p => {
        const dificil = p.dificultad === 'dificil' || p.dificultad === 'difícil';
        const bloomAlto = ['ANALIZAR', 'EVALUAR', 'CREAR'].includes(p.nivelBloom);
        return dificil || bloomAlto;
    });

    if (desafiantes.length >= cantidad) {
        return desafiantes.slice(0, cantidad);
    }

    // Completar con preguntas de dificultad media
    const medias = preguntas.filter(p => p.dificultad === 'media');
    return [...desafiantes, ...medias].slice(0, cantidad);
}

/**
 * Seleccionar mezcla equilibrada
 */
function seleccionarEquilibrada(preguntas, dificultadPreferida, cantidad) {
    const filtradas = filtrarPorDificultad(preguntas, dificultadPreferida);
    return filtradas.slice(0, cantidad);
}

/**
 * Filtrar por dificultad
 */
function filtrarPorDificultad(preguntas, dificultadPreferida) {
    // 70% de la dificultad preferida, 30% mixta
    const preferidas = preguntas.filter(p =>
        p.dificultad === dificultadPreferida ||
        p.dificultad === dificultadPreferida.normalize('NFD').replace(/[\u0300-\u036f]/g, '')
    );
    const otras = preguntas.filter(p => !preferidas.includes(p));

    const cantidadPreferidas = Math.ceil(preferidas.length * 0.7);
    const cantidadOtras = Math.floor(otras.length * 0.3);

    return [...preferidas.slice(0, cantidadPreferidas), ...otras.slice(0, cantidadOtras)];
}

/**
 * Generar título descriptivo
 */
function generarTitulo(enfoque, asignatura, tema) {
    const base = `${asignatura} - ${tema}`;

    if (enfoque.tipo === 'patron_especifico') {
        const patronInfo = PATRONES_ERROR_TIER1[enfoque.patronPrincipal];
        return `${base} - Refuerzo: ${patronInfo.nombre}`;
    } else if (enfoque.tipo === 'desafio') {
        return `${base} - Desafío Avanzado`;
    } else if (enfoque.tipo === 'criterio_especifico') {
        return `${base} - Refuerzo Específico`;
    } else {
        return `${base} - Personalizada`;
    }
}

/**
 * Generar descripción de la ficha
 */
function generarDescripcion(enfoque) {
    const patronInfo = enfoque.patronPrincipal ? PATRONES_ERROR_TIER1[enfoque.patronPrincipal] : null;

    let descripcion = '📚 **Ficha Personalizada**\n\n';
    descripcion += `${enfoque.razon}\n\n`;

    if (patronInfo) {
        descripcion += `**Enfoque:** ${patronInfo.nombre}\n`;
        descripcion += `${patronInfo.descripcion}\n\n`;
        descripcion += `**Plan de Trabajo:**\n`;
        descripcion += `• Método: ${patronInfo.intervencion.metodo}\n`;
        descripcion += `• Duración recomendada: ${patronInfo.intervencion.duracion}\n`;
        descripcion += `• Frecuencia: ${patronInfo.intervencion.frecuencia}\n\n`;
    }

    descripcion += `**Nivel de dificultad:** ${enfoque.dificultadSugerida}\n`;
    descripcion += `**Prioridad:** ${enfoque.prioridad}`;

    return descripcion;
}

/**
 * Generar ficha normal (sin historial)
 */
async function generarFichaNormal(asignatura, tema, curso, numPreguntas) {
    const preguntas = await obtenerPreguntasPorTema(asignatura, tema, numPreguntas, curso);

    return {
        titulo: `${asignatura} - ${tema}`,
        descripcion: 'Ficha de ejercicios estándar',
        preguntas: preguntas.slice(0, numPreguntas),
        enfoque: { tipo: 'general', personalizada: false },
        metadata: {
            asignatura,
            tema,
            curso,
            personalizada: false,
            fechaGeneracion: new Date().toISOString()
        }
    };
}

/**
 * Sugerir fichas basadas en análisis
 */
export function sugerirFichas(analisis, asignatura, curso) {
    const sugerencias = [];

    // Sugerencia 1: Refuerzo de patrón recurrente
    if (analisis.patronesRecurrentes.length > 0) {
        const patron = analisis.patronesRecurrentes[0];
        sugerencias.push({
            tipo: 'patron_recurrente',
            prioridad: patron.gravedad === 'CRÍTICA' ? 1 : 2,
            titulo: `Reforzar ${patron.info.nombre}`,
            descripcion: `Este patrón aparece en ${patron.frecuencia}% de tus evaluaciones`,
            icono: patron.info.icono,
            configuracion: {
                asignatura,
                curso,
                enfoque: {
                    tipo: 'patron_especifico',
                    patronPrincipal: patron.patron,
                    dificultadSugerida: patron.patron === 'EC' ? 'facil' : 'media'
                }
            }
        });
    }

    // Sugerencia 2: Criterio LOMLOE problemático
    if (analisis.criteriosProblematicos.length > 0) {
        const criterio = analisis.criteriosProblematicos[0];
        sugerencias.push({
            tipo: 'criterio_lomloe',
            prioridad: 2,
            titulo: `Reforzar ${criterio.codigo}`,
            descripcion: `Este criterio LOMLOE necesita atención especial`,
            icono: '📋',
            configuracion: {
                asignatura: criterio.asignatura,
                curso: criterio.curso,
                enfoque: {
                    tipo: 'criterio_especifico',
                    criteriosProblematicos: [criterio.codigo],
                    dificultadSugerida: 'media'
                }
            }
        });
    }

    // Sugerencia 3: Desafío (si va muy bien)
    if (analisis.evolucionPuntuacion.promedio >= 85 &&
        analisis.tendenciaGeneral.tipo.includes('mejorando')) {
        sugerencias.push({
            tipo: 'desafio',
            prioridad: 3,
            titulo: 'Desafío Avanzado',
            descripcion: '¡Vas muy bien! Prueba con ejercicios más desafiantes',
            icono: '🚀',
            configuracion: {
                asignatura,
                curso,
                enfoque: {
                    tipo: 'desafio',
                    dificultadSugerida: 'dificil'
                }
            }
        });
    }

    // Sugerencia 4: Repaso general (si va mal)
    if (analisis.evolucionPuntuacion.promedio < 60 ||
        analisis.tendenciaGeneral.tipo.includes('empeorando')) {
        sugerencias.push({
            tipo: 'repaso_basico',
            prioridad: 1,
            titulo: 'Repaso Básico',
            descripcion: 'Refuerza los conceptos fundamentales desde el principio',
            icono: '📚',
            configuracion: {
                asignatura,
                curso,
                enfoque: {
                    tipo: 'general',
                    dificultadSugerida: 'facil'
                }
            }
        });
    }

    return sugerencias.sort((a, b) => a.prioridad - b.prioridad);
}

export default {
    generarFichaPersonalizada,
    sugerirFichas
};
