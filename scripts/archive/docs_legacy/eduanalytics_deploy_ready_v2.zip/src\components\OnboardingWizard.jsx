import React, { useState } from 'react';
import { supabase } from '../supabaseClient';
import { generateWorksheet } from '../utils/gemini';
import {
    Sparkles, ArrowRight, Brain, Zap,
    MessageSquare, BookOpen, Crown, Rocket, AlertCircle
} from 'lucide-react';

const OnboardingWizard = ({ studentId, onComplete }) => {
    const [step, setStep] = useState('welcome'); // welcome, name, visual-quiz, villain, generating
    const [userData, setUserData] = useState({
        name: '',
        learningStyle: '',
        examBlock: '',
        villainSubject: ''
    });
    // Removed loading state variable as it's not used in current render implementation effectively, 
    // relying on step 'generating' instead.

    // --- STEP 1: NOMBRE ---
    const handleNameSubmit = (e) => {
        e.preventDefault();
        if (userData.name.trim()) setStep('visual-quiz');
    };

    // --- STEP 2: ESTILO (QUIZ) ---
    const quizOptions = [
        { id: 'visual', label: 'Hacer dibujos en los márgenes', icon: Sparkles, color: 'text-pink-500', bg: 'bg-pink-50' },
        { id: 'auditory', label: 'Hablar con el compañero de al lado', icon: MessageSquare, color: 'text-blue-500', bg: 'bg-blue-50' },
        { id: 'kinesthetic', label: 'Mover el boli o la pierna sin parar', icon: Zap, color: 'text-amber-500', bg: 'bg-amber-50' },
        { id: 'reading', label: 'Leer el libro por mi cuenta', icon: BookOpen, color: 'text-indigo-500', bg: 'bg-indigo-50' },
    ];

    const selectStyle = (styleId) => {
        setUserData(prev => ({ ...prev, learningStyle: styleId }));
        setStep('exam-quiz');
    };

    // --- STEP 3: BLOQUEO EXAMEN (NUEVO) ---
    const examOptions = [
        { id: 'nerves', label: 'Me quedo en blanco por los nervios', icon: AlertCircle, color: 'text-red-500', bg: 'bg-red-50' },
        { id: 'time', label: 'No me da tiempo a acabar', icon: Zap, color: 'text-orange-500', bg: 'bg-orange-50' },
        { id: 'confusion', label: 'Confundo conceptos y me lío', icon: Brain, color: 'text-purple-500', bg: 'bg-purple-50' },
    ];

    const selectExamBlock = (blockId) => {
        setUserData(prev => ({ ...prev, examBlock: blockId }));
        setStep('villain');
    };

    // --- STEP 3: VILLANO ---
    const handleVillainSubmit = async (e) => {
        e.preventDefault();
        if (userData.villainSubject.trim()) {
            setStep('generating');
            // Little delay to show animation
            setTimeout(() => finishValidating(), 100);
        }
    };

    // --- STEP 4: GENERACIÓN MÁGICA ---
    const finishValidating = async () => {
        try {
            const { data: { user } } = await supabase.auth.getUser();
            const targetId = studentId || user?.id; // Fallback to auth user if no studentId provided

            if (!targetId) throw new Error("No target ID identified");

            // 1. Guardar Nombre
            // Intentamos actualizar 'students' primero (si es hijo), si falla/no afecta, intentamos 'profiles'
            let nameUpdated = false;

            // Try updating students table
            const { error: studentErr, count } = await supabase
                .from('students')
                .update({ first_name: userData.name, full_name: userData.name })
                .eq('id', targetId)
                .select(); // Select to check if row existed

            if (!studentErr && count > 0) {
                nameUpdated = true;
            } else {
                // Try profiles table (if it's the main user)
                await supabase
                    .from('profiles')
                    .update({ first_name: userData.name, full_name: userData.name })
                    .eq('id', targetId);
            }

            // 2. Guardar Learning Profile (Estilo)
            let varkStyle = 'Visual';
            if (userData.learningStyle === 'auditory') varkStyle = 'Auditivo';
            if (userData.learningStyle === 'kinesthetic') varkStyle = 'Kinestésico';
            if (userData.learningStyle === 'reading') varkStyle = 'Lectoescritura';

            const { error: lpError } = await supabase
                .from('learning_profiles')
                .upsert({
                    student_id: targetId,
                    vark_dominant: varkStyle,
                    vark_scores: null, // Reset any existing scores to force "Basic Profile" state
                    last_updated: new Date().toISOString()
                }, { onConflict: 'student_id' });

            if (lpError) console.error("Error saving LP:", lpError);

            // 3. GENERAR EL REGALO (Primer Recurso)
            let blockAdvice = "";
            if (userData.examBlock === 'nerves') blockAdvice = "Incluye una técnica de respiración o gestión emocional (SEL) al principio.";
            if (userData.examBlock === 'time') blockAdvice = "Enfócate en la velocidad y gestión del tiempo (Pomodoro).";
            if (userData.examBlock === 'confusion') blockAdvice = "Usa la técnica Feynman para clarificar conceptos básicos.";

            // Fallback content in case AI fails
            let generatedContent = {
                title: `Plan Anti-Villano para ${userData.villainSubject}`,
                intro: `Hola ${userData.name}. He diseñado esto pensando en tu estilo ${varkStyle}.`,
                theory_recap: `Para tu bloqueo (${userData.examBlock}), te recomiendo: ${blockAdvice}`,
                type: "ROADMAP",
                sections: [
                    {
                        title: "Misión Inicial",
                        questions: [{ text: "¿Qué es lo más difícil de este tema?", feedback: "Identificar el problema es el primer paso." }]
                    }
                ]
            };

            const prompt = `
                Hola IA. Soy ${userData.name}. 
                Estilo: ${varkStyle}.
                Problema Principal en Examen: ${userData.examBlock} (${blockAdvice}).
                Asignatura Villano: "${userData.villainSubject}".
                
                Genera un "Plan de Ataque Secreto" (JSON) para dominar "${userData.villainSubject}".
                IMPORTANTE: Añade una sección específica para solucionar mi problema de "${userData.examBlock}".
                
                JSON Schema:
                {
                   "title": "string",
                   "intro": "string",
                   "theory_recap": "string",
                   "type": "ROADMAP",
                   "sections": []
                }
            `;

            try {
                const aiResult = await generateWorksheet({
                    profile: { grade_level: 'General' },
                    subject: { name: userData.villainSubject },
                    topic: 'Estrategia de Estudio',
                    activityType: 'Plan de Arranque',
                    config: { difficulty: 'Fácil', numQuestions: 1 },
                    observations: prompt
                });

                // Intentar parsear
                let parsedAI = null;
                try {
                    parsedAI = JSON.parse(aiResult);
                } catch (e) {
                    const jsonMatch = aiResult.match(/\{[\s\S]*\}/);
                    if (jsonMatch) parsedAI = JSON.parse(jsonMatch[0]);
                }

                if (parsedAI && parsedAI.title) {
                    generatedContent = parsedAI;
                }
            } catch (aiErr) {
                console.warn("AI Generation failed, using fallback:", aiErr.message);
                // We proceed with the default 'generatedContent'
            }

            // 4. Guardar en Mochila (Resource Library)
            await supabase.from('resource_library').insert({
                student_id: targetId,
                title: generatedContent.title || `Plan para ${userData.villainSubject}`,
                description: "Tu primera herramienta personalizada. ¡Empieza aquí!",
                resource_type: 'ROADMAP',
                topic: userData.villainSubject,
                subject: userData.villainSubject,
                content: generatedContent,
                is_public: false,
                ai_quality_score: 10
            });

            // SUCCESS -> Salir
            onComplete();

        } catch (error) {
            console.error("Wizard Critical Error:", error);
            // Even if it fails, we let them in to avoid blocking.
            alert("Hubo un pequeño error de conexión, pero ya estás dentro.");
            onComplete();
        }
    };


    // --- RENDERIZADO ---

    if (step === 'welcome') return (
        <div className="fixed inset-0 z-[200] bg-slate-900 flex flex-col items-center justify-center p-6 text-center text-white animate-in fade-in duration-500">
            <div className="w-24 h-24 bg-gradient-to-br from-indigo-500 to-purple-600 rounded-full flex items-center justify-center mb-8 shadow-[0_0_50px_rgba(99,102,241,0.5)] animate-bounce">
                <Rocket className="w-12 h-12 text-white" />
            </div>
            <h1 className="text-4xl md:text-6xl font-black mb-6 tracking-tight">
                ¡Hola! Soy <span className="text-transparent bg-clip-text bg-gradient-to-r from-blue-400 to-emerald-400">EduAnalytics</span>.
            </h1>
            <p className="text-xl text-slate-300 max-w-lg mb-10 leading-relaxed">
                No soy un simple profesor virtual. Soy tu <b className="text-white">Copiloto de Neuro-Aprendizaje</b>.
                <br />Pero primero... necesito saber cómo te llamas.
            </p>

            <form onSubmit={handleNameSubmit} className="w-full max-w-md space-y-4">
                <input
                    type="text"
                    placeholder="Escribe tu nombre..."
                    value={userData.name}
                    onChange={(e) => setUserData({ ...userData, name: e.target.value })}
                    className="w-full px-8 py-5 rounded-full bg-slate-800/50 border-2 border-slate-700 text-center text-2xl font-bold text-white placeholder:text-slate-600 focus:border-indigo-500 focus:outline-none focus:ring-4 focus:ring-indigo-500/20 transition-all shadow-xl"
                    autoFocus
                />
                <button
                    type="submit"
                    disabled={!userData.name.trim()}
                    className="w-full py-5 rounded-full bg-white text-slate-900 font-black text-lg uppercase tracking-widest hover:scale-105 transition-transform disabled:opacity-50 disabled:scale-100 shadow-2xl shadow-white/10"
                >
                    Comenzar Aventura
                </button>
            </form>
        </div>
    );

    if (step === 'visual-quiz') return (
        <div className="fixed inset-0 z-[200] bg-white flex flex-col items-center justify-center p-6 text-center animate-in slide-in-from-right duration-500">
            <h2 className="text-3xl md:text-5xl font-black text-slate-900 mb-4">
                Encantado, <span className="text-indigo-600 decoration-4 underline decoration-indigo-200">{userData.name}</span>.
            </h2>
            <p className="text-lg text-slate-500 mb-12 max-w-xl">
                Vamos a calibrar el sistema para tu cerebro. <br />
                <b>Pregunta Rápida:</b> Estás en clase y el tema es un poco aburrido... ¿Qué sueles hacer instintivamente?
            </p>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4 w-full max-w-4xl">
                {quizOptions.map((opt) => (
                    <button
                        key={opt.id}
                        onClick={() => selectStyle(opt.id)}
                        className={`group relative p-8 rounded-[32px] border-2 border-slate-100 hover:border-${opt.color.split('-')[1]}-200 ${opt.bg} hover:shadow-xl hover:-translate-y-1 transition-all text-left flex items-center gap-6`}
                    >
                        <div className={`p-4 bg-white rounded-2xl shadow-sm ${opt.color}`}>
                            <opt.icon className="w-8 h-8" />
                        </div>
                        <div>
                            <h3 className="text-xl font-bold text-slate-800 group-hover:text-indigo-600 transition-colors">
                                {opt.label}
                            </h3>
                        </div>
                        <div className="absolute top-1/2 right-6 -translate-y-1/2 opacity-0 group-hover:opacity-100 transition-opacity">
                            <ArrowRight className="w-6 h-6 text-slate-400" />
                        </div>
                    </button>
                ))}
            </div>
        </div>
    );

    if (step === 'exam-quiz') return (
        <div className="fixed inset-0 z-[200] bg-white flex flex-col items-center justify-center p-6 text-center animate-in slide-in-from-right duration-500">
            <h2 className="text-3xl md:text-5xl font-black text-slate-900 mb-4">
                Una cosa más...
            </h2>
            <p className="text-lg text-slate-500 mb-12 max-w-xl">
                ¿Cuál es tu peor pesadilla en un examen?
            </p>

            <div className="grid grid-cols-1 gap-4 w-full max-w-2xl">
                {examOptions.map((opt) => (
                    <button
                        key={opt.id}
                        onClick={() => selectExamBlock(opt.id)}
                        className={`group relative p-6 rounded-[32px] border-2 border-slate-100 hover:border-${opt.color.split('-')[1]}-200 ${opt.bg} hover:shadow-xl hover:-translate-y-1 transition-all text-left flex items-center gap-6`}
                    >
                        <div className={`p-4 bg-white rounded-2xl shadow-sm ${opt.color}`}>
                            <opt.icon className="w-8 h-8" />
                        </div>
                        <div>
                            <h3 className="text-xl font-bold text-slate-800 group-hover:text-black transition-colors">
                                {opt.label}
                            </h3>
                        </div>
                    </button>
                ))}
            </div>
        </div>
    );

    if (step === 'villain') return (
        <div className="fixed inset-0 z-[200] bg-gradient-to-br from-indigo-900 to-slate-900 flex flex-col items-center justify-center p-6 text-center text-white animate-in slide-in-from-right duration-500">
            <div className="max-w-2xl w-full">
                <div className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full bg-indigo-500/20 text-indigo-200 text-xs font-black uppercase tracking-widest mb-6 border border-indigo-500/30">
                    <Crown className="w-4 h-4" /> Último Paso
                </div>
                <h2 className="text-4xl md:text-5xl font-black mb-6">
                    ¿Cuál es tu "Villano Final"?
                </h2>
                <p className="text-xl text-slate-300 mb-10 leading-relaxed">
                    Dime esa asignatura o tema que se te resiste. <br />
                    Voy a preparar un <b>Plan Secreto</b> para que la domines.
                </p>

                <form onSubmit={handleVillainSubmit} className="space-y-6">
                    <input
                        type="text"
                        placeholder="Ej: Matemáticas, Historia, Física..."
                        value={userData.villainSubject}
                        onChange={(e) => setUserData({ ...userData, villainSubject: e.target.value })}
                        className="w-full px-8 py-6 rounded-[24px] bg-white/10 backdrop-blur-md border-2 border-white/10 text-center text-3xl font-bold text-white placeholder:text-white/20 focus:border-emerald-400 focus:outline-none focus:bg-white/20 transition-all"
                        autoFocus
                    />
                    <button
                        type="submit"
                        disabled={!userData.villainSubject.trim()}
                        className="w-full py-5 rounded-full bg-emerald-500 text-white font-black text-lg uppercase tracking-widest hover:bg-emerald-400 hover:scale-[1.02] shadow-xl shadow-emerald-500/30 transition-all flex items-center justify-center gap-3 disabled:opacity-50 disabled:scale-100"
                    >
                        <Sparkles className="w-6 h-6" />
                        Generar Mi Estrategia
                    </button>
                </form>
            </div>
        </div>
    );

    if (step === 'generating') return (
        <div className="fixed inset-0 z-[200] bg-white flex flex-col items-center justify-center p-6 text-center">
            <div className="w-32 h-32 relative mb-12">
                <div className="absolute inset-0 border-8 border-indigo-100 rounded-full"></div>
                <div className="absolute inset-0 border-8 border-t-indigo-600 rounded-full animate-spin"></div>
                <div className="absolute inset-0 flex items-center justify-center">
                    <Brain className="w-12 h-12 text-indigo-600 animate-pulse" />
                </div>
            </div>

            <h2 className="text-3xl font-black text-slate-800 mb-4 animate-pulse">
                Diseñando Estrategia para {userData.villainSubject}...
            </h2>
            <div className="space-y-4 text-slate-500 font-medium">
                <p className="flex items-center justify-center gap-2 animate-in fade-in slide-in-from-bottom-2 duration-700">
                    <Sparkles className="w-4 h-4 text-emerald-500" />
                    Optimizando para perfil {userData.learningStyle}...
                </p>
                <p className="flex items-center justify-center gap-2 animate-in fade-in slide-in-from-bottom-2 duration-700 delay-1000">
                    <Crown className="w-4 h-4 text-amber-500" />
                    Consultando estrategias de Alto Rendimiento...
                </p>
                <p className="flex items-center justify-center gap-2 text-indigo-600 font-bold animate-in fade-in slide-in-from-bottom-2 duration-700 delay-2000">
                    <Rocket className="w-4 h-4" />
                    ¡Ya casi está! Llenando tu mochila...
                </p>
            </div>
        </div>
    );

    return null;
};

export default OnboardingWizard;
