import React, { useState } from 'react';
import {
    TrendingUp, TrendingDown, Target, Award, AlertCircle,
    CheckCircle2, XCircle, Brain, BookOpen, Users,
    Download, Printer, Share2, Mail, Star, Trophy,
    BarChart3, PieChart, LineChart, Clock, Calendar
} from 'lucide-react';
import { PATRONES_ERROR_TIER1, obtenerCriterioLOMLOE } from '../services/taxonomia-errores-avanzada';

/**
 * COMPONENTE DE INFORME DE EVALUACIÓN
 * Muestra análisis detallado con feedback para estudiante y padres
 */
const InformeEvaluacion = ({ resultados, nombreEstudiante, nombreFicha }) => {
    const [vistaActual, setVistaActual] = useState('estudiante'); // 'estudiante' | 'padres' | 'detallado'

    if (!resultados) {
        return <div className="text-gray-500">Cargando resultados...</div>;
    }

    return (
        <div className="max-w-6xl mx-auto p-6 space-y-8">
            {/* Header con selector de vista */}
            <div className="bg-gradient-to-r from-blue-600 to-purple-600 rounded-2xl p-6 text-white shadow-xl">
                <h1 className="text-3xl font-bold mb-2">📊 Informe de Evaluación</h1>
                <p className="text-blue-100 mb-4">{nombreFicha || 'Ficha de Trabajo'}</p>

                {/* Tabs para cambiar vista */}
                <div className="flex gap-3">
                    <button
                        onClick={() => setVistaActual('estudiante')}
                        className={`px-4 py-2 rounded-lg font-semibold transition-all ${vistaActual === 'estudiante'
                            ? 'bg-white text-blue-600'
                            : 'bg-blue-500/30 hover:bg-blue-500/50'
                            }`}
                    >
                        👨‍🎓 Para el Estudiante
                    </button>
                    <button
                        onClick={() => setVistaActual('padres')}
                        className={`px-4 py-2 rounded-lg font-semibold transition-all ${vistaActual === 'padres'
                            ? 'bg-white text-blue-600'
                            : 'bg-blue-500/30 hover:bg-blue-500/50'
                            }`}
                    >
                        👨‍👩‍👧 Para los Padres
                    </button>
                    <button
                        onClick={() => setVistaActual('detallado')}
                        className={`px-4 py-2 rounded-lg font-semibold transition-all ${vistaActual === 'detallado'
                            ? 'bg-white text-blue-600'
                            : 'bg-blue-500/30 hover:bg-blue-500/50'
                            }`}
                    >
                        📋 Análisis Detallado
                    </button>
                </div>
            </div>

            {/* Tarjeta de Puntuación Principal */}
            <div className="bg-white rounded-2xl shadow-lg p-8 border-2 border-gray-100">
                <div className="grid md:grid-cols-2 gap-8 items-center">
                    {/* Puntuación visual */}
                    <div className="text-center">
                        <div className="relative inline-block">
                            <svg className="w-48 h-48 transform -rotate-90">
                                <circle
                                    cx="96"
                                    cy="96"
                                    r="80"
                                    stroke="#e5e7eb"
                                    strokeWidth="16"
                                    fill="none"
                                />
                                <circle
                                    cx="96"
                                    cy="96"
                                    r="80"
                                    stroke={getColorPorcentaje(resultados.porcentaje)}
                                    strokeWidth="16"
                                    fill="none"
                                    strokeDasharray={`${(resultados.porcentaje / 100) * 502.65} 502.65`}
                                    className="transition-all duration-1000"
                                />
                            </svg>
                            <div className="absolute inset-0 flex flex-col items-center justify-center">
                                <div className="text-5xl font-bold" style={{ color: getColorPorcentaje(resultados.porcentaje) }}>
                                    {resultados.porcentaje}%
                                </div>
                                <div className="text-sm text-gray-500 mt-1">
                                    {resultados.correctas}/{resultados.totalPreguntas}
                                </div>
                            </div>
                        </div>
                    </div>

                    {/* Estadísticas rápidas */}
                    <div className="space-y-4">
                        <div className="flex items-center gap-3 p-3 bg-green-50 rounded-lg">
                            <CheckCircle2 className="w-6 h-6 text-green-600" />
                            <div>
                                <div className="font-semibold text-green-900">Correctas</div>
                                <div className="text-2xl font-bold text-green-600">{resultados.correctas}</div>
                            </div>
                        </div>

                        <div className="flex items-center gap-3 p-3 bg-orange-50 rounded-lg">
                            <AlertCircle className="w-6 h-6 text-orange-600" />
                            <div>
                                <div className="font-semibold text-orange-900">Parcialmente correctas</div>
                                <div className="text-2xl font-bold text-orange-600">{resultados.parciales}</div>
                            </div>
                        </div>

                        <div className="flex items-center gap-3 p-3 bg-red-50 rounded-lg">
                            <XCircle className="w-6 h-6 text-red-600" />
                            <div>
                                <div className="font-semibold text-red-900">Incorrectas</div>
                                <div className="text-2xl font-bold text-red-600">{resultados.incorrectas}</div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            {/* Contenido según vista seleccionada */}
            {vistaActual === 'estudiante' && <VistaEstudiante resultados={resultados} />}
            {vistaActual === 'padres' && <VistaPadres resultados={resultados} nombreEstudiante={nombreEstudiante} />}
            {vistaActual === 'detallado' && <VistaDetallada resultados={resultados} />}

            {/* Botones de acción */}
            <div className="flex gap-4 justify-center print:hidden">
                <button className="flex items-center gap-2 px-6 py-3 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors">
                    <Printer className="w-5 h-5" />
                    Imprimir Informe
                </button>
                <button className="flex items-center gap-2 px-6 py-3 bg-green-600 text-white rounded-lg hover:bg-green-700 transition-colors">
                    <Download className="w-5 h-5" />
                    Descargar PDF
                </button>
                <button className="flex items-center gap-2 px-6 py-3 bg-purple-600 text-white rounded-lg hover:bg-purple-700 transition-colors">
                    <Mail className="w-5 h-5" />
                    Enviar por Email
                </button>
            </div>
        </div>
    );
};

/**
 * VISTA PARA EL ESTUDIANTE
 */
const VistaEstudiante = ({ resultados }) => {
    return (
        <div className="space-y-6">
            {/* Mensaje personalizado */}
            <div className="bg-gradient-to-r from-purple-50 to-pink-50 rounded-2xl p-6 border-2 border-purple-200">
                <h2 className="text-2xl font-bold text-purple-900 mb-4 flex items-center gap-2">
                    <Star className="w-7 h-7" />
                    Tu Resultado
                </h2>
                <div className="prose prose-purple max-w-none text-gray-700 leading-relaxed whitespace-pre-line">
                    {resultados.mensajeEstudiante}
                </div>
            </div>

            {/* Fortalezas */}
            {resultados.fortalezas.length > 0 && (
                <div className="bg-green-50 rounded-2xl p-6 border-2 border-green-200">
                    <h3 className="text-xl font-bold text-green-900 mb-4 flex items-center gap-2">
                        <Trophy className="w-6 h-6" />
                        Tus Fortalezas
                    </h3>
                    <div className="space-y-3">
                        {resultados.fortalezas.map((fortaleza, idx) => (
                            <div key={idx} className="flex items-start gap-3 bg-white p-4 rounded-lg">
                                <span className="text-3xl">{fortaleza.icono}</span>
                                <div>
                                    <div className="font-semibold text-green-900">{fortaleza.titulo}</div>
                                    <div className="text-sm text-gray-600">{fortaleza.descripcion}</div>
                                </div>
                            </div>
                        ))}
                    </div>
                </div>
            )}

            {/* Áreas de mejora */}
            {resultados.debilidades.length > 0 && (
                <div className="bg-blue-50 rounded-2xl p-6 border-2 border-blue-200">
                    <h3 className="text-xl font-bold text-blue-900 mb-4 flex items-center gap-2">
                        <Target className="w-6 h-6" />
                        ¿Dónde puedes mejorar?
                    </h3>
                    <div className="space-y-3">
                        {resultados.debilidades.map((debilidad, idx) => (
                            <div key={idx} className="flex items-start gap-3 bg-white p-4 rounded-lg">
                                <span className="text-3xl">{debilidad.icono}</span>
                                <div className="flex-1">
                                    <div className="font-semibold text-blue-900">{debilidad.titulo}</div>
                                    <div className="text-sm text-gray-600 mb-2">{debilidad.descripcion}</div>
                                    <div className="text-sm bg-blue-100 text-blue-800 px-3 py-1 rounded-full inline-block">
                                        💡 {debilidad.accion}
                                    </div>
                                </div>
                            </div>
                        ))}
                    </div>
                </div>
            )}

            {/* ⭐ NUEVO: Tipo de errores que cometes (simplificado para estudiantes) */}
            {resultados.erroresPorPatron && Object.keys(resultados.erroresPorPatron).length > 0 && (
                <div className="bg-gradient-to-r from-indigo-50 to-purple-50 rounded-2xl p-6 border-2 border-indigo-200">
                    <h3 className="text-xl font-bold text-indigo-900 mb-4 flex items-center gap-2">
                        <Brain className="w-6 h-6" />
                        ¿Qué tipo de errores cometo?
                    </h3>
                    <p className="text-sm text-gray-700 mb-4">
                        Entender tus errores te ayuda a mejorar más rápido:
                    </p>
                    <div className="grid md:grid-cols-2 gap-3">
                        {Object.entries(resultados.erroresPorPatron).map(([patron, count]) => {
                            const patronInfo = PATRONES_ERROR_TIER1[patron];
                            if (!patronInfo) return null;

                            return (
                                <div key={patron} className="bg-white p-4 rounded-lg shadow-sm">
                                    <div className="flex items-center gap-2 mb-2">
                                        <span className="text-3xl">{patronInfo.icono}</span>
                                        <div className="flex-1">
                                            <div className="font-semibold text-gray-900">{patronInfo.nombre}</div>
                                            <div className="text-xs text-gray-500">{count} error{count > 1 ? 'es' : ''}</div>
                                        </div>
                                    </div>
                                    <div className="text-xs text-gray-600 mb-2">
                                        {patronInfo.descripcion}
                                    </div>
                                    {patronInfo.intervencion && (
                                        <div className="text-xs bg-indigo-50 p-2 rounded">
                                            💡 {patronInfo.intervencion.metodo}
                                        </div>
                                    )}
                                </div>
                            );
                        })}
                    </div>
                </div>
            )}

            {/* Recomendaciones */}
            <div className="bg-orange-50 rounded-2xl p-6 border-2 border-orange-200">
                <h3 className="text-xl font-bold text-orange-900 mb-4 flex items-center gap-2">
                    <BookOpen className="w-6 h-6" />
                    Próximos Pasos
                </h3>
                <div className="space-y-3">
                    {resultados.recomendacionesGenerales.map((rec, idx) => (
                        <div key={idx} className={`p-4 rounded-lg ${getPrioridadColor(rec.prioridad)}`}>
                            <div className="flex items-start gap-3">
                                <span className="text-2xl">{rec.icono}</span>
                                <div>
                                    <div className="font-semibold mb-1">{rec.mensaje}</div>
                                    <div className="text-sm bg-white/70 px-3 py-1 rounded">
                                        📌 {rec.accion}
                                    </div>
                                </div>
                            </div>
                        </div>
                    ))}
                </div>
            </div>
        </div>
    );
};

/**
 * VISTA PARA LOS PADRES
 */
const VistaPadres = ({ resultados, nombreEstudiante }) => {
    return (
        <div className="space-y-6">
            {/* Resumen ejecutivo */}
            <div className="bg-white rounded-2xl p-6 border-2 border-gray-200 shadow-lg">
                <h2 className="text-2xl font-bold text-gray-900 mb-4 flex items-center gap-2">
                    <Users className="w-7 h-7 text-blue-600" />
                    Informe para Padres/Tutores
                </h2>
                <div className="prose max-w-none whitespace-pre-line text-gray-700">
                    {resultados.mensajePadres}
                </div>
            </div>

            {/* Gráfico de rendimiento por dificultad */}
            <div className="bg-white rounded-2xl p-6 border-2 border-gray-200">
                <h3 className="text-xl font-bold text-gray-900 mb-4 flex items-center gap-2">
                    <BarChart3 className="w-6 h-6" />
                    Rendimiento por Nivel de Dificultad
                </h3>
                <div className="space-y-4">
                    {Object.entries(resultados.porDificultad).map(([nivel, data]) => (
                        <div key={nivel} className="space-y-2">
                            <div className="flex justify-between text-sm">
                                <span className="font-semibold capitalize">{nivel}</span>
                                <span className="text-gray-600">{data.correctas}/{data.total} ({data.porcentaje}%)</span>
                            </div>
                            <div className="w-full bg-gray-200 rounded-full h-3">
                                <div
                                    className={`h-3 rounded-full transition-all duration-1000 ${getColorBarra(data.porcentaje)}`}
                                    style={{ width: `${data.porcentaje}%` }}
                                />
                            </div>
                        </div>
                    ))}
                </div>
            </div>

            {/* ⭐ NUEVO: Distribución de Patrones de Error (TIER 1) */}
            {resultados.erroresPorPatron && Object.keys(resultados.erroresPorPatron).length > 0 && (
                <div className="bg-white rounded-2xl p-6 border-2 border-gray-200">
                    <h3 className="text-xl font-bold text-gray-900 mb-4 flex items-center gap-2">
                        <Brain className="w-6 h-6 text-purple-600" />
                        Análisis de Patrones de Error (Diagnóstico Profesional)
                    </h3>
                    <p className="text-sm text-gray-600 mb-4">
                        Este análisis identifica la naturaleza de los errores según taxonomía pedagógica profesional
                    </p>
                    <div className="space-y-4">
                        {Object.entries(resultados.erroresPorPatron).map(([patron, count]) => {
                            const patronInfo = PATRONES_ERROR_TIER1[patron];
                            if (!patronInfo) return null;

                            const porcentaje = Math.round((count / resultados.incorrectas) * 100);

                            return (
                                <div key={patron} className="space-y-2">
                                    <div className="flex items-center justify-between">
                                        <div className="flex items-center gap-2">
                                            <span className="text-2xl">{patronInfo.icono}</span>
                                            <div>
                                                <div className="font-semibold text-gray-900">{patronInfo.nombre}</div>
                                                <div className="text-xs text-gray-600">{patronInfo.descripcion}</div>
                                            </div>
                                        </div>
                                        <div className="text-right">
                                            <div className="font-bold text-gray-900">{count} errores</div>
                                            <div className="text-xs text-gray-500">{porcentaje}% del total</div>
                                        </div>
                                    </div>
                                    <div className="w-full bg-gray-200 rounded-full h-3">
                                        <div
                                            className="h-3 rounded-full transition-all duration-1000"
                                            style={{
                                                width: `${porcentaje}%`,
                                                backgroundColor: patronInfo.color
                                            }}
                                        />
                                    </div>
                                    {patronInfo.intervencion && (
                                        <div className="text-xs bg-gray-50 p-2 rounded">
                                            <strong>Plan de intervención:</strong> {patronInfo.intervencion.metodo}
                                            ({patronInfo.intervencion.duracion}, {patronInfo.intervencion.frecuencia})
                                        </div>
                                    )}
                                </div>
                            );
                        })}
                    </div>

                    {/* Resumen de prioridades */}
                    <div className="mt-4 p-4 bg-yellow-50 border-l-4 border-yellow-500 rounded">
                        <div className="font-semibold text-yellow-900 mb-2">⚠️ Prioridad de Intervención:</div>
                        <div className="text-sm text-gray-700">
                            {(() => {
                                const ec = resultados.erroresPorPatron.EC || 0;
                                const ep = resultados.erroresPorPatron.EP || 0;
                                const eac = resultados.erroresPorPatron.EAC || 0;

                                if (ec > 0) {
                                    return `🚨 ALTA: Se detectaron ${ec} error(es) conceptual(es). Requiere atención inmediata de un adulto/profesor para revisar los conceptos fundamentales.`;
                                } else if (ep > Math.max(eac, 1)) {
                                    return `🔷 MEDIA: Los errores son principalmente procedimentales. Necesita práctica supervisada paso a paso.`;
                                } else if (eac > 0) {
                                    return `🔵 MEDIA-BAJA: Dificultad para aplicar conocimientos a contextos nuevos. Necesita más práctica con casos prácticos.`;
                                } else {
                                    return `✅ BAJA: Solo errores menores de forma. Revisar con calma antes de entregar.`;
                                }
                            })()}
                        </div>
                    </div>
                </div>
            )}

            {/* Errores que requieren atención */}
            {resultados.erroresGraves.length > 0 && (
                <div className="bg-red-50 rounded-2xl p-6 border-2 border-red-200">
                    <h3 className="text-xl font-bold text-red-900 mb-4 flex items-center gap-2">
                        <AlertCircle className="w-6 h-6" />
                        Atención Especial Requerida
                    </h3>
                    <p className="text-sm text-red-700 mb-4">
                        Se han detectado errores conceptuales que requieren intervención inmediata:
                    </p>
                    <div className="space-y-3">
                        {resultados.erroresGraves.map((error, idx) => (
                            <div key={idx} className="bg-white p-4 rounded-lg">
                                <div className="font-semibold text-red-900 mb-1">Tema: {error.tema}</div>
                                <div className="text-sm text-gray-600 mb-2">Pregunta: "{error.pregunta}"</div>
                                <div className="text-sm bg-red-100 text-red-800 px-3 py-2 rounded">
                                    💡 <strong>Recomendación:</strong> {error.recomendacion}
                                </div>
                            </div>
                        ))}
                    </div>
                </div>
            )}
        </div>
    );
};

/**
 * VISTA DETALLADA
 */
const VistaDetallada = ({ resultados }) => {
    return (
        <div className="space-y-6">
            <div className="bg-white rounded-2xl p-6 border-2 border-gray-200">
                <h2 className="text-2xl font-bold text-gray-900 mb-6 flex items-center gap-2">
                    <Brain className="w-7 h-7 text-purple-600" />
                    Análisis Pregunta por Pregunta
                </h2>
                <div className="space-y-4">
                    {resultados.analisisDetallado.map((analisis, idx) => (
                        <div
                            key={idx}
                            className={`p-5 rounded-xl border-2 ${analisis.correcta
                                ? 'bg-green-50 border-green-200'
                                : analisis.puntos > 0
                                    ? 'bg-orange-50 border-orange-200'
                                    : 'bg-red-50 border-red-200'
                                }`}
                        >
                            {/* Pregunta */}
                            <div className="flex items-start gap-3 mb-3">
                                <span className={`flex-shrink-0 w-8 h-8 rounded-full flex items-center justify-center text-white font-bold ${analisis.correcta ? 'bg-green-600' : analisis.puntos > 0 ? 'bg-orange-600' : 'bg-red-600'
                                    }`}>
                                    {idx + 1}
                                </span>
                                <div className="flex-1">
                                    <div className="font-medium text-gray-900 mb-2">{analisis.pregunta}</div>

                                    {/* Respuestas */}
                                    <div className="grid md:grid-cols-2 gap-3 mb-3">
                                        <div className="bg-white p-3 rounded-lg">
                                            <div className="text-xs text-gray-500 mb-1">Tu respuesta:</div>
                                            <div className="text-sm font-medium text-gray-800">
                                                {analisis.respuestaUsuario || <span className="text-gray-400 italic">Sin responder</span>}
                                            </div>
                                        </div>
                                        <div className="bg-white p-3 rounded-lg">
                                            <div className="text-xs text-gray-500 mb-1">Respuesta correcta:</div>
                                            <div className="text-sm font-medium text-green-700">
                                                {analisis.respuestaCorrecta}
                                            </div>
                                        </div>
                                    </div>

                                    {/* Feedback */}
                                    <div className="bg-white/70 p-3 rounded-lg text-sm">
                                        <div className="font-semibold mb-1">📝 Feedback:</div>
                                        <div className="text-gray-700 whitespace-pre-line">{analisis.feedback}</div>
                                    </div>

                                    {/* ⭐ NUEVO: Patrón de Error Profesional (TIER 1) */}
                                    {analisis.patronError && !analisis.correcta && (
                                        <div className="mt-3 p-4 rounded-lg border-2"
                                            style={{
                                                backgroundColor: PATRONES_ERROR_TIER1[analisis.patronError]?.color + '15',
                                                borderColor: PATRONES_ERROR_TIER1[analisis.patronError]?.color
                                            }}>
                                            <div className="flex items-center gap-2 mb-2">
                                                <span className="text-2xl">
                                                    {PATRONES_ERROR_TIER1[analisis.patronError]?.icono}
                                                </span>
                                                <span className="font-bold" style={{ color: PATRONES_ERROR_TIER1[analisis.patronError]?.color }}>
                                                    {PATRONES_ERROR_TIER1[analisis.patronError]?.nombre}
                                                </span>
                                                <span className="text-xs px-2 py-1 bg-white rounded shadow-sm">
                                                    Confianza: {Math.round((analisis.patronConfianza || 0) * 100)}%
                                                </span>
                                            </div>
                                            <p className="text-sm text-gray-700 mb-2">
                                                {PATRONES_ERROR_TIER1[analisis.patronError]?.descripcion}
                                            </p>
                                            <div className="text-xs bg-white/70 px-3 py-2 rounded">
                                                <strong>Impacto:</strong> {PATRONES_ERROR_TIER1[analisis.patronError]?.impacto}
                                            </div>
                                        </div>
                                    )}

                                    {/* ⭐ NUEVO: Criterio LOMLOE (TIER 2) */}
                                    {analisis.criterioLOMLOE && !analisis.correcta && (
                                        <div className="mt-2 p-3 bg-purple-50 border-l-4 border-purple-500 rounded">
                                            <div className="font-semibold text-purple-900 mb-1 flex items-center gap-2">
                                                <span>📋</span>
                                                <span>Criterio LOMLOE: {analisis.criterioLOMLOE.codigo}</span>
                                            </div>
                                            <div className="text-sm text-gray-700">
                                                {(() => {
                                                    const criterio = obtenerCriterioLOMLOE(
                                                        analisis.criterioLOMLOE.asignatura,
                                                        analisis.criterioLOMLOE.curso,
                                                        analisis.criterioLOMLOE.codigo
                                                    );
                                                    return criterio ? (
                                                        <>
                                                            <p>{criterio.descripcion}</p>
                                                            {criterio.competencias && (
                                                                <div className="mt-1 text-xs">
                                                                    <strong>Competencias:</strong> {criterio.competencias.join(', ')}
                                                                </div>
                                                            )}
                                                        </>
                                                    ) : 'Criterio no disponible';
                                                })()}
                                            </div>
                                        </div>
                                    )}

                                    {/* ⭐ NUEVO: Plan de Acción Específico */}
                                    {analisis.planAccion && !analisis.correcta && (
                                        <div className="mt-2 p-3 bg-blue-50 border-l-4 border-blue-500 rounded">
                                            <div className="font-semibold text-blue-900 mb-2">💡 Plan de Acción Recomendado:</div>
                                            <div className="grid grid-cols-2 gap-2 text-xs">
                                                <div>
                                                    <strong>Método:</strong> {analisis.planAccion.metodo}
                                                </div>
                                                <div>
                                                    <strong>Duración:</strong> {analisis.planAccion.duracion}
                                                </div>
                                                <div>
                                                    <strong>Frecuencia:</strong> {analisis.planAccion.frecuencia}
                                                </div>
                                                <div>
                                                    <strong>Prioridad:</strong> {analisis.planAccion.prioridad}
                                                </div>
                                            </div>
                                        </div>
                                    )}

                                    {/* Recomendación tradicional */}
                                    {analisis.recomendacion && !analisis.patronError && (
                                        <div className="mt-2 bg-blue-100 text-blue-800 p-3 rounded-lg text-sm">
                                            <div className="font-semibold mb-1">💡 Recomendación:</div>
                                            <div>{analisis.recomendacion}</div>
                                        </div>
                                    )}

                                    {/* Metadatos */}
                                    <div className="mt-3 flex flex-wrap gap-2">
                                        <span className="text-xs px-2 py-1 bg-purple-100 text-purple-700 rounded">
                                            📊 Nivel Bloom: {analisis.nivelBloom}
                                        </span>
                                        {analisis.patronError && (
                                            <span className="text-xs px-2 py-1 rounded"
                                                style={{
                                                    backgroundColor: PATRONES_ERROR_TIER1[analisis.patronError]?.color + '30',
                                                    color: PATRONES_ERROR_TIER1[analisis.patronError]?.color
                                                }}>
                                                {PATRONES_ERROR_TIER1[analisis.patronError]?.icono} {analisis.patronError}
                                            </span>
                                        )}
                                        {analisis.tipoError && !analisis.patronError && (
                                            <span className="text-xs px-2 py-1 bg-orange-100 text-orange-700 rounded">
                                                ⚠️ Tipo error: {analisis.tipoError}
                                            </span>
                                        )}
                                        <span className="text-xs px-2 py-1 bg-gray-100 text-gray-700 rounded">
                                            ⭐ Puntos: {analisis.puntos}
                                        </span>
                                    </div>
                                </div>
                            </div>
                        </div>
                    ))}
                </div>
            </div>
        </div>
    );
};

/**
 * FUNCIONES AUXILIARES
 */
function getColorPorcentaje(porcentaje) {
    if (porcentaje >= 90) return '#10b981'; // green-500
    if (porcentaje >= 70) return '#3b82f6'; // blue-500
    if (porcentaje >= 50) return '#f59e0b'; // amber-500
    return '#ef4444'; // red-500
}

function getColorBarra(porcentaje) {
    if (porcentaje >= 80) return 'bg-green-500';
    if (porcentaje >= 60) return 'bg-blue-500';
    if (porcentaje >= 40) return 'bg-orange-500';
    return 'bg-red-500';
}

function getPrioridadColor(prioridad) {
    const colores = {
        'alta': 'bg-red-100 border-l-4 border-red-500',
        'media': 'bg-orange-100 border-l-4 border-orange-500',
        'baja': 'bg-blue-100 border-l-4 border-blue-500',
        'info': 'bg-green-100 border-l-4 border-green-500'
    };
    return colores[prioridad] || colores.info;
}

export default InformeEvaluacion;
