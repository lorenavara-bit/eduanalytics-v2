// Khan Academy - Organizado por CURSO
// COMPLETO 4º Y 5º PRIMARIA

// 4º PRIMARIA
import { CUARTO_PRIMARIA_GALICIA } from './cuarto-primaria-galicia-PARTE1.js';
import { CUARTO_PRIMARIA_GALICIA_PARTE2 } from './cuarto-primaria-galicia-PARTE2.js';
import { SANTILLANA_MATEMATICAS_4 } from './santillana-4-primaria-MATES.js';
import { SANTILLANA_LENGUA_4 } from './santillana-4-primaria-LENGUA.js';
import { SANTILLANA_NATURALES_4 } from './santillana-4-primaria-NATURALES.js';
import { SANTILLANA_SOCIALES_4 } from './santillana-4-primaria-SOCIALES.js';
import { SANTILLANA_GALEGO_4 } from './santillana-4-primaria-GALEGO.js';
import { SANTILLANA_INGLES_4 } from './santillana-4-primaria-INGLES.js';

// 5º PRIMARIA
import { QUINTO_PRIMARIA_MATEMATICAS } from './quinto-primaria-matematicas.js';
import { QUINTO_PRIMARIA_LENGUA } from './quinto-primaria-lengua.js';
import { QUINTO_PRIMARIA_SOCIALES } from './quinto-primaria-sociales.js';
import { QUINTO_PRIMARIA_NATURALES } from './quinto-primaria-naturales.js';

// Combinar contenido 4º PRIMARIA (original + Santillana)
const COMPLETO_4_PRIMARIA = {
    // Merge Matemáticas (original + Santillana)
    'Matemáticas': {
        ...CUARTO_PRIMARIA_GALICIA['Matemáticas'],
        ...SANTILLANA_MATEMATICAS_4['Matemáticas']
    },

    // Merge Lengua Castellana (original + Santillana)
    'Lengua Castellana': {
        ...CUARTO_PRIMARIA_GALICIA['Lengua Castellana'],
        ...SANTILLANA_LENGUA_4['Lengua Castellana']
    },

    // Merge Lingua Galega (original + Santillana)
    'Lingua Galega': {
        ...CUARTO_PRIMARIA_GALICIA['Lingua Galega'],
        ...SANTILLANA_GALEGO_4['Lingua Galega']
    },

    // Merge Ciencias de la Naturaleza (original + Santillana)
    'Ciencias de la Naturaleza': {
        ...CUARTO_PRIMARIA_GALICIA_PARTE2['Ciencias de la Naturaleza'],
        ...SANTILLANA_NATURALES_4['Ciencias de la Naturaleza']
    },

    // Merge Ciencias Sociales (original + Santillana)
    'Ciencias Sociales': {
        ...CUARTO_PRIMARIA_GALICIA_PARTE2['Ciencias Sociales'],
        ...SANTILLANA_SOCIALES_4['Ciencias Sociales']
    },

    // Merge Inglés (original + Santillana)
    'Inglés': {
        ...CUARTO_PRIMARIA_GALICIA_PARTE2['Inglés'],
        ...SANTILLANA_INGLES_4['Inglés']
    }
};

// 5º PRIMARIA completo
const COMPLETO_5_PRIMARIA = {
    'Matemáticas': QUINTO_PRIMARIA_MATEMATICAS['Matemáticas'],
    'Lengua Castellana': QUINTO_PRIMARIA_LENGUA['Lengua Castellana'],
    'Ciencias Sociales': QUINTO_PRIMARIA_SOCIALES['Ciencias Sociales'],
    'Ciencias de la Naturaleza': QUINTO_PRIMARIA_NATURALES['Ciencias de la Naturaleza']
};

export const KHAN_EXERCISES_POR_CURSO = {
    '4º Primaria': COMPLETO_4_PRIMARIA,
    '5º Primaria': COMPLETO_5_PRIMARIA,

    '1º ESO': {
        'Matemáticas': {
            'Fracciones': {
                source: 'Khan Academy',
                url: 'https://es.khanacademy.org/math/arithmetic/fraction-arithmetic',
                nivel: '1º ESO',
                ejercicios: [] // Ya tenemos estos en el banco general
            }
        }
    }
};

/**
 * Obtener ejercicios por CURSO y tema
 * Con coincidencia parcial/fuzzy para mejorar el matching
 */
export async function getKhanExercisesPorCurso({ curso, asignatura, tema, cantidad = 10 }) {
    console.log(`🎓 Buscando ejercicios de Khan Academy: ${curso} - ${asignatura} - ${tema}`);

    // Buscar en la estructura por curso
    const cursoDB = KHAN_EXERCISES_POR_CURSO[curso];
    if (!cursoDB) {
        console.log(`⚠️ No hay contenido para ${curso}`);
        return null;
    }

    const asignaturaDB = cursoDB[asignatura];
    if (!asignaturaDB) {
        console.log(`⚠️ No hay ${asignatura} para ${curso}`);
        return null;
    }

    // Intentar coincidencia EXACTA primero
    let temaDB = asignaturaDB[tema];
    let temaEncontrado = tema;

    // Si no hay coincidencia exacta, intentar coincidencia PARCIAL (fuzzy matching)
    if (!temaDB || !temaDB.ejercicios || temaDB.ejercicios.length === 0) {
        console.log(`⚠️ No hay coincidencia exacta para "${tema}", intentando coincidencia parcial...`);

        // Normalizar tema de búsqueda
        const temaNormalizado = tema.toLowerCase().trim();

        // Buscar coincidencia parcial en los temas disponibles
        const temaKey = Object.keys(asignaturaDB).find(key => {
            const keyNormalizado = key.toLowerCase().trim();
            // Coincide si uno contiene al otro
            return keyNormalizado.includes(temaNormalizado) || temaNormalizado.includes(keyNormalizado);
        });

        if (temaKey) {
            console.log(`✅ Coincidencia parcial encontrada: "${tema}" → "${temaKey}"`);
            temaDB = asignaturaDB[temaKey];
            temaEncontrado = temaKey;
        }
    }

    // Si aún no hay contenido, retornar null
    if (!temaDB || !temaDB.ejercicios || temaDB.ejercicios.length === 0) {
        console.log(`⚠️ No hay ejercicios de "${tema}" para ${curso}`);
        console.log(`📋 Temas disponibles: ${Object.keys(asignaturaDB).join(', ')}`);
        return null;
    }

    console.log(`✅ Encontrados ${temaDB.ejercicios.length} ejercicios de "${temaEncontrado}" para ${curso}`);

    return {
        source: 'KHAN_ACADEMY',
        url_oficial: temaDB.url,
        nivel: temaDB.nivel,
        total_disponibles: temaDB.ejercicios.length,
        ejercicios: temaDB.ejercicios.slice(0, cantidad),
        metadata: {
            curso,
            asignatura,
            tema: temaEncontrado, // Usar el tema real encontrado
            tema_original: tema, // Guardar el tema original buscado
            cantidad: Math.min(temaDB.ejercicios.length, cantidad)
        }
    };
}

/**
 * Verificar si hay contenido para un curso específico
 */
export function hasKhanContentPorCurso(curso, asignatura, tema) {
    const cursoDB = KHAN_EXERCISES_POR_CURSO[curso];
    if (!cursoDB) return false;

    const asignaturaDB = cursoDB[asignatura];
    if (!asignaturaDB) return false;

    const temaDB = asignaturaDB[tema];
    return !!(temaDB && temaDB.ejercicios && temaDB.ejercicios.length > 0);
}

/**
 * Listar todos los temas disponibles para un curso
 */
export function getTemasDisponiblesPorCurso(curso, asignatura) {
    const cursoDB = KHAN_EXERCISES_POR_CURSO[curso];
    if (!cursoDB) return [];

    const asignaturaDB = cursoDB[asignatura];
    if (!asignaturaDB) return [];

    return Object.keys(asignaturaDB);
}

export default {
    KHAN_EXERCISES_POR_CURSO,
    getKhanExercisesPorCurso,
    hasKhanContentPorCurso,
    getTemasDisponiblesPorCurso
};
