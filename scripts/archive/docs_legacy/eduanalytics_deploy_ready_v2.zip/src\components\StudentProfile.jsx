import React, { useState, useEffect, useRef } from 'react';
import { supabase } from '../supabaseClient';
import { useNavigate } from 'react-router-dom';
import {
    Camera, Save, Loader2, User, BookOpen, Brain,
    MoreHorizontal, LogOut, Star, Sparkles, Plus, Trash2,
    Search, TrendingUp, Heart, ThumbsUp, ThumbsDown, MessageSquare,
    Settings, Layout, UserCircle, X, Key
} from 'lucide-react';
import EarlyDetectionPrimary from './EarlyDetectionPrimary';
import EarlyDetectionSecondary from './EarlyDetectionSecondary';
import EarlyDetectionGames from './EarlyDetectionGames';
import StudentInsightsDashboard from './StudentInsightsDashboard';
import RadarChart from './RadarChart';

const StudentProfile = () => {
    const [students, setStudents] = useState([]);
    const [selectedStudent, setSelectedStudent] = useState(null);
    const [isEditing, setIsEditing] = useState(false);
    const [loading, setLoading] = useState(true);
    const [saving, setSaving] = useState(false);
    const [screeningView, setScreeningView] = useState(null);
    const fileInputRef = useRef(null);
    const [apiKeys, setApiKeys] = useState({
        GEMINI_API_KEY: localStorage.getItem('GEMINI_API_KEY') || '',
        SAMBANOVA_API_KEY: localStorage.getItem('SAMBANOVA_API_KEY') || '',
        OPENROUTER_API_KEY: localStorage.getItem('OPENROUTER_API_KEY') || ''
    });

    const [learningProfile, setLearningProfile] = useState({
        vark_scores: { v: 0.25, a: 0.25, r: 0.25, k: 0.25 },
        multiple_intelligences: {
            linguistic: 0.5, logical: 0.5, spatial: 0.5, kinesthetic: 0.5,
            musical: 0.5, interpersonal: 0.5, intrapersonal: 0.5, naturalistic: 0.5
        },
        cognitive_traits: {
            attention: 'normal',
            processing_speed: 'normal',
            persistence: 'normal'
        },
        confidence_score: 0.5
    });

    // Alias to maintain compatibility with existing code using userData
    const userData = selectedStudent;
    const setUserData = setSelectedStudent;

    const navigate = useNavigate();

    const isSoft = selectedStudent?.education_level === 'primaria' || !selectedStudent;
    const isRobust = selectedStudent?.education_level === 'eso' || selectedStudent?.education_level === 'bachillerato';

    const theme = {
        card: isSoft
            ? 'rounded-[50px] shadow-2xl shadow-indigo-100/50 border-none bg-white overflow-hidden'
            : 'rounded-[40px] border border-slate-200 shadow-xl overflow-hidden bg-white',
        accent: 'bg-gradient-to-br from-indigo-700 via-blue-800 to-slate-900',
        bg: isSoft ? 'bg-indigo-50/20' : 'bg-slate-50',
        input: isSoft
            ? 'rounded-3xl bg-white border border-indigo-100/50 shadow-sm focus:ring-4 focus:ring-indigo-100 transition-all font-bold text-sm'
            : 'rounded-2xl bg-white border-2 border-slate-100 focus:border-indigo-500 focus:ring-0 transition-all font-bold text-sm'
    };

    const educationLevels = [
        { id: 'primaria', label: 'Primaria' },
        { id: 'eso', label: 'ESO' },
        { id: 'bachillerato', label: 'Bachillerato' }
    ];

    const gradesByLevel = {
        'primaria': ['1º Primaria', '2º Primaria', '3º Primaria', '4º Primaria', '5º Primaria', '6º Primaria'],
        'eso': ['1º ESO', '2º ESO', '3º ESO', '4º ESO'],
        'bachillerato': ['1º Bachillerato', '2º Bachillerato']
    };

    const learningStyles = [
        { id: 'visual', label: 'Canal Visual', desc: 'Retención mediante imágenes y esquemas', icon: '👁️' },
        { id: 'auditivo', label: 'Canal Auditivo', desc: 'Procesamiento por escucha activa', icon: '👂' },
        { id: 'kinestesico', label: 'Lógica Vivencial', desc: 'Aprendizaje por acción y experiencia', icon: '✋' },
        { id: 'lectura', label: 'Análisis Lector', desc: 'Comprensión profunda por texto', icon: '📖' }
    ];

    useEffect(() => {
        fetchProfile();
    }, []);

    const fetchProfile = async () => {
        try {
            const { data: { user } } = await supabase.auth.getUser();
            if (!user) { navigate('/'); return; }

            const { data: studentsData, error } = await supabase.from('students').select('*').eq('parent_id', user.id);
            if (error) throw error;

            if (studentsData && studentsData.length > 0) {
                setStudents(studentsData);
                const firstStudent = studentsData[0];
                if (!selectedStudent) {
                    setSelectedStudent(firstStudent);
                    fetchLearningProfile(firstStudent.id);
                }
            } else {
                setStudents([]);
                setSelectedStudent({
                    full_name: '',
                    education_level: 'primaria',
                    grade_level: '',
                    editorial_math: 'Santillana',
                    editorial_language: 'Santillana',
                    editorial_science: 'Santillana',
                    editorial_english: 'Go Far',
                    challenge_level: 'standard',
                    interests: '',
                    learning_style: 'visual',
                    avatar_url: null
                });
                setIsEditing(true);
            }
        } catch (error) {
            console.error('Error in fetchProfile:', error);
        } finally {
            setLoading(false);
        }
    };

    const fetchLearningProfile = async (studentId) => {
        try {
            const { data, error } = await supabase
                .from('learning_profiles')
                .select('*')
                .eq('student_id', studentId)
                .maybeSingle();

            if (data) {
                setLearningProfile({
                    ...learningProfile,
                    ...data
                });
            }
        } catch (err) {
            console.error("Error fetching learning profile:", err);
        }
    };

    const handleAvatarClick = () => {
        if (fileInputRef.current) fileInputRef.current.click();
    };

    const handleFileUpload = async (e) => {
        const file = e.target.files[0];
        if (!file) return;

        try {
            setSaving(true);
            const reader = new FileReader();
            reader.onload = (uploadEvent) => {
                setSelectedStudent({ ...selectedStudent, avatar_url: uploadEvent.target.result });
                setSaving(false);
            };
            reader.readAsDataURL(file);

            // Si quieres guardar permanentemente en Supabase, necesitaríamos un bucket
            // Por ahora lo guardamos como Base64 para que funcione inmediato
        } catch (err) {
            console.error(err);
            setSaving(false);
        }
    };

    const guessLevel = (grade) => {
        if (!grade) return 'primaria';
        if (grade.includes('Primaria')) return 'primaria';
        if (grade.includes('ESO')) return 'eso';
        if (grade.includes('Bachillerato')) return 'bachillerato';
        return 'primaria';
    };

    const handleDelete = async (studentId, studentName) => {
        if (!window.confirm(`¿Seguro que quieres borrar el perfil de ${studentName}? Esta acción no se puede deshacer.`)) return;

        try {
            setSaving(true);
            console.log('🗑️ Intentando borrar estudiante:', studentId);
            const { error } = await supabase.from('students').delete().eq('id', studentId);

            if (error) {
                console.error('❌ Error de Supabase al borrar:', error);
                throw error;
            }

            console.log('✅ Estudiante borrado con éxito');
            alert('Perfil borrado correctamente.');
            fetchProfile();
        } catch (error) {
            console.error('❌ Fallo en handleDelete:', error);
            alert('Error al borrar: ' + error.message);
        } finally {
            setSaving(false);
        }
    };

    const handleSave = async (e) => {
        if (e) e.preventDefault();
        setSaving(true);
        try {
            const { data: { user } } = await supabase.auth.getUser();
            if (!user) throw new Error("No hay sesión de usuario");

            // 1. Guardar Estudiante
            const { data: savedStudent, error: studentError } = await supabase
                .from('students')
                .upsert({
                    ...selectedStudent,
                    parent_id: user.id
                })
                .select()
                .single();

            if (studentError) throw studentError;

            // 2. Guardar Perfil de Aprendizaje Profundo
            const { error: profileError } = await supabase
                .from('learning_profiles')
                .upsert({
                    student_id: savedStudent.id,
                    vark_scores: learningProfile.vark_scores,
                    vark_dominant: selectedStudent.learning_style,
                    multiple_intelligences: learningProfile.multiple_intelligences,
                    cognitive_traits: learningProfile.cognitive_traits,
                    confidence_score: learningProfile.confidence_score,
                    last_updated: new Date().toISOString()
                }, { onConflict: 'student_id' });

            if (profileError) {
                console.warn("Error saving learning profile (did you run expand_learning_profile.sql?):", profileError);
            }

            // 3. Guardar Keys
            localStorage.setItem('GEMINI_API_KEY', apiKeys.GEMINI_API_KEY);
            localStorage.setItem('SAMBANOVA_API_KEY', apiKeys.SAMBANOVA_API_KEY);
            localStorage.setItem('OPENROUTER_API_KEY', apiKeys.OPENROUTER_API_KEY);

            alert('¡Configuración completa de ' + (savedStudent.full_name || 'tu hijo') + ' guardada! 🧠');
            setIsEditing(false);
            fetchProfile();
        } catch (error) {
            alert(error.message);
        } finally { setSaving(false); }
    };

    if (loading) return (
        <div className="min-h-screen flex items-center justify-center bg-white">
            <Loader2 className="w-10 h-10 text-indigo-600 animate-spin" />
        </div>
    );

    return (
        <div className={`min-h-screen ${theme.bg} pb-20 font-sans`}>
            {/* Header Hero (ResourceHub Style) */}
            <div className="bg-gradient-to-br from-indigo-700 via-blue-800 to-slate-900 text-white py-20 px-6 overflow-hidden relative">
                {/* Decorative Blobs */}
                <div className="absolute top-0 right-0 w-[500px] h-[500px] bg-blue-400/10 rounded-full blur-[100px] -mr-40 -mt-40 animate-pulse"></div>
                <div className="absolute bottom-0 left-0 w-[300px] h-[300px] bg-indigo-500/10 rounded-full blur-[80px] -ml-20 -mb-20"></div>

                <div className="max-w-6xl mx-auto flex flex-col md:flex-row items-center justify-between relative z-10">
                    <div className="mb-8 md:mb-0">
                        <div className="inline-flex items-center gap-2 px-4 py-2 bg-white/10 backdrop-blur-md rounded-full border border-white/20 mb-6">
                            <Sparkles className="w-4 h-4 text-yellow-300" />
                            <span className="text-xs font-bold uppercase tracking-widest text-blue-100">Panel de Control</span>
                        </div>
                        <h1 className="text-5xl font-extrabold tracking-tight mb-4">NeuroPerfil</h1>
                        <p className="text-xl text-blue-100/80 max-w-xl font-medium leading-relaxed">
                            Administra los perfiles de tus hijos y configura su experiencia de aprendizaje personalizada.
                        </p>
                    </div>

                    {/* Action Buttons */}
                    <div className="flex flex-col gap-3 min-w-[200px]">
                        {isEditing ? (
                            <button
                                onClick={() => setIsEditing(false)}
                                className="bg-white/10 hover:bg-white/20 text-white px-6 py-3 rounded-2xl font-black text-xs uppercase tracking-widest flex items-center gap-2 transition-all"
                            >
                                Volver a la lista
                            </button>
                        ) : (
                            <button
                                onClick={() => {
                                    setSelectedStudent({
                                        full_name: '',
                                        education_level: 'primaria',
                                        grade_level: '',
                                        editorial_math: 'Santillana',
                                        editorial_language: 'Santillana',
                                        editorial_science: 'Santillana',
                                        editorial_english: 'Go Far',
                                        challenge_level: 'standard',
                                        interests: '',
                                        learning_style: 'visual',
                                        avatar_url: null
                                    });
                                    setIsEditing(true);
                                }}
                                className="bg-indigo-600 hover:bg-indigo-700 text-white px-6 py-3 rounded-2xl font-black text-xs uppercase tracking-widest flex items-center gap-2 transition-all"
                            >
                                <Plus className="w-4 h-4" /> Añadir Hijo
                            </button>
                        )}

                    </div>
                </div>
            </div>

            {console.log('👥 RENDER ESTUDIANTES:', students)}
            <div className="max-w-6xl mx-auto px-4 -mt-6">
                {!isEditing ? (
                    <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
                        {students.map(child => (
                            <div key={child.id} className="bg-white rounded-[40px] p-8 shadow-xl shadow-slate-200 border border-slate-100 flex flex-col items-center group relative overflow-hidden">
                                <div className="absolute top-0 right-0 p-6 opacity-10 group-hover:opacity-20 transition-opacity">
                                    <User className="w-20 h-20" />
                                </div>
                                <div className="w-24 h-24 rounded-[35px] bg-indigo-50 flex items-center justify-center mb-6 overflow-hidden">
                                    {child.avatar_url ? (
                                        <img src={child.avatar_url} alt={child.full_name} className="w-full h-full object-cover" />
                                    ) : (
                                        <UserCircle className="w-12 h-12 text-indigo-400" />
                                    )}
                                </div>
                                <h3 className="text-xl font-black text-slate-800 mb-1">{child.full_name}</h3>
                                <p className="text-[10px] font-black uppercase tracking-widest text-indigo-600 bg-indigo-50 px-3 py-1 rounded-full mb-6">
                                    {child.grade_level}
                                </p>
                                <div className="w-full grid grid-cols-2 gap-3 mb-8">
                                    <div className="bg-slate-50 p-3 rounded-2xl text-center">
                                        <p className="text-[8px] font-black text-slate-400 uppercase">Editorial</p>
                                        <p className="text-xs font-bold text-slate-700">{child.editorial_math}</p>
                                    </div>
                                    <div className="bg-slate-50 p-3 rounded-2xl text-center">
                                        <p className="text-[8px] font-black text-slate-400 uppercase">Nivel</p>
                                        <p className="text-xs font-bold text-slate-700 capitalize">{child.challenge_level}</p>
                                    </div>
                                </div>
                                <div className="w-full">
                                    <button
                                        onClick={() => {
                                            setSelectedStudent(child);
                                            setScreeningView('DASHBOARD');
                                        }}
                                        className="w-full py-4 bg-indigo-50 text-indigo-600 rounded-2xl font-black text-[10px] uppercase tracking-widest hover:bg-indigo-100 transition-all flex items-center justify-center gap-2"
                                    >
                                        <TrendingUp className="w-3 h-3" /> Dashboard
                                    </button>
                                </div>
                                <div className="flex w-full gap-3 mt-3">
                                    <button
                                        onClick={() => {
                                            setSelectedStudent(child);
                                            setIsEditing(true);
                                        }}
                                        className="flex-1 py-4 bg-gradient-to-r from-blue-600 to-indigo-600 text-white rounded-2xl font-black text-xs uppercase tracking-widest hover:shadow-lg shadow-blue-500/30 transition-all flex items-center justify-center gap-2"
                                    >
                                        <Settings className="w-4 h-4" /> Configurar
                                    </button>
                                    <button
                                        onClick={(e) => {
                                            e.stopPropagation();
                                            handleDelete(child.id, child.full_name);
                                        }}
                                        className="p-4 bg-red-50 text-red-500 rounded-2xl hover:bg-red-100 transition-all"
                                        title="Borrar Perfil"
                                    >
                                        <Trash2 className="w-5 h-5" />
                                    </button>
                                </div>
                            </div>
                        ))}
                    </div>
                ) : (
                    <form onSubmit={handleSave} className="space-y-10">
                        {/* 1. SECCIÓN PRINCIPAL: IDENTIDAD */}
                        <div className={`bg-white ${theme.card} relative overflow-hidden`}>
                            <div className="p-8 md:p-12">
                                <div className="flex flex-col lg:grid lg:grid-cols-12 gap-12">
                                    <div className="lg:col-span-8 flex flex-col md:flex-row items-center gap-10">
                                        <div className="relative group cursor-pointer" onClick={handleAvatarClick}>
                                            <div className="w-36 h-36 rounded-[50px] overflow-hidden shadow-2xl border-4 border-white bg-gray-50 flex items-center justify-center">
                                                {selectedStudent?.avatar_url ? (
                                                    <img src={selectedStudent.avatar_url} alt="Avatar" className="w-full h-full object-cover" />
                                                ) : (
                                                    <UserCircle className="w-20 h-20 text-indigo-200" />
                                                )}
                                            </div>
                                            <div className="absolute inset-0 bg-black/20 rounded-[50px] opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center">
                                                <Camera className="text-white w-8 h-8" />
                                            </div>
                                            <p className="text-center text-[8px] font-bold text-slate-400 mt-2 uppercase tracking-widest">Cambiar Foto</p>
                                        </div>

                                        <div className="flex-1 space-y-6 w-full text-center md:text-left">
                                            <div className="space-y-4">
                                                <input
                                                    type="text"
                                                    placeholder="Nombre de tu hijo/a"
                                                    value={selectedStudent?.full_name || ''}
                                                    onChange={e => setSelectedStudent({ ...selectedStudent, full_name: e.target.value })}
                                                    className="w-full bg-transparent border-none text-4xl font-black text-gray-900 focus:ring-0 placeholder-gray-200 p-0"
                                                />
                                                <div className="flex flex-wrap items-center justify-center md:justify-start gap-3">
                                                    <select
                                                        value={selectedStudent.education_level}
                                                        onChange={e => setSelectedStudent({ ...selectedStudent, education_level: e.target.value })}
                                                        className="px-4 py-2 bg-blue-100 text-blue-700 rounded-2xl text-xs font-black uppercase tracking-widest border-none cursor-pointer"
                                                    >
                                                        {educationLevels.map(lvl => <option key={lvl.id} value={lvl.id}>{lvl.label}</option>)}
                                                    </select>
                                                    <select
                                                        value={selectedStudent.grade_level}
                                                        onChange={e => setSelectedStudent({ ...selectedStudent, grade_level: e.target.value })}
                                                        className="px-4 py-2 bg-purple-100 text-purple-700 rounded-2xl text-xs font-black uppercase tracking-widest border-none cursor-pointer"
                                                    >
                                                        <option value="">Seleccionar curso</option>
                                                        {gradesByLevel[selectedStudent.education_level]?.map(g => <option key={g} value={g}>{g}</option>)}
                                                    </select>
                                                </div>
                                            </div>
                                        </div>
                                    </div>

                                    <div className="lg:col-span-4 p-8 bg-indigo-50/50 rounded-[45px]">
                                        <h4 className="text-xs font-black uppercase tracking-widest text-indigo-600 mb-6">Configuración por Materia</h4>
                                        <div className="space-y-4">
                                            <input
                                                type="file"
                                                ref={fileInputRef}
                                                className="hidden"
                                                accept="image/*"
                                                onChange={handleFileUpload}
                                            />

                                            <div className="grid grid-cols-2 gap-4">
                                                {Object.entries(selectedStudent.subjects || {
                                                    'Matemáticas': selectedStudent.editorial_math || 'Santillana',
                                                    'Lengua': selectedStudent.editorial_language || 'Santillana',
                                                    'Ciencias': selectedStudent.editorial_science || 'Santillana',
                                                    'Inglés': selectedStudent.editorial_english || 'Go Far'
                                                }).map(([subject, editorial]) => (
                                                    <div key={subject} className="relative group">
                                                        <label className="text-[9px] font-black text-slate-400 uppercase mb-2 block flex justify-between">
                                                            {subject}
                                                            {!['Matemáticas', 'Lengua', 'Ciencias', 'Inglés'].includes(subject) && (
                                                                <button
                                                                    type="button"
                                                                    onClick={() => {
                                                                        const newSubjects = { ...selectedStudent.subjects };
                                                                        delete newSubjects[subject];
                                                                        setSelectedStudent({ ...selectedStudent, subjects: newSubjects });
                                                                    }}
                                                                    className="text-red-400 hover:text-red-600"
                                                                >
                                                                    <Trash2 className="w-3 h-3" />
                                                                </button>
                                                            )}
                                                        </label>
                                                        <select
                                                            value={editorial}
                                                            onChange={e => {
                                                                const currentSubjects = selectedStudent.subjects || {
                                                                    'Matemáticas': selectedStudent.editorial_math || 'Santillana',
                                                                    'Lengua': selectedStudent.editorial_language || 'Santillana',
                                                                    'Ciencias': selectedStudent.editorial_science || 'Santillana',
                                                                    'Inglés': selectedStudent.editorial_english || 'Go Far'
                                                                };
                                                                setSelectedStudent({
                                                                    ...selectedStudent,
                                                                    subjects: { ...currentSubjects, [subject]: e.target.value }
                                                                });
                                                            }}
                                                            className="w-full bg-white border-2 border-indigo-100 p-2 rounded-xl text-[10px] font-bold"
                                                        >
                                                            <option value="Santillana">Santillana</option>
                                                            <option value="SM">SM</option>
                                                            <option value="Anaya">Anaya</option>
                                                            <option value="Oxford">Oxford</option>
                                                            <option value="Cambridge">Cambridge</option>
                                                            <option value="Go Far">Go Far</option>
                                                            <option value="Standard">Otras</option>
                                                        </select>
                                                    </div>
                                                ))}
                                                <button
                                                    type="button"
                                                    onClick={() => {
                                                        const name = prompt('Nombre de la nueva asignatura (ej: Gallego, Francés...):');
                                                        if (name) {
                                                            const currentSubjects = selectedStudent.subjects || {
                                                                'Matemáticas': selectedStudent.editorial_math || 'Santillana',
                                                                'Lengua': selectedStudent.editorial_language || 'Santillana',
                                                                'Ciencias': selectedStudent.editorial_science || 'Santillana',
                                                                'Inglés': selectedStudent.editorial_english || 'Go Far'
                                                            };
                                                            setSelectedStudent({
                                                                ...selectedStudent,
                                                                subjects: { ...currentSubjects, [name]: 'Santillana' }
                                                            });
                                                        }
                                                    }}
                                                    className="col-span-2 py-2 border-2 border-dashed border-indigo-200 text-indigo-400 rounded-xl text-[10px] font-bold uppercase tracking-widest hover:bg-indigo-50 hover:border-indigo-300 transition-all flex items-center justify-center gap-2"
                                                >
                                                    <Plus className="w-4 h-4" /> Añadir Asignatura
                                                </button>
                                            </div>

                                            <div className="pt-4 border-t border-indigo-100">
                                                <label className="text-[10px] font-black text-slate-400 uppercase mb-2 block">Nivel de Reto General</label>
                                                <select
                                                    value={selectedStudent.challenge_level}
                                                    onChange={e => setSelectedStudent({ ...selectedStudent, challenge_level: e.target.value })}
                                                    className="w-full bg-white border-2 border-slate-900 p-3 rounded-2xl text-xs font-black uppercase tracking-widest"
                                                >
                                                    <option value="refuerzo">📉 Refuerzo</option>
                                                    <option value="standard">⚖️ Estándar</option>
                                                    <option value="ampliacion">🚀 Ampliación</option>
                                                </select>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>

                        {/* 2. CÓMO APRENDE */}
                        <div className={theme.card}>
                            <div className={`p-6 ${theme.accent} text-white flex items-center justify-between`}>
                                <div className="flex items-center gap-4">
                                    {isSoft ? <Brain className="w-6 h-6" /> : <span className="bg-yellow-400 text-black px-2 py-1 font-black">M</span>}
                                    <h3 className="font-black uppercase tracking-widest text-sm">
                                        Perfil de Aprendizaje
                                    </h3>
                                </div>
                                <div className="flex gap-2">
                                    <button
                                        type="button"
                                        onClick={() => setScreeningView('GAMES')}
                                        className="px-5 py-2 bg-white/20 text-white rounded-2xl text-[10px] font-black uppercase tracking-widest hover:scale-105 transition-all flex items-center gap-2"
                                    >
                                        <Sparkles className="w-3 h-3" /> Centro de Diagnóstico
                                    </button>
                                </div>
                            </div>
                            <div className="p-8 grid grid-cols-2 md:grid-cols-4 gap-6">
                                {learningStyles.map(style => (
                                    <button
                                        key={style.id}
                                        type="button"
                                        onClick={() => setSelectedStudent({ ...selectedStudent, learning_style: style.id })}
                                        className={`p-6 border-4 transition-all flex flex-col items-center text-center gap-3 rounded-3xl ${selectedStudent?.learning_style === style.id
                                            ? 'border-indigo-500 bg-indigo-50 text-indigo-700 scale-105 shadow-lg'
                                            : 'border-transparent bg-slate-50 text-slate-400 hover:bg-slate-100'
                                            }`}
                                    >
                                        <span className="text-3xl">{style.icon}</span>
                                        <div className="space-y-1">
                                            <div className="text-[11px] font-black uppercase tracking-tighter leading-none">{style.label}</div>
                                            <div className="text-[9px] opacity-70 leading-tight font-medium lowercase italic">{style.desc}</div>
                                        </div>
                                    </button>
                                ))}
                            </div>

                            {/* Explicación de estilos */}
                            <div className="px-8 pb-8">
                                <div className="bg-indigo-50/50 rounded-3xl p-4 border border-indigo-100">
                                    <h4 className="text-[10px] font-black uppercase text-indigo-600 mb-2 flex items-center gap-2">
                                        <Sparkles className="w-3 h-3" /> ¿Qué significa cada canal?
                                    </h4>
                                    <div className="grid md:grid-cols-2 gap-4 text-[9px] text-slate-600 leading-tight">
                                        <p><b>Visual:</b> La IA generará mapas mentales, esquemas y problemas con referencias visuales claras.</p>
                                        <p><b>Auditivo:</b> La IA incluirá textos narrativos y explicaciones que fluyen mejor al ser leídas en voz alta.</p>
                                        <p><b>Lógica Vivencial:</b> Se priorizarán problemas prácticos, experimentos y retos de movimiento/acción.</p>
                                        <p><b>Análisis Lector:</b> Se centrará en la comprensión profunda, textos ricos y análisis crítico detallado.</p>
                                    </div>
                                </div>
                            </div>
                        </div>

                        {/* 3. PERSONALIZACIÓN Y CONTEXTO */}
                        <div className="space-y-10">
                            {/* PARA PRIMARIA (ESTILO SUAVE) */}
                            {isSoft && (
                                <div className={`${theme.card} p-8 lg:p-12 space-y-12`}>
                                    <div className="grid lg:grid-cols-2 gap-10">
                                        <div className="space-y-5">
                                            <div className="flex items-center gap-3 text-indigo-600">
                                                <div className="p-2 bg-indigo-50 rounded-2xl"><Heart className="w-6 h-6 fill-indigo-500" /></div>
                                                <h3 className="text-xl font-black uppercase tracking-tighter">Pasiones e Intereses</h3>
                                            </div>
                                            <textarea
                                                value={userData.interests}
                                                onChange={e => setUserData({ ...userData, interests: e.target.value })}
                                                className={theme.input + " w-full min-h-[140px] p-6 focus:ring-indigo-200 outline-none"}
                                                placeholder="¿Qué le apasiona? (Dinosaurios, fútbol, dibujo...)"
                                            />
                                        </div>
                                        <div className="space-y-8">
                                            <div className="space-y-3">
                                                <div className="flex items-center gap-3 text-purple-600 uppercase text-xs font-black tracking-widest">
                                                    <ThumbsUp className="w-5 h-5" /> Lo que más motiva
                                                </div>
                                                <input type="text" value={userData.favorite_subjects} onChange={e => setUserData({ ...userData, favorite_subjects: e.target.value })} className={theme.input + " w-full p-4"} placeholder="Asignaturas favoritas..." />
                                            </div>
                                            <div className="space-y-3">
                                                <div className="flex items-center gap-3 text-slate-400 uppercase text-xs font-black tracking-widest">
                                                    <ThumbsDown className="w-5 h-5" /> Lo que menos gusta
                                                </div>
                                                <input type="text" value={userData.least_favorite_subjects} onChange={e => setUserData({ ...userData, least_favorite_subjects: e.target.value })} className={theme.input + " w-full p-4"} placeholder="Temas a evitar..." />
                                            </div>
                                        </div>
                                    </div>
                                    <div className="pt-8 border-t border-indigo-50 space-y-5">
                                        <div className="flex items-center gap-3 text-indigo-600">
                                            <div className="p-2 bg-indigo-50 rounded-2xl"><MessageSquare className="w-6 h-6" /></div>
                                            <h3 className="text-xl font-black uppercase tracking-tighter">Observaciones Familiares</h3>
                                        </div>
                                        <textarea value={userData.observations} onChange={e => setUserData({ ...userData, observations: e.target.value })} className={theme.input + " w-full min-h-[160px] p-6"} placeholder="Detalles que ayuden a la IA..." />
                                    </div>
                                </div>
                            )}

                            {/* PARA ESO/BACHILLERATO (ESTILO SUBWAY) */}
                            {isRobust && (
                                <div className="grid lg:grid-cols-2 gap-8">
                                    <div className={`bg-white ${theme.card} !border-orange-500`}>
                                        <div className="bg-orange-500 p-4 text-white flex items-center gap-3">
                                            <span className="bg-white text-orange-500 w-8 h-8 flex items-center justify-center font-black rounded-full">B</span>
                                            <h3 className="font-black uppercase tracking-widest text-xs">Pasiones e Intereses</h3>
                                        </div>
                                        <div className="p-6">
                                            <textarea value={userData.interests} onChange={e => setUserData({ ...userData, interests: e.target.value })} className={theme.input + " w-full min-h-[120px] p-4"} placeholder="Intereses y hobbies..." />
                                        </div>
                                    </div>
                                    <div className={`bg-white ${theme.card} !border-blue-600`}>
                                        <div className="bg-blue-600 p-4 text-white flex items-center gap-3">
                                            <span className="bg-white text-blue-600 w-8 h-8 flex items-center justify-center font-black rounded-full">A</span>
                                            <h3 className="font-black uppercase tracking-widest text-xs">Lo que más le motiva</h3>
                                        </div>
                                        <div className="p-6">
                                            <input type="text" value={userData.favorite_subjects} onChange={e => setUserData({ ...userData, favorite_subjects: e.target.value })} className={theme.input + " w-full p-4"} placeholder="Asignaturas excelentes..." />
                                        </div>
                                    </div>
                                    <div className={`bg-white ${theme.card} !border-red-600`}>
                                        <div className="bg-red-600 p-4 text-white flex items-center gap-3">
                                            <span className="bg-white text-red-600 w-8 h-8 flex items-center justify-center font-black rounded-full">1</span>
                                            <h3 className="font-black uppercase tracking-widest text-xs">Lo que no soporta</h3>
                                        </div>
                                        <div className="p-6">
                                            <input type="text" value={userData.least_favorite_subjects} onChange={e => setUserData({ ...userData, least_favorite_subjects: e.target.value })} className={theme.input + " w-full p-4"} placeholder="Temas de resistencia..." />
                                        </div>
                                    </div>
                                    <div className={`bg-white ${theme.card} !border-emerald-600`}>
                                        <div className="bg-emerald-600 p-4 text-white flex items-center gap-3">
                                            <span className="bg-white text-emerald-600 w-8 h-8 flex items-center justify-center font-black rounded-full">4</span>
                                            <h3 className="font-black uppercase tracking-widest text-xs">Observaciones Familia</h3>
                                        </div>
                                        <div className="p-6">
                                            <textarea value={userData.observations} onChange={e => setUserData({ ...userData, observations: e.target.value })} className={theme.input + " w-full min-h-[120px] p-4"} placeholder="Notas del entorno familiar..." />
                                        </div>
                                    </div>
                                </div>
                            )}

                            {/* 4. CONFIGURACIÓN DE IA (BYOK) */}
                            <div className={`bg-white ${theme.card} !border-indigo-600`}>
                                <div className={`p-6 bg-gradient-to-r from-blue-600 to-indigo-600 text-white flex items-center justify-between`}>
                                    <div className="flex items-center gap-4">
                                        <Key className="w-6 h-6 text-yellow-400" />
                                        <h3 className="font-black uppercase tracking-widest text-sm">Configuración de Inteligencia Artificial</h3>
                                    </div>
                                    <span className="bg-white/10 px-3 py-1 rounded-full text-[9px] font-black uppercase tracking-widest">Bring Your Own Key (BYOK)</span>
                                </div>
                                <div className="p-8 space-y-8">
                                    <div className="grid md:grid-cols-2 gap-10">
                                        <div className="space-y-4">
                                            <div className="flex items-center justify-between">
                                                <label className="text-xs font-black text-slate-500 uppercase tracking-widest">Google Gemini API Key (Recomendado)</label>
                                                <a href="https://aistudio.google.com/app/apikey" target="_blank" rel="noreferrer" className="text-[10px] text-indigo-500 font-bold hover:underline">Obtener gratis ↗</a>
                                            </div>
                                            <input
                                                type="password"
                                                value={apiKeys.GEMINI_API_KEY}
                                                onChange={e => setApiKeys({ ...apiKeys, GEMINI_API_KEY: e.target.value })}
                                                className={theme.input + " w-full p-4 pr-12"}
                                                placeholder="AIzaSy..."
                                            />
                                            <p className="text-[10px] text-slate-400 leading-relaxed italic">
                                                * Esta clave se guarda <b>solo en tu navegador</b>. Permite generar fichas y analizar perfiles de forma gratuita.
                                            </p>
                                        </div>

                                        <div className="space-y-4">
                                            <label className="text-xs font-black text-slate-500 uppercase tracking-widest block">OpenRouter API Key (Opcional)</label>
                                            <input
                                                type="password"
                                                value={apiKeys.OPENROUTER_API_KEY}
                                                onChange={e => setApiKeys({ ...apiKeys, OPENROUTER_API_KEY: e.target.value })}
                                                className={theme.input + " w-full p-4"}
                                                placeholder="sk-or-v1-..."
                                            />
                                            <p className="text-[10px] text-slate-400 leading-relaxed italic">
                                                * Usado como motor de respaldo si Gemini falla. Da acceso a GPT-4, Llama 3, etc.
                                            </p>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>

                        {/* Botones de acción finales */}
                        <div className="flex justify-end gap-4 pt-10">
                            <button type="button" onClick={() => setIsEditing(false)} className="px-10 py-5 rounded-2xl bg-slate-100 text-slate-500 font-black text-xs uppercase tracking-widest hover:bg-slate-200 transition-all">
                                Cancelar
                            </button>
                            <button type="submit" disabled={saving} className="px-10 py-5 rounded-2xl bg-gradient-to-r from-blue-600 to-indigo-600 text-white font-black text-xs uppercase tracking-[0.2em] hover:scale-105 transition-all flex items-center gap-3 shadow-lg shadow-blue-500/30">
                                {saving ? <Loader2 className="animate-spin w-4 h-4" /> : <Save className="w-5 h-5" />}
                                Guardar Hijo/a
                            </button>
                        </div>
                    </form>
                )
                }
            </div >

            {/* MODALS PERSISTENTES */}
            {
                screeningView && (
                    <div className="fixed inset-0 z-50 overflow-y-auto bg-gray-900/80 backdrop-blur-xl flex items-start justify-center p-4 py-10">
                        <div className="w-full max-w-[95vw] relative">
                            <div className="relative">
                                <button
                                    onClick={() => setScreeningView(null)}
                                    className="absolute -top-12 right-0 md:-right-12 text-white p-3 hover:bg-white/20 rounded-full transition-all bg-white/10 backdrop-blur-md shadow-lg"
                                    title="Volver al perfil"
                                >
                                    <X className="w-6 h-6" />
                                </button>
                                <div className="bg-transparent">
                                    {screeningView === 'QUESTIONNAIRE' ? (
                                        userData.education_level === 'primaria' ? (
                                            <EarlyDetectionPrimary studentId={userData.id} onComplete={(a) => a === 'GAMES' ? setScreeningView('GAMES') : setScreeningView(null)} />
                                        ) : (
                                            <EarlyDetectionSecondary studentId={userData.id} onComplete={() => setScreeningView(null)} />
                                        )
                                    ) : screeningView === 'GAMES' ? (
                                        <EarlyDetectionGames studentId={userData.id} onBack={() => setScreeningView('QUESTIONNAIRE')} />
                                    ) : (
                                        <StudentInsightsDashboard studentId={userData.id} onNavigate={setScreeningView} />
                                    )}
                                </div>
                            </div>
                        </div>
                    </div>
                )
            }
        </div >
    );
};

export default StudentProfile;
