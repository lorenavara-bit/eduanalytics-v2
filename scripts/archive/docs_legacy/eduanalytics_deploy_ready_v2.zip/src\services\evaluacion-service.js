// SERVICIO DE ANÁLISIS Y EVALUACIÓN EDUCATIVA
// Sistema completo de feedback para estudiantes y padres
// CON TAXONOMÍA AVANZADA DE ERRORES (TIER 1 & 2) + LOMLOE

import {
    PATRONES_ERROR_TIER1,
    CRITERIOS_LOMLOE,
    detectarPatronError,
    inferirCriterioDesdePregunta,
    generarFeedbackExcelencia
} from './taxonomia-errores-avanzada.js';

/**
 * ANÁLISIS DE RESPUESTAS Y GENERACIÓN DE FEEDBACK DETALLADO
 */

// Taxonomía de Bloom para clasificar preguntas
export const NIVELES_BLOOM = {
    RECORDAR: { nivel: 1, nombre: 'Recordar', descripcion: 'Memorizar y recordar información' },
    COMPRENDER: { nivel: 2, nombre: 'Comprender', descripcion: 'Explicar ideas o conceptos' },
    APLICAR: { nivel: 3, nombre: 'Aplicar', descripcion: 'Usar información en nuevas situaciones' },
    ANALIZAR: { nivel: 4, nombre: 'Analizar', descripcion: 'Distinguir entre diferentes partes' },
    EVALUAR: { nivel: 5, nombre: 'Evaluar', descripcion: 'Justificar una decisión' },
    CREAR: { nivel: 6, nombre: 'Crear', descripcion: 'Producir nuevo trabajo original' }
};

// ⭐ NUEVO: Perfiles de Procesamiento Cognitivo (Para entender "cómo funciona el cerebro del niño")
export const PERFILES_COGNITIVOS = {
    VISUAL_SPATIAL: {
        id: 'visual_spatial',
        nombre: 'Pensamiento Visual-Espacial',
        descripcion: 'Aprende mejor con imágenes, diagramas y mapas mentales.',
        senales: 'Falla en instrucciones largas de texto, pero acierta puzles o diagramas.',
        consejoPadres: 'Usad dibujos para explicarle matemáticas y subrayad con colores.'
    },
    SEQUENTIAL_VERBAL: {
        id: 'sequential_verbal',
        nombre: 'Procesamiento Secuencial-Verbal',
        descripcion: 'Aprende paso a paso a través de palabras y listas.',
        senales: 'Bueno memorizando textos, pero se pierde si el problema es muy abierto.',
        consejoPadres: 'Haced listas de pasos numerados para sus tareas diarias.'
    },
    WORKING_MEMORY_LOAD: {
        id: 'working_memory',
        nombre: 'Carga en Memoria de Trabajo',
        descripcion: 'Su cerebro "se llena" rápido con demasiada información a la vez.',
        senales: 'Olvida el principio de la frase al llegar al final; se frustra con tareas de varios pasos.',
        consejoPadres: 'Dividid las tareas en "micro-misiones". Una sola instrucción cada vez.'
    },
    CONCEPTUAL_GAP: {
        id: 'conceptual_gap',
        nombre: 'Brecha de Abstracción',
        descripcion: 'Le cuesta pasar de lo concreto a lo abstracto.',
        senales: 'Entiende que 2+2=4 con manzanas, pero no con símbolos.',
        consejoPadres: 'Usad objetos físicos (legos, garbanzos) tanto tiempo como necesite.'
    },
    EXECUTIVE_DYSFUNCTION: {
        id: 'executive_dysfunction',
        nombre: 'Dificultad en Función Ejecutiva',
        descripcion: 'Le cuesta planificar, organizar y empezar tareas.',
        senales: 'Sabe la respuesta pero no sabe por dónde empezar a escribir; se bloquea ante un papel en blanco.',
        consejoPadres: 'Ayudadle a "romper el hielo". Escribid la primera palabra juntos o haced la primera parte del problema con él.'
    },
    HIGH_COMPLEXITY_SEEKER: {
        id: 'high_complexity',
        nombre: 'Búsqueda de Alta Complejidad',
        descripcion: 'Su cerebro se "apaga" con tareas repetitivas o demasiado simples.',
        senales: 'Falla en preguntas fáciles por falta de atención, pero acierta las más difíciles y abstractas.',
        consejoPadres: 'Añadidle un "plus de dificultad" o un reto creativo a las tareas monótonas.'
    }
};

// Tipos de errores comunes
export const TIPOS_ERROR = {
    CONCEPTUAL: {
        id: 'conceptual',
        nombre: 'Error Conceptual',
        descripcion: 'No comprende el concepto fundamental',
        gravedad: 'alta',
        icono: '🧠'
    },
    PROCEDIMIENTO: {
        id: 'procedimiento',
        nombre: 'Error de Procedimiento',
        descripcion: 'Conoce el concepto pero aplica mal el proceso',
        gravedad: 'media',
        icono: '⚙️'
    },
    LECTURA: {
        id: 'lectura',
        nombre: 'Error de Lectura',
        descripcion: 'No lee correctamente el enunciado',
        gravedad: 'baja',
        icono: '📖'
    },
    CALCULO: {
        id: 'calculo',
        nombre: 'Error de Cálculo',
        descripcion: 'Error en operaciones matemáticas básicas',
        gravedad: 'baja',
        icono: '🔢'
    },
    ATENCION: {
        id: 'atencion',
        nombre: 'Error de Atención',
        descripcion: 'Descuido o falta de concentración',
        gravedad: 'baja',
        icono: '👀'
    },
    INCOMPLETO: {
        id: 'incompleto',
        nombre: 'Respuesta Incompleta',
        descripcion: 'La respuesta está parcialmente correcta',
        gravedad: 'media',
        icono: '📝'
    }
};

/**
 * Analizar una respuesta individual CON TAXONOMÍA AVANZADA
 */
export function analizarRespuesta(pregunta, respuestaUsuario, respuestaCorrecta, contexto = {}) {
    const analisis = {
        correcta: false,
        puntos: 0,

        // TIER 1: Patrón de error profesional
        patronError: null,
        patronConfianza: 0,

        // TIER 2: Criterio LOMLOE
        criterioLOMLOE: null,

        // Análisis tradicional (mantener compatibilidad)
        tipoError: null,
        nivelBloom: determinarNivelBloom(pregunta),

        feedback: '',
        feedbackExcelencia: '',
        recomendacion: '',
        planAccion: null,
        ejemploAdicional: null
    };

    // Normalizar respuestas para comparación
    const respuestaNormalizada = normalizarTexto(respuestaUsuario);
    const correctaNormalizada = normalizarTexto(respuestaCorrecta);

    // Verificar corrección
    const similitud = calcularSimilitud(respuestaNormalizada, correctaNormalizada);

    if (similitud >= 0.9) {
        // Respuesta correcta
        analisis.correcta = true;
        analisis.puntos = 1;
        analisis.feedback = generarFeedbackPositivo(pregunta.dificultad);

    } else if (similitud >= 0.5) {
        // Parcialmente correcta
        analisis.puntos = 0.5;
        analisis.tipoError = 'incompleto';
        analisis.patronError = 'ETF'; // Error de forma
        analisis.patronConfianza = 0.8;
        analisis.feedback = `Tu respuesta está parcialmente correcta. La respuesta completa debería ser: "${respuestaCorrecta}"`;
        analisis.recomendacion = 'Revisa que tu respuesta incluya todos los elementos necesarios.';

    } else if (!respuestaUsuario || respuestaUsuario.trim() === '') {
        // Sin respuesta
        analisis.tipoError = 'atencion';
        analisis.patronError = 'ETF'; // Error de forma/atención
        analisis.patronConfianza = 1.0;
        analisis.feedback = 'No has respondido esta pregunta.';
        analisis.recomendacion = 'Recuerda leer cada pregunta con atención y no dejar ninguna sin responder.';

    } else {
        // Incorrecta - USAR TAXONOMÍA AVANZADA

        // Detectar patrón de error profesional (TIER 1)
        const deteccionPatron = detectarPatronError(pregunta, respuestaUsuario, respuestaCorrecta, contexto);
        analisis.patronError = deteccionPatron.patron;
        analisis.patronConfianza = deteccionPatron.confianza;

        // Inferir criterio LOMLOE (TIER 2)
        if (contexto.asignatura && contexto.curso) {
            const criterioInferido = inferirCriterioDesdePregunta(pregunta, contexto.asignatura, contexto.curso);
            if (criterioInferido) {
                analisis.criterioLOMLOE = {
                    codigo: criterioInferido,
                    asignatura: contexto.asignatura,
                    curso: contexto.curso
                };
            }
        }

        // Generar feedback de excelencia
        analisis.feedbackExcelencia = generarFeedbackExcelencia({
            patron: analisis.patronError,
            criterio: analisis.criterioLOMLOE,
            pregunta: pregunta.pregunta || pregunta.text,
            respuestaUsuario,
            respuestaCorrecta
        });

        // Plan de acción específico
        const patronInfo = PATRONES_ERROR_TIER1[analisis.patronError];
        if (patronInfo) {
            analisis.planAccion = patronInfo.intervencion;
        }

        // Mantener feedback tradicional (compatibilidad)
        analisis.tipoError = identificarTipoError(pregunta, respuestaUsuario, respuestaCorrecta);
        analisis.feedback = generarFeedbackCorrectivo(pregunta, respuestaUsuario, respuestaCorrecta, analisis.tipoError);
        analisis.recomendacion = generarRecomendacion(pregunta, analisis.tipoError);
    }

    return analisis;
}

/**
 * Análisis completo de una ficha
 */
export function analizarFichaCompleta(preguntas, respuestas) {
    const resultados = {
        // Métricas básicas
        totalPreguntas: preguntas.length,
        correctas: 0,
        parciales: 0,
        incorrectas: 0,
        sinResponder: 0,
        puntuacion: 0,
        porcentaje: 0,

        // Análisis por dificultad
        porDificultad: {
            facil: { total: 0, correctas: 0, porcentaje: 0 },
            media: { total: 0, correctas: 0, porcentaje: 0 },
            dificil: { total: 0, correctas: 0, porcentaje: 0 }
        },

        // Análisis por nivel de Bloom
        porNivelBloom: {},

        // Patrones de error
        erroresPorTipo: {},
        erroresGraves: [],

        // Fortalezas y debilidades
        fortalezas: [],
        debilidades: [],

        // Recomendaciones
        recomendacionesGenerales: [],
        temasRepasar: [],
        temasReforzar: [],

        // Feedback personalizado
        mensajeEstudiante: '',
        mensajePadres: '',

        // Detalles por pregunta
        analisisDetallado: []
    };

    let puntosTotal = 0;

    // Analizar cada pregunta CON CONTEXTO
    preguntas.forEach((pregunta, index) => {
        const respuestaUsuario = respuestas[pregunta.id] || '';
        const respuestaCorrecta = pregunta.respuesta_correcta || pregunta.respuesta;

        // Contexto para taxonomía avanzada
        const contexto = {
            asignatura: resultados.asignatura || 'General',
            curso: resultados.curso || '4º Primaria'
        };

        const analisis = analizarRespuesta(pregunta, respuestaUsuario, respuestaCorrecta, contexto);
        resultados.analisisDetallado.push({
            pregunta: pregunta.pregunta,
            respuestaUsuario,
            respuestaCorrecta,
            ...analisis
        });

        // Actualizar métricas
        puntosTotal += analisis.puntos;

        if (analisis.correcta) {
            resultados.correctas++;
        } else if (analisis.puntos > 0) {
            resultados.parciales++;
        } else if (!respuestaUsuario || respuestaUsuario.trim() === '') {
            resultados.sinResponder++;
        } else {
            resultados.incorrectas++;
        }

        // Por dificultad
        const dif = pregunta.dificultad || 'media';
        if (resultados.porDificultad[dif]) {
            resultados.porDificultad[dif].total++;
            if (analisis.correcta) resultados.porDificultad[dif].correctas++;
        }

        // Por nivel Bloom
        const nivelBloom = analisis.nivelBloom;
        if (!resultados.porNivelBloom[nivelBloom]) {
            resultados.porNivelBloom[nivelBloom] = { total: 0, correctas: 0 };
        }
        resultados.porNivelBloom[nivelBloom].total++;
        if (analisis.correcta) resultados.porNivelBloom[nivelBloom].correctas++;

        // ⭐ NUEVO: Errores por PATRÓN (TIER 1)
        if (analisis.patronError) {
            if (!resultados.erroresPorPatron) {
                resultados.erroresPorPatron = {};
            }
            if (!resultados.erroresPorPatron[analisis.patronError]) {
                resultados.erroresPorPatron[analisis.patronError] = 0;
            }
            resultados.erroresPorPatron[analisis.patronError]++;
        }

        // ⭐ NUEVO: Criterios LOMLOE afectados (TIER 2)
        if (analisis.criterioLOMLOE) {
            if (!resultados.criteriosAfectados) {
                resultados.criteriosAfectados = [];
            }
            resultados.criteriosAfectados.push(analisis.criterioLOMLOE);
        }

        // Errores por tipo (mantener compatibilidad)
        if (analisis.tipoError) {
            if (!resultados.erroresPorTipo) {
                resultados.erroresPorTipo = {};
            }
            if (!resultados.erroresPorTipo[analisis.tipoError]) {
                resultados.erroresPorTipo[analisis.tipoError] = 0;
            }
            resultados.erroresPorTipo[analisis.tipoError]++;

            // Detectar errores críticos (EC - Conceptual)
            if (analisis.patronError === 'EC') {
                resultados.erroresGraves.push({
                    pregunta: pregunta.pregunta,
                    tema: pregunta.tema || 'general',
                    patronError: 'EC',
                    criterioLOMLOE: analisis.criterioLOMLOE,
                    recomendacion: analisis.recomendacion
                });
            }
        }
    });

    // Calcular porcentajes
    resultados.puntuacion = puntosTotal;
    resultados.porcentaje = Math.round((puntosTotal / preguntas.length) * 100);

    // Calcular porcentajes por dificultad
    Object.keys(resultados.porDificultad).forEach(dif => {
        const data = resultados.porDificultad[dif];
        data.porcentaje = data.total > 0 ? Math.round((data.correctas / data.total) * 100) : 0;
    });

    // Identificar fortalezas y debilidades
    resultados.fortalezas = identificarFortalezas(resultados);
    resultados.debilidades = identificarDebilidades(resultados);

    // Generar recomendaciones
    resultados.recomendacionesGenerales = generarRecomendacionesGenerales(resultados);
    resultados.temasRepasar = identificarTemasRepasar(resultados);

    // Generar mensajes personalizados
    resultados.mensajeEstudiante = generarMensajeEstudiante(resultados);

    // ⭐ NUEVO: Análisis de Perfil Cognitivo
    resultados.perfilCognitivo = analizarPerfilCognitivo(resultados);

    resultados.mensajePadres = generarMensajePadres(resultados);

    return resultados;
}

/**
 * FUNCIONES AUXILIARES
 */

function normalizarTexto(texto) {
    if (!texto) return '';
    return texto
        .toLowerCase()
        .normalize('NFD')
        .replace(/[\u0300-\u036f]/g, '') // Quitar acentos
        .replace(/[^\w\s]/g, '') // Quitar puntuación
        .trim();
}

function calcularSimilitud(texto1, texto2) {
    if (texto1 === texto2) return 1;
    if (!texto1 || !texto2) return 0;

    // Similitud simple basada en palabras comunes
    const palabras1 = texto1.split(/\s+/);
    const palabras2 = texto2.split(/\s+/);

    let coincidencias = 0;
    palabras1.forEach(p1 => {
        if (palabras2.includes(p1)) coincidencias++;
    });

    return coincidencias / Math.max(palabras1.length, palabras2.length);
}

function determinarNivelBloom(pregunta) {
    const texto = (pregunta.pregunta || '').toLowerCase();

    // Palabras clave para cada nivel
    if (texto.match(/nombra|define|qu[eé] es|identifica|lista/)) return 'RECORDAR';
    if (texto.match(/explica|describe|resume|compara|diferencia/)) return 'COMPRENDER';
    if (texto.match(/calcula|resuelve|aplica|usa|demuestra/)) return 'APLICAR';
    if (texto.match(/analiza|examina|contrasta|relaciona/)) return 'ANALIZAR';
    if (texto.match(/eval[uú]a|justifica|critica|argumenta/)) return 'EVALUAR';
    if (texto.match(/crea|dise[ñn]a|construye|inventa/)) return 'CREAR';

    return 'COMPRENDER'; // Por defecto
}

function identificarTipoError(pregunta, respuestaUsuario, respuestaCorrecta) {
    // Lógica simple para identificar tipo de error
    const tipo = pregunta.tipo || 'short_answer';

    if (tipo === 'fill_blank' || tipo === 'multiple_choice') {
        return TIPOS_ERROR.LECTURA.id;
    }

    if (pregunta.pregunta.toLowerCase().includes('calcula') || pregunta.pregunta.toLowerCase().includes('cuanto')) {
        return TIPOS_ERROR.CALCULO.id;
    }

    if (respuestaUsuario.length < respuestaCorrecta.length / 2) {
        return TIPOS_ERROR.INCOMPLETO.id;
    }

    return TIPOS_ERROR.CONCEPTUAL.id;
}

function generarFeedbackPositivo(dificultad) {
    const mensajes = {
        facil: [
            '¡Excelente! Has demostrado que dominas este concepto.',
            '¡Muy bien! Respuesta correcta.',
            '¡Perfecto! Sigue así.'
        ],
        media: [
            '¡Muy bien! Has aplicado correctamente tus conocimientos.',
            '¡Excelente trabajo! Respuesta completa y correcta.',
            '¡Genial! Demuestras buena comprensión del tema.'
        ],
        dificil: [
            '¡Impresionante! Has resuelto una pregunta difícil correctamente.',
            '¡Fantástico! Excelente razonamiento y respuesta.',
            '¡Sobresaliente! Demuestras un dominio excepcional del tema.'
        ]
    };

    const nivel = dificultad || 'media';
    const opciones = mensajes[nivel] || mensajes.media;
    return opciones[Math.floor(Math.random() * opciones.length)];
}

function generarFeedbackCorrectivo(pregunta, respuestaUsuario, respuestaCorrecta, tipoError) {
    const errorInfo = TIPOS_ERROR[tipoError.toUpperCase()] || TIPOS_ERROR.CONCEPTUAL;

    return `${errorInfo.icono} **${errorInfo.nombre}**: ${errorInfo.descripcion}

**Tu respuesta:** ${respuestaUsuario || '(sin responder)'}
**Respuesta correcta:** ${respuestaCorrecta}

${pregunta.explicacion ? `💡 **Explicación:** ${pregunta.explicacion}` : ''}`;
}

function generarRecomendacion(pregunta, tipoError) {
    const recomendaciones = {
        conceptual: 'Te recomiendo repasar este concepto con tu profesor o padre/madre. Es importante entender bien la idea principal antes de continuar.',
        procedimiento: 'Revisa paso a paso cómo resolver este tipo de ejercicios. Practica con ejemplos similares.',
        lectura: 'Lee cada pregunta con mucha atención, subrayando las palabras clave.',
        calculo: 'Revisa tus cálculos con calma. Usa papel borrador para hacer las operaciones.',
        atencion: 'Tómate tu tiempo para leer y pensar antes de responder.',
        incompleto: 'Asegúrate de responder todas las partes de la pregunta.'
    };

    return recomendaciones[tipoError] || recomendaciones.conceptual;
}

function generarEjemploSimilar(pregunta) {
    // Aquí se podría generar un ejercicio similar
    // Por ahora, retornamos null
    return null;
}

function identificarFortalezas(resultados) {
    const fortalezas = [];

    // Buen rendimiento en preguntas difíciles
    if (resultados.porDificultad.dificil.porcentaje >= 70) {
        fortalezas.push({
            icono: '🏆',
            titulo: 'Excelente en preguntas complejas',
            descripcion: `Has acertado el ${resultados.porDificultad.dificil.porcentaje}% de las preguntas difíciles`
        });
    }

    // Buen rendimiento general
    if (resultados.porcentaje >= 80) {
        fortalezas.push({
            icono: '⭐',
            titulo: 'Muy buen dominio general',
            descripcion: `Has obtenido un ${resultados.porcentaje}% de aciertos`
        });
    }

    // Pocosanos
    if (resultados.sinResponder === 0) {
        fortalezas.push({
            icono: '✅',
            titulo: 'Completitud',
            descripcion: 'Has respondido todas las preguntas'
        });
    }

    return fortalezas;
}

function identificarDebilidades(resultados) {
    const debilidades = [];

    // Bajo rendimiento en algún tipo de dificultad
    Object.entries(resultados.porDificultad).forEach(([nivel, data]) => {
        if (data.total > 0 && data.porcentaje < 50) {
            debilidades.push({
                icono: '📚',
                titulo: `Dificultad con preguntas de nivel ${nivel}`,
                descripcion: `Solo has acertado el ${data.porcentaje}% en este nivel`,
                accion: `Practica más con ejercicios de dificultad ${nivel}`
            });
        }
    });

    // Errores conceptuales
    if (resultados.erroresGraves.length > 0) {
        debilidades.push({
            icono: '🧠',
            titulo: 'Conceptos fundamentales por reforzar',
            descripcion: `${resultados.erroresGraves.length} error(es) conceptual(es) detectado(s)`,
            accion: 'Necesitas repasar los conceptos básicos con un adulto o profesor'
        });
    }

    // Muchas preguntas sin responder
    if (resultados.sinResponder > resultados.totalPreguntas * 0.2) {
        debilidades.push({
            icono: '⏰',
            titulo: 'Gestión del tiempo',
            descripcion: `${resultados.sinResponder} preguntas sin responder`,
            accion: 'Organiza mejor tu tiempo y asegúrate de responder todas las preguntas'
        });
    }

    return debilidades;
}

function generarRecomendacionesGenerales(resultados) {
    const recomendaciones = [];

    if (resultados.porcentaje < 50) {
        recomendaciones.push({
            prioridad: 'alta',
            icono: '🆘',
            mensaje: 'Necesitas apoyo urgente en este tema. Pide ayuda a tu profesor o padre/madre.',
            accion: 'Sesión de repaso con un adulto'
        });
    } else if (resultados.porcentaje < 70) {
        recomendaciones.push({
            prioridad: 'media',
            icono: '📖',
            mensaje: 'Debes repasar los conceptos básicos para mejorar.',
            accion: 'Estudia 30 minutos diarios sobre este tema'
        });
    } else if (resultados.porcentaje < 90) {
        recomendaciones.push({
            prioridad: 'baja',
            icono: '💪',
            mensaje: 'Vas muy bien, pero puedes mejorar aún más.',
            accion: 'Practica con ejercicios adicionales para perfeccionar'
        });
    } else {
        recomendaciones.push({
            prioridad: 'info',
            icono: '🌟',
            mensaje: '¡Excelente trabajo! Dominas muy bien este tema.',
            accion: 'Puedes avanzar al siguiente nivel de dificultad'
        });
    }

    return recomendaciones;
}

function identificarTemasRepasar(resultados) {
    const temas = new Set();

    resultados.erroresGraves.forEach(error => {
        temas.add(error.tema);
    });

    return Array.from(temas);
}

function generarMensajeEstudiante(resultados) {
    let mensaje = '';

    if (resultados.porcentaje >= 90) {
        mensaje = `🌟 **¡Fantástico trabajo!**

Has obtenido un **${resultados.porcentaje}%** de aciertos. ¡Eres un estudiante excepcional!

${resultados.correctas} de ${resultados.totalPreguntas} respuestas correctas demuestran que:
✅ Comprendes muy bien los conceptos
✅ Estudias con dedicación
✅ Estás preparado para avanzar

**Sigue así y alcanzarás grandes metas. ¡Estamos muy orgullosos de ti!**`;
    } else if (resultados.porcentaje >= 70) {
        mensaje = `👍 **¡Buen trabajo!**

Has logrado un **${resultados.porcentaje}%** de aciertos. ¡Vas por buen camino!

${resultados.correctas} respuestas correctas de ${resultados.totalPreguntas} muestran que entiendes el tema.

**Para mejorar aún más:**
${resultados.debilidades.slice(0, 2).map(d => `• ${d.accion}`).join('\n')}

**Con un poco más de práctica, ¡serás excelente!**`;
    } else if (resultados.porcentaje >= 50) {
        mensaje = `📚 **Necesitas repasar**

Has obtenido un **${resultados.porcentaje}%**. Has aprendido algunas cosas, pero necesitas reforzar.

**No te preocupes, todos aprendemos a nuestro ritmo. Lo importante es:**
• Pedir ayuda cuando no entiendas algo
• Estudiar un poco cada día
• No rendirte, ¡tú puedes!

**Tus padres y profesores están aquí para ayudarte. ¡Adelante!**`;
    } else {
        mensaje = `🆘 **Necesitas apoyo**

Has obtenido un **${resultados.porcentaje}%**. Este tema te está costando y necesitas ayuda.

**Esto es normal y le pasa a muchos estudiantes. Lo importante es:**
• Hablar con tu profesor o padre/madre
• Pedir que te expliquen de nuevo los concepts
• Practicar con ejercicios más sencillos primero

**¡No estás solo! Con ayuda y esfuerzo, lo conseguirás.**`;
    }

    return mensaje;
}

function generarMensajePadres(resultados) {
    let mensaje = `# Informe para Padres/Tutores

## Resumen General
${generarResumenGeneral(resultados)}

${resultados.perfilCognitivo ? `
## 🧠 La Brújula del Aprendizaje (Cómo aprende su hijo/a)
**Perfil Detectado:** ${resultados.perfilCognitivo.nombre}

**¿Qué significa?**
${resultados.perfilCognitivo.descripcion}

**💡 Consejo para evitar la frustración:**
${resultados.perfilCognitivo.consejoPadres}
` : ''}

## Análisis Detallado
${generarAnalisisDetallado(resultados)}

## Recomendaciones para el Hogar
${generarRecomendacionesPadres(resultados)}

## Próximos Pasos
${generarProximosPasos(resultados)}`;

    return mensaje;
}

function generarResumenGeneral(resultados) {
    return `
Su hijo/a ha completado una ficha de evaluación con los siguientes resultados:

**Puntuación:** ${resultados.puntuacion}/${resultados.totalPreguntas} (${resultados.porcentaje}%)
**Nivel:** ${obtenerNivelRendimiento(resultados.porcentaje)}

📊 **Desglose:**
- ✅ Correctas: ${resultados.correctas}
- ⚠️ Parcialmente correctas: ${resultados.parciales}
- ❌ Incorrectas: ${resultados.incorrectas}
- ⭕ Sin responder: ${resultados.sinResponder}
`;
}

function generarAnalisisDetallado(resultados) {
    return `
**Por nivel de dificultad:**
- Fácil: ${resultados.porDificultad.facil.porcentaje}% de aciertos
- Media: ${resultados.porDificultad.media.porcentaje}% de aciertos  
- Difícil: ${resultados.porDificultad.dificil.porcentaje}% de aciertos

**Fortalezas identificadas:**
${resultados.fortalezas.map(f => `• ${f.titulo}: ${f.descripcion}`).join('\n') || '• Aún no se han identificado fortalezas claras'}

**Áreas de mejora:**
${resultados.debilidades.map(d => `• ${d.titulo}: ${d.descripcion}`).join('\n') || '• No se detectaron debilidades significativas'}

${resultados.erroresGraves.length > 0 ? `
**⚠️ Atención especial requerida:**
Su hijo/a ha presentado errores conceptuales en:
${resultados.erroresGraves.map(e => `• ${e.tema}: ${e.recomendacion}`).join('\n')}
` : ''}
`;
}

function generarRecomendacionesPadres(resultados) {
    if (resultados.porcentaje >= 80) {
        return `
✅ **Su hijo/a está rindiendo muy bien**. Para mantener este nivel:
• Felicítele por su esfuerzo y dedicación
• Mantenga una rutina de estudio regular
• Proporcione desafíos adicionales si muestra interés
• Fomente la lectura relacionada con estos temas
`;
    } else if (resultados.porcentaje >= 60) {
        return `
📚 **Su hijo/a necesita refuerzo**. Recomendamos:
• Dedicar 30 minutos diarios al repaso
• Repasar juntos los conceptos básicos
• Hacer ejercicios similares adicionales
• Contactar con el profesor para orientación específica
• Elogiar los pequeños progresos para mantener la motivación
`;
    } else {
        return `
🆘 **Su hijo/a necesita apoyo urgente**. Es importante:
• Programar sesiones de estudio diarias (45-60 min)
• Solicitar una reunión con el profesor/a
• Considerar apoyo educativo adicional
• Romper los conceptos en partes más pequeñas
• Asegurar que comprende lo básico antes de avanzar
• **Mantener una actitud positiva y paciente**
`;
    }
}

function generarProximosPasos(resultados) {
    const pasos = [];

    if (resultados.temasRepasar.length > 0) {
        pasos.push(`📖 Repasar: ${resultados.temasRepasar.join(', ')}`);
    }

    if (resultados.porcentaje < 70) {
        pasos.push('📅 Establecer un horario de estudio regular');
        pasos.push('👥 Considerar estudio en grupo o tutoría');
    }

    if (resultados.erroresGraves.length > 0) {
        pasos.push('🔍 Revisar conceptos fundamentales con el profesor');
    }

    if (resultados.porcentaje >= 80) {
        pasos.push('🚀 Explorar material de nivel avanzado');
        pasos.push('🎯 Establecer nuevos objetivos de learning');
    }

    return pasos.map((p, i) => `${i + 1}. ${p}`).join('\n');
}

function obtenerNivelRendimiento(porcentaje) {
    if (porcentaje >= 90) return '⭐ Excelente';
    if (porcentaje >= 80) return '😊 Muy Bueno';
    if (porcentaje >= 70) return '👍 Bueno';
    if (porcentaje >= 60) return '📚 Suficiente';
    if (porcentaje >= 50) return '⚠️ Insuficiente';
    return '🆘 Necesita Apoyo Urgente';
}

/**
 * ⭐ NUEVO: Analizar el perfil cognitivo basado en el patrón de aciertos/errores
 */
function analizarPerfilCognitivo(resultados) {
    const { porNivelBloom, erroresPorTipo } = resultados;

    // 1. Detectar embotellamiento de Memoria de Trabajo
    // (Acierta Recordar, pero falla sistemáticamente en Aplicar/Analizar)
    const recordarAcc = porNivelBloom.RECORDAR?.total > 0 ? (porNivelBloom.RECORDAR.correctas / porNivelBloom.RECORDAR.total) : 0;
    const aplicarAcc = porNivelBloom.APLICAR?.total > 0 ? (porNivelBloom.APLICAR.correctas / porNivelBloom.APLICAR.total) : 0;

    if (recordarAcc > 0.7 && aplicarAcc < 0.3) {
        return PERFILES_COGNITIVOS.WORKING_MEMORY_LOAD;
    }

    // 2. Detectar Brecha Conceptual
    if (erroresPorTipo.conceptual > resultados.totalPreguntas * 0.4) {
        return PERFILES_COGNITIVOS.CONCEPTUAL_GAP;
    }

    // 3. Predicción por tipo de error dominante
    if (erroresPorTipo.lectura > erroresPorTipo.calculo && erroresPorTipo.lectura > 2) {
        return PERFILES_COGNITIVOS.VISUAL_SPATIAL; // A menudo los visuales fallan en lectura densa
    }

    if (recordarAcc > 0.8 && resultados.porcentaje > 60) {
        return PERFILES_COGNITIVOS.SEQUENTIAL_VERBAL;
    }

    // 4. Detectar Búsqueda de Complejidad (Típico AACC)
    if (resultados.porDificultad.dificil.porcentaje > resultados.porDificultad.facil.porcentaje + 20) {
        return PERFILES_COGNITIVOS.HIGH_COMPLEXITY_SEEKER;
    }

    // 5. Detectar Disfunción Ejecutiva (Muchos errores de atención/sin responder en alguien que acierta lo difícil)
    if (resultados.sinResponder > 2 && resultados.porDificultad.media.porcentaje > 70) {
        return PERFILES_COGNITIVOS.EXECUTIVE_DYSFUNCTION;
    }

    return null;
}

export default {
    analizarRespuesta,
    analizarFichaCompleta,
    NIVELES_BLOOM,
    TIPOS_ERROR
};
