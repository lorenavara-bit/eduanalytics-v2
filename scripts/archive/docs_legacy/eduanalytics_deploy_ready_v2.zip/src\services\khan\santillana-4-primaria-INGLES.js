// CONTENIDO SANTILLANA 4º PRIMARIA - INGLÉS (ENGLISH)
// Basado en el temario típico de Santillana
// Creado para niños de 9 años

export const SANTILLANA_INGLES_4 = {
    'Inglés': {
        'Present Simple': {
            source: 'Santillana 4º Primaria - English',
            nivel: '4º Primaria',
            ejercicios: [
                { tipo: 'Concepto', ejercicio: 'What is the Present Simple?', respuesta: 'A verb tense for habits and routines', explicacion: 'We use it for things we do every day' },
                { tipo: 'Afirmativa', ejercicio: 'Complete: I ____ (play) football every day', respuesta: 'play', explicacion: 'I/you/we/they + verb' },
                { tipo: 'He/She/It', ejercicio: 'Complete: She ____ (play) tennis', respuesta: 'plays', explicacion: 'He/she/it + verb + S' },
                { tipo: 'Negativa', ejercicio: 'Make negative: I like pizza', respuesta: "I don't like pizza", explicacion: "I/you/we/they + don't + verb" },
                { tipo: 'Negativa 3ª', ejercicio: 'Make negative: She likes pizza', respuesta: "She doesn't like pizza", explicacion: "He/she/it + doesn't + verb" },
                { tipo: 'Pregunta', ejercicio: 'Make a question: You like ice cream', respuesta: 'Do you like ice cream?', explicacion: 'Do + I/you/we/they + verb?' },
                { tipo: 'Pregunta 3ª', ejercicio: 'Make a question: He plays football', respuesta: 'Does he play football?', explicacion: 'Does + he/she/it + verb?' },
                { tipo: 'Respuesta corta', ejercicio: 'Do you like chocolate? (Yes)', respuesta: 'Yes, I do', explicacion: 'Yes/No + pronoun + do/does' },
                { tipo: 'Frecuencia', ejercicio: 'Put in order: always / I / breakfast / eat', respuesta: 'I always eat breakfast', explicacion: 'Adverb va antes del verbo' },
                { tipo: 'Aplicar', ejercicio: 'Complete: My brother ____ (watch) TV every day', respuesta: 'watches', explicacion: 'He watches (3ª persona + es)' },
                { tipo: 'Identificar', ejercicio: 'Is this correct? "She dont like apples"', respuesta: "No, it's: She doesn't like apples", explicacion: "doesn't (not dont)" },
                { tipo: 'Traducir', ejercicio: 'Translate: Yo juego al fútbol', respuesta: 'I play football', explicacion: 'I + play (no S)' }
            ]
        },

        'Present Continuous': {
            source: 'Santillana 4º Primaria - English',
            nivel: '4º Primaria',
            ejercicios: [
                { tipo: 'Concepto', ejercicio: 'What is the Present Continuous?', respuesta: 'For actions happening now', explicacion: 'We use it for things happening right now' },
                { tipo: 'Estructura', ejercicio: 'What is the structure? Subject + ...', respuesta: 'Subject + am/is/are + verb-ing', explicacion: 'Example: I am playing' },
                { tipo: 'Afirmativa', ejercicio: 'Complete: I ____ (play) now', respuesta: 'am playing', explicacion: 'I + am + verb-ing' },
                { tipo: 'Con He/She', ejercicio: 'Complete: She ____ (run) now', respuesta: 'is running', explicacion: 'He/she/it + is + verb-ing' },
                { tipo: 'Con They', ejercicio: 'Complete: They ____ (eat) now', respuesta: 'are eating', explicacion: 'We/you/they + are + verb-ing' },
                { tipo: 'Negativa', ejercicio: 'Make negative: I am playing', respuesta: "I'm not playing / I am not playing", explicacion: 'Add NOT after am/is/are' },
                { tipo: 'Pregunta', ejercicio: 'Make a question: You are reading', respuesta: 'Are you reading?', explicacion: 'Am/is/are + subject + verb-ing?' },
                { tipo: '-ing spelling', ejercicio: 'What is the -ing form of "swim"?', respuesta: 'swimming', explicacion: 'Double the M: swim → swimming' },
                { tipo: '-ing spelling 2', ejercicio: 'What is the -ing form of "make"?', respuesta: 'making', explicacion: 'Remove E: make → making' },
                { tipo: 'Now vs Always', ejercicio: 'Use Present Simple or Continuous: I ____ (eat) breakfast NOW', respuesta: 'am eating', explicacion: 'NOW = Present Continuous' },
                { tipo: 'Diferencia', ejercicio: '"I play" vs "I am playing". Which is NOW?', respuesta: 'I am playing', explicacion: 'Continuous = ahora, Simple = siempre' },
                { tipo: 'Aplicar', ejercicio: 'Look! The birds ____ (fly)', respuesta: 'are flying', explicacion: 'Look! = ahora → Continuous' }
            ]
        },

        'Past Simple (was/were)': {
            source: 'Santillana 4º Primaria - English',
            nivel: '4º Primaria',
            ejercicios: [
                { tipo: 'Was', ejercicio: 'Complete: I ____ happy yesterday', respuesta: 'was', explicacion: 'I/he/she/it + was' },
                { tipo: 'Were', ejercicio: 'Complete: They ____ at school yesterday', respuesta: 'were', explicacion: 'We/you/they + were' },
                { tipo: 'Negativa was', ejercicio: 'Make negative: I was tired', respuesta: "I wasn't tired / I was not tired", explicacion: 'was + not = wasn\'t' },
                { tipo: 'Negativa were', ejercicio: 'Make negative: They were happy', respuesta: "They weren't happy / They were not happy", explicacion: 'were + not = weren\'t' },
                { tipo: 'Pregunta', ejercicio: 'Make a question: You were at home', respuesta: 'Were you at home?', explicacion: 'Was/Were + subject + ...?' },
                { tipo: 'Respuesta', ejercicio: 'Were you at school? (Yes)', respuesta: 'Yes, I was', explicacion: 'Yes/No + pronoun + was/were' },
                { tipo: 'Elegir', ejercicio: 'I ____ (was/were) at the park', respuesta: 'was', explicacion: 'I + was' },
                { tipo: 'Elegir 2', ejercicio: 'We ____ (was/were) friends', respuesta: 'were', explicacion: 'We + were' },
                { tipo: 'Aplicar', ejercicio: 'The weather ____ (was/were) sunny yesterday', respuesta: 'was', explicacion: 'Weather es singular →was' },
                { tipo: 'Tiempo', ejercicio: 'Yesterday, last week, ago = Present or Past?', respuesta: 'Past', explicacion: 'Estas palabras indican pasado' },
                { tipo: 'Traducir', ejercicio: 'Translate: Yo estaba cansado', respuesta: 'I was tired', explicacion: 'I + was + tired' },
                { tipo: 'Corregir', ejercicio: 'Correct: She were happy', respuesta: 'She was happy', explicacion: 'She + was (no were)' }
            ]
        },

        'Vocabulary: Daily Routines': {
            source: 'Santillana 4º Primaria - English',
            nivel: '4º Primaria',
            ejercicios: [
                { tipo: 'Despertar', ejercicio: 'How do you say "despertarse"?', respuesta: 'Wake up', explicacion: 'I wake up at 7' },
                { tipo: 'Levantarse', ejercicio: 'How do you say "levantarse"?', respuesta: 'Get up', explicacion: 'I get up early' },
                { tipo: 'Ducharse', ejercicio: 'How do you say "ducharse"?', respuesta: 'Have a shower / Take a shower', explicacion: 'I have a shower' },
                { tipo: 'Vestirse', ejercicio: 'How do you say "vestirse"?', respuesta: 'Get dressed', explicacion: 'I get dressed quickly' },
                { tipo: 'Desayunar', ejercicio: 'How do you say "desayunar"?', respuesta: 'Have breakfast', explicacion: 'I have breakfast at 8' },
                { tipo: 'Ir al cole', ejercicio: 'How do you say "ir al colegio"?', respuesta: 'Go to school', explicacion: 'I go to school by bus' },
                { tipo: 'Almorzar', ejercicio: 'How do you say "comer/almorzar"?', respuesta: 'Have lunch', explicacion: 'I have lunch at 2' },
                { tipo: 'Hacer deberes', ejercicio: 'How do you say "hacer los deberes"?', respuesta: 'Do homework', explicacion: 'I do my homework' },
                { tipo: 'Cenar', ejercicio: 'How do you say "cenar"?', respuesta: 'Have dinner', explicacion: 'I have dinner at 8' },
                { tipo: 'Acostarse', ejercicio: 'How do you say "acostarse"?', respuesta: 'Go to bed', explicacion: 'I go to bed at 10' },
                { tipo: 'Aplicar', ejercicio: 'Complete: I ____ ____ at 7 o\'clock (despertarse)', respuesta: 'wake up', explicacion: 'I wake up at 7' },
                { tipo: 'Ordenar', ejercicio: 'Order: dinner / have / I / 8 / at', respuesta: 'I have dinner at 8', explicacion: 'Subject + verb + complement' }
            ]
        },

        'Vocabulary: School Subjects': {
            source: 'Santillana 4º Primaria - English',
            nivel: '4º Primaria',
            ejercicios: [
                { tipo: 'Matemáticas', ejercicio: 'How do you say "Matemáticas"?', respuesta: 'Maths / Mathematics', explicacion: 'I like Maths' },
                { tipo: 'Inglés', ejercicio: 'How do you say "Inglés" (la asignatura)?', respuesta: 'English', explicacion: 'I study English' },
                { tipo: 'Ciencias', ejercicio: 'How do you say "Ciencias"?', respuesta: 'Science', explicacion: 'I love Science' },
                { tipo: 'Educación Física', ejercicio: 'How do you say "Educación Física"?', respuesta: 'PE / Physical Education', explicacion: 'I have PE on Monday' },
                { tipo: 'Arte', ejercicio: 'How do you say "Arte/Plástica"?', respuesta: 'Art', explicacion: 'I enjoy Art' },
                { tipo: 'Música', ejercicio: 'How do you say "Música"?', respuesta: 'Music', explicacion: 'Music is fun' },
                { tipo: 'Historia', ejercicio: 'How do you say "Historia"?', respuesta: 'History', explicacion: 'I study History' },
                { tipo: 'Geografía', ejercicio: 'How do you say "Geografía"?', respuesta: 'Geography', explicacion: 'Geography is interesting' },
                { tipo: 'Aplicar', ejercicio: 'My favourite subject is ____ (Matemáticas)', respuesta: 'Maths', explicacion: 'My favourite subject is Maths' },
                { tipo: 'Preferencias', ejercicio: 'Complete: I ____ (like/don\'t like) English', respuesta: 'like / don\'t like', explicacion: 'Both are correct depending on your preference' },
                { tipo: 'Horario', ejercicio: 'Complete: I have ____ on Monday', respuesta: 'Ejemplo: Maths, English, PE...', explicacion: 'Name a school subject' },
                { tipo: 'Opinión', ejercicio: 'How do you say "difícil" (sobre una asignatura)?', respuesta: 'Difficult / Hard', explicacion: 'Maths is difficult' }
            ]
        },

        'Vocabulary: Food and Drinks': {
            source: 'Santillana 4º Primaria - English',
            nivel: '4º Primaria',
            ejercicios: [
                { tipo: 'Frutas', ejercicio: 'Name 3 fruits in English', respuesta: 'Apple, banana, orange, strawberry...', explicacion: 'Common fruits' },
                { tipo: 'Verduras', ejercicio: 'Name 3 vegetables in English', respuesta: 'Carrot, tomato, lettuce, potato...', explicacion: 'Common vegetables' },
                { tipo: 'Bebidas', ejercicio: 'Name 3 drinks in English', respuesta: 'Water, juice, milk, tea, coffee...', explicacion: 'Common drinks' },
                { tipo: 'Desayuno', ejercicio: 'What do you have for breakfast?', respuesta: 'Ejemplo: Cereal, toast, milk, juice', explicacion: 'Breakfast foods' },
                { tipo: 'Me gusta', ejercicio: 'Complete: I like ____  (algo de comida)', respuesta: 'Ejemplo: pizza, apples, chocolate', explicacion: 'I like + food' },
                { tipo: 'No me gusta', ejercicio: 'Complete: I don\'t like ____', respuesta: 'Ejemplo: vegetables, fish, soup', explicacion: "I don't like + food" },
                { tipo: 'Contable', ejercicio: 'Which is countable: "apple" or "milk"?', respuesta: 'Apple (you can count apples)', explicacion: 'Milk is uncountable' },
                { tipo: 'Some/Any', ejercicio: 'I have ____ apples (some/any)', respuesta: 'some', explicacion: 'Affirmative + some' },
                { tipo: 'Comida chatarra', ejercicio: 'Is pizza healthy or unhealthy?', respuesta: 'Unhealthy / junk food', explicacion: 'Pizza is not very healthy' },
                { tipo: 'Comida sana', ejercicio: 'Is an apple healthy or unhealthy?', respuesta: 'Healthy', explicacion: 'Fruit is healthy' },
                { tipo: 'Traducir', ejercicio: 'How do you say "tengo hambre"?', respuesta: "I'm hungry / I am hungry", explicacion: "I'm hungry (not I have hunger)" },
                { tipo: 'Traducir 2', ejercicio: 'How do you say "tengo sed"?', respuesta: "I'm thirsty / I am thirsty", explicacion: "I'm thirsty (not I have thirst)" }
            ]
        }
    }
};

export default { SANTILLANA_INGLES_4 };
