import React, { useState, useEffect, useRef } from 'react';
import { supabase } from '../supabaseClient';
import { useNavigate } from 'react-router-dom';
import { Loader2, Wand2, Book, Settings, Trash2, Plus, Save, Check, Printer, Download, AlertCircle, Sparkles, Calendar, User } from 'lucide-react';
import { generateSmartWorksheet, ContentSourceStats } from '../services/smart-worksheet-generator';
import { generateWorksheet as generateWithAIFallback, saveEvaluationResults } from '../utils/gemini';
import { analizarFichaCompleta } from '../services/evaluacion-service';
import InteractiveWorksheet from './InteractiveWorksheet';
import AuthPage from './AuthPage';
import ExamRoadmap from './ExamRoadmap'; // Import integrated component

import { getEnv } from '../utils/appEnv';

const WorksheetGenerator = () => {
    const navigate = useNavigate();
    const [mode, setMode] = useState('WORKSHEET'); // 'WORKSHEET' | 'ROADMAP'
    const [loading, setLoading] = useState(true);
    const [user, setUser] = useState(null);
    const [students, setStudents] = useState([]);
    const [selectedStudent, setSelectedStudent] = useState(null);
    const [subjects, setSubjects] = useState([]);
    const [selectedSubject, setSelectedSubject] = useState(null);

    const [addingSubject, setAddingSubject] = useState(false);
    const [newSubjectName, setNewSubjectName] = useState('');
    const [textbook, setTextbook] = useState('Santillana');

    const [topic, setTopic] = useState('');
    const [customerInterest, setCustomerInterest] = useState(''); // Minecraft, Espacio, Fútbol...

    const [generating, setGenerating] = useState(false);
    const [generatedContent, setGeneratedContent] = useState(null);
    const [saving, setSaving] = useState(false);

    const [activityType, setActivityType] = useState('practicar');
    const [difficulty, setDifficulty] = useState('Medio');
    const [challengeLevel, setChallengeLevel] = useState('standard');
    const [numQuestions, setNumQuestions] = useState(10);
    const [questionTypes, setQuestionTypes] = useState(['Test', 'Respuesta Corta']);

    const hasFetched = useRef(false);


    const DIFFICULTIES = ['Fácil', 'Medio', 'Difícil'];
    const QUESTION_OPTIONS = [
        { id: 'Test', label: 'Tipo Test' },
        { id: 'Respuesta Corta', label: 'Preguntas Cortas' },
        { id: 'Verdadero/Falso', label: 'Verdadero/Falso' },
        { id: 'Rellenar Huecos', label: 'Rellenar Huecos' },
        { id: 'Comprensión Lectora', label: '📖 Comprensión Lectora' },
        { id: 'Relacionar', label: 'Relacionar/Unir' },
        { id: 'Mapas', label: 'Mapas / Geografía' },
        { id: 'Diagramas', label: 'Diagramas' },
        { id: 'Problemas', label: 'Problemas Matemáticos' },
        { id: 'Casos Reales', label: 'Casos Reales' },
        { id: 'Definiciones', label: 'Definiciones' }
    ];

    useEffect(() => {
        if (!hasFetched.current) {
            hasFetched.current = true;
            fetchData();
        }
    }, []);

    const fetchData = async () => {
        try {
            setLoading(true);
            const { data: { user: authUser } } = await supabase.auth.getUser();
            if (!authUser) {
                setLoading(false);
                return;
            }

            setUser(authUser);

            // 1. Fetch children with RICH PROFILE (Tests & Screenings)
            const { data: kids, error: kidsError } = await supabase.from('students')
                .select(`
                    *,
                    learning_profiles (
                        vark_dominant,
                        vark_scores,
                        fs_active_reflective,
                        fs_sensing_intuitive,
                        fs_visual_verbal,
                        fs_sequential_global,
                        ai_summary
                    ),
                    nee_screenings (
                        risk_level,
                        recommendations,
                        created_at,
                        type
                    )
                `)
                .eq('parent_id', authUser.id);

            if (kidsError) throw kidsError;

            if (kids && kids.length > 0) {
                // Format joined data (Supabase returns arrays for 1:N)
                const formattedKids = kids.map(k => ({
                    ...k,
                    learning_profile: (k.learning_profiles && k.learning_profiles.length > 0) ? k.learning_profiles[0] : null,
                    nee_data: (k.nee_screenings && k.nee_screenings.length > 0)
                        ? k.nee_screenings.sort((a, b) => new Date(b.created_at || b.timestamp) - new Date(a.created_at || a.timestamp))[0]
                        : null,
                    all_screenings: k.nee_screenings || [] // Pass complete history for multi-test context
                }));

                setStudents(formattedKids);
                const initialStudent = formattedKids[0];
                setSelectedStudent(initialStudent);
                setChallengeLevel(initialStudent.challenge_level || 'standard');
                setTextbook(initialStudent.editorial_math || 'Santillana');
            }

            // 2. Fetch subjects (user_subjects)
            const { data: subjectsData, error: subjectsError } = await supabase.from('user_subjects')
                .select('*')
                .eq('user_id', authUser.id)
                .order('name');

            if (subjectsError || !subjectsData || subjectsData.length === 0) {
                // If no subjects, initialize based on first kid's level or default
                const level = kids?.[0]?.education_level || 'eso';
                await initializeSubjects(authUser.id, level);
            } else {
                setSubjects(subjectsData);
                setSelectedSubject(subjectsData[0]);
            }

        } catch (e) {
            console.error('Error in fetchData:', e);
        } finally {
            setLoading(false);
        }
    };



    // REMIX LOGIC: Auto-fill from URL params
    useEffect(() => {
        if (!loading && subjects.length > 0) {
            const params = new URLSearchParams(window.location.search);
            const remixData = params.get('remix');
            if (remixData) {
                try {
                    const parsed = JSON.parse(decodeURIComponent(remixData));
                    if (parsed.subject) {
                        const matched = subjects.find(s => s.name.toLowerCase() === parsed.subject.toLowerCase())
                            || subjects.find(s => s.name.toLowerCase().includes(parsed.subject.toLowerCase()));
                        if (matched) setSelectedSubject(matched);
                    }
                    if (parsed.topic) setTopic(parsed.topic);
                    if (parsed.type) {
                        if (parsed.type === 'ROADMAP') setMode('ROADMAP');
                        else setMode('WORKSHEET');
                    }
                    // Clean URL to prevent re-applying on refresh
                    window.history.replaceState({}, document.title, window.location.pathname);
                } catch (e) { console.error("Bad remix data", e); }
            }
        }
    }, [loading, subjects]);

    // NUEVO: Cargar insights del estudiante (VARK + Neurodiversidad)
    useEffect(() => {
        if (selectedStudent?.id) {
            fetchStudentInsights(selectedStudent.id);
        }
    }, [selectedStudent?.id]);

    const fetchStudentInsights = async (studentId) => {
        try {
            // 1. Fetch Learning Profile
            const { data: lp } = await supabase
                .from('learning_profiles')
                .select('*')
                .eq('student_id', studentId)
                .single();

            // 2. Fetch Latest Neurodiversity Screening
            const { data: nee } = await supabase
                .from('nee_screenings')
                .select('*')
                .eq('student_id', studentId)
                .order('created_at', { ascending: false })
                .limit(1)
                .single();

            setSelectedStudent(prev => ({
                ...prev,
                learning_profile: lp || null,
                nee_data: nee || null
            }));
        } catch (err) {
            console.log("No insights found for student yet:", studentId);
        }
    };

    const initializeSubjects = async (userId, level) => {
        let defaults = [];
        const normLevel = (level || '').toLowerCase();
        if (normLevel.includes('primaria')) defaults = ['Matemáticas', 'Lengua Castellana', 'Ciencias Naturales', 'Ciencias Sociales', 'Inglés'];
        else if (normLevel.includes('eso')) defaults = ['Matemáticas', 'Geografía e Historia', 'Lengua Castellana', 'Biología y Geología', 'Física y Química', 'Inglés', 'Tecnología'];
        else defaults = ['Matemáticas', 'Historia', 'Lengua Castellana', 'Inglés', 'Filosofía', 'Física', 'Química'];

        const toInsert = defaults.map(name => ({ user_id: userId, name, education_level: level, is_custom: false }));
        try {
            const { data, error } = await supabase.from('user_subjects').insert(toInsert).select();
            if (error) throw error;
            if (data && data.length > 0) {
                setSubjects(data);
                setSelectedSubject(data[0]);
            }
        } catch (e) { console.error("Init Error", e); }
    };

    const guessLevel = (val) => {
        if (!val) return 'primaria';
        const low = val.toLowerCase();
        if (low.includes('primaria')) return 'primaria';
        if (low.includes('eso')) return 'eso';
        if (low.includes('bachillerato')) return 'bachillerato';
        return 'primaria';
    };

    const handleAddSubject = async () => {
        if (!user) return alert("Debes iniciar sesión primero.");
        if (!newSubjectName.trim()) return;
        try {
            const level = selectedStudent?.education_level || guessLevel(selectedStudent?.grade_level);
            const { data, error } = await supabase.from('user_subjects').insert({
                user_id: user.id,
                name: newSubjectName.trim(),
                education_level: level,
                is_custom: true
            }).select().single();
            if (error) throw error;
            setSubjects(prev => [...prev, data]);
            setSelectedSubject(data); setNewSubjectName(''); setAddingSubject(false);
        } catch (error) { alert("Error al añadir asignatura: " + error.message); }
    };

    const handleDeleteSubject = async (e, subjectId) => {
        e.stopPropagation();
        if (!confirm("¿Borrar esta asignatura?")) return;
        try {
            const { error } = await supabase.from('user_subjects').delete().eq('id', subjectId);
            if (error) throw error;
            setSubjects(prev => prev.filter(s => s.id !== subjectId));
            if (selectedSubject?.id === subjectId) setSelectedSubject(null);
        } catch (err) {
            alert("Error al borrar: " + err.message);
        }
    };

    const handleUpdateTextbook = async () => {
        if (!user) return alert("Debes iniciar sesión.");
        if (!selectedSubject) return alert("Selecciona una asignatura primero.");
        try {
            const { error } = await supabase.from('user_subjects').update({ textbook_info: textbook }).eq('id', selectedSubject.id);
            if (error) throw error;
            const updated = { ...selectedSubject, textbook_info: textbook };
            setSubjects(prev => prev.map(s => s.id === selectedSubject.id ? updated : s));
            setSelectedSubject(updated);
            alert("Libro guardado correctamente ✅");
        } catch (e) { alert("Error guardando libro: " + e.message); }
    };

    const handleGenerate = async () => {
        if (!user) return alert("Inicia sesión.");
        if (!topic || !selectedSubject) return alert("Completa el tema y selecciona asignatura.");

        setGenerating(true);
        setGeneratedContent(null);

        try {
            console.log(`🧠 Generación inteligente: ${topic}`);

            // 🛡️ DEDUPLICACIÓN: Verificar banco local
            let excluded = [];
            try {
                const { data: dbQs } = await supabase
                    .from('question_bank_local')
                    .select('question_text')
                    .eq('topic', topic)
                    .ilike('subject', selectedSubject.name)
                    .limit(100);
                if (dbQs) excluded = dbQs.map(q => q.question_text);
                console.log(`🛡️ Deduplication: Found ${excluded.length} previous questions in DB.`);
            } catch (dberr) { console.warn("Dedupe check ignored:", dberr); }

            console.log(`📊 Estrategia: INTEF primero → AI fallback`);

            // Usar Smart Generator (Cache -> OER -> AI)
            const rawOutput = await generateSmartWorksheet({
                profile: selectedStudent || { grade_level: '4º Primaria' },
                subject: { ...selectedSubject, textbook_info: textbook },
                topic,
                activityType,
                config: {
                    difficulty,
                    questionTypes,
                    numQuestions,
                    challenge_level: challengeLevel,
                    interest: customerInterest // AÑADIDO: Interés personal
                },
                observations: "",
                excludedContent: excluded
            });

            let parsedContent = rawOutput;
            if (typeof rawOutput === 'string') {
                try {
                    const jsonStr = rawOutput.replace(/```json/g, '').replace(/```/g, '').trim();
                    parsedContent = JSON.parse(jsonStr);
                } catch (e) {
                    console.warn("Parse warning", e);
                }
            }

            setGeneratedContent(parsedContent);

            // 💾 AUTO-SAVE: Guardar en Banco de Preguntas Local
            if (parsedContent?.sections) {
                const newRows = [];
                parsedContent.sections.forEach(s => {
                    s.questions?.forEach(q => {
                        newRows.push({
                            topic: topic,
                            subject: selectedSubject.name,
                            grade_level: selectedStudent?.grade_level || 'General',
                            question_text: q.text,
                            question_type: q.type || 'short_answer',
                            options: q.options || [],
                            correct_answer: q.correct_answer || q.answer,
                            difficulty: difficulty.toLowerCase(),
                            source: 'AI_GENERATED',
                            metadata: { generated_at: new Date().toISOString() }
                        });
                    });
                });

                if (newRows.length > 0) {
                    supabase.from('question_bank_local').insert(newRows)
                        .then(({ error }) => {
                            if (error) console.error("❌ Auto-save failed:", error);
                            else console.log(`✅ Saved ${newRows.length} qs to question_bank_local.`);
                        });
                }
            }

            // Mostrar estadísticas de ahorro
            const stats = ContentSourceStats.getStats();
            console.log(`
                📊 ESTADÍSTICAS DE CONTENIDO:
                - Uso Cache: ${stats.cache_usage_percent}%
                - Uso INTEF: ${stats.intef_usage_percent}%
                - Uso AI: ${stats.ai_usage_percent}%
                - 💰 Ahorro total estimado: €${(stats.cost_saved * 0.9).toFixed(2)}
            `);

        } catch (error) {
            console.error(error);
            alert("Error generando ficha: " + error.message);
        } finally {
            setGenerating(false);
        }
    };

    const handleSaveWorksheet = async () => {
        if (!user) return alert("Inicia sesión.");
        if (!generatedContent || !selectedSubject) return;
        setSaving(true);
        try {
            // Determinar tipo de recurso para la Librería Unificada
            let type = 'WORKSHEET'; // Default
            if (activityType.toLowerCase().includes('examen')) type = 'EXAM';
            else if (activityType.toLowerCase().includes('aprender') || activityType.toLowerCase().includes('explicacion')) type = 'STUDY_GUIDE';

            // Guardar en la nueva Mochila Universal (resource_library)
            const { error } = await supabase.from('resource_library').insert({
                student_id: user.id,
                title: generatedContent.title || `${activityType} de ${topic}`,
                description: `Ficha generada para ${selectedSubject.name}. Dificultad: ${difficulty}`,
                resource_type: type,
                topic: topic,
                subject: selectedSubject.name,
                content: {
                    ...generatedContent,
                    config: { activityType, textbook, questionTypes, numQuestions },
                    difficulty_level: difficulty // Guardamos dificultad original
                },
                is_public: false,
                is_curated: false,
                user_engagement_score: 1
            });

            if (error) throw error;
            alert("¡Guardado en tu Mochila Universal! 🎒 Puedes verlo en el Hub.");
        } catch (error) {
            console.error(error);
            alert("Error al guardar: " + error.message);
        } finally {
            setSaving(false);
        }
    };

    const handleLocalCorrection = async (userAnswers, setCorrectionResult, timeSpent) => {
        // Preparar las preguntas para el servicio de evaluación
        const allQuestions = [];
        generatedContent.sections?.forEach(sec => {
            sec.questions?.forEach(q => {
                allQuestions.push({
                    ...q,
                    pregunta: q.text,
                    respuesta_correcta: q.correct_answer || q.respuesta,
                    dificultad: difficulty.toLowerCase()
                });
            });
        });

        // Realizar análisis avanzado
        const result = analizarFichaCompleta(allQuestions, userAnswers);

        // Simular retardo para feedback visual
        await new Promise(r => setTimeout(r, 800));

        // Adaptar resultado al formato esperado por InteractiveWorksheet
        const formattedResult = {
            score: result.puntuacion,
            total: result.totalPreguntas,
            summary: result.mensajeEstudiante,
            mensajePadres: result.mensajePadres,
            perfilCognitivo: result.perfilCognitivo,
            corrections: {}
        };

        // Mapear correcciones individuales
        result.analisisDetallado.forEach((item, index) => {
            const qId = allQuestions[index].id;
            formattedResult.corrections[qId] = {
                correct: item.correcta,
                feedback: item.feedbackExcelencia || item.feedback
            };
        });

        setCorrectionResult(formattedResult);

        // NUEVO: Guardar en base de datos para Analytics
        if (selectedStudent?.id) {
            const evaluationData = result.analisisDetallado.map((item, index) => ({
                questionId: allQuestions[index].id,
                criterio: allQuestions[index].criterio_evaluacion || 'General',
                competencias: allQuestions[index].competencias || [],
                isCorrect: item.correcta,
                studentAnswer: item.respuestaUsuario,
                correctAnswer: item.respuestaCorrecta,
                feedback: item.feedbackExcelencia || item.feedback,
                timeSeconds: timeSpent / allQuestions.length, // Tiempo estimado por pregunta
                tags: allQuestions[index].tags || null // Pasar TAGS reales
            }));

            // Usamos metadatos de la ficha
            const worksheetInfo = {
                subjectName: selectedSubject?.name,
                topic: topic,
                perfilCognitivoId: result.perfilCognitivo?.id
            };

            saveEvaluationResults(selectedStudent.id, worksheetInfo, evaluationData)
                .then(() => console.log("📊 Datos de evaluación guardados para Analytics"))
                .catch(err => console.error("❌ Error guardando analytics:", err));
        }
    };

    const toggleQuestionType = (typeId) => { setQuestionTypes(prev => prev.includes(typeId) ? prev.filter(t => t !== typeId) : [...prev, typeId]); };

    // Get available topics for selected subject
    const getAvailableTopics = () => {
        if (!selectedSubject) return [];

        // Import topic lists from khan-por-curso
        const KHAN_EXERCISES_POR_CURSO = {
            '4º Primaria': {
                'Matemáticas': ['Multiplicación', 'División', 'Sumas y Restas', 'Fracciones', 'Problemas', 'Propiedad Conmutativa', 'Propiedad Asociativa', 'Propiedad Distributiva', 'Números de 5 y 6 cifras', 'Números Decimales', 'Medidas de Longitud', 'Medidas de Tiempo', 'Ángulos'],
                'Lengua Castellana': ['Ortografía', 'Comprensión Lectora', 'Gramática', 'Palabras Agudas, Llanas y Esdrújulas', 'El Verbo - Tiempos Verbales', 'Sustantivos y Adjetivos', 'La Oración Simple', 'Tipos de Texto'],
                'Lingua Galega': ['Ortografía galega', 'Vocabulario galego', 'Comprensión Lectora en Galego', 'Gramática Galega', 'Ortografía da Lingua Galega', 'Vocabulario Galego Avanzado', 'Redacción e Expresión en Galego', 'Cultura Galega'],
                'Ciencias de la Naturaleza': ['Los Seres Vivos', 'El Cuerpo Humano', 'La Materia', 'Las Plantas', 'Los Animales Vertebrados', 'Los Animales Invertebrados', 'Los Ecosistemas', 'La Energía', 'Las Máquinas'],
                'Ciencias Naturales': ['El cuerpo humano: La relación', 'Los sentidos y el sistema nervioso', 'El aparato locomotor', 'La salud y la enfermedad', 'Los seres vivos: Las plantas', 'Los ecosistemas', 'La materia y las fuerzas', 'La energía', 'La luz y el calor', 'Las máquinas'],
                'Ciencias Sociales': ['Galicia', 'Mi Localidad', 'España: Relieve y Ríos', 'El Clima de España', 'La Población de España', 'Los Sectores Económicos', 'La Historia: Prehistoria y Edad Antigua', 'La Edad Media en España'],
                'Inglés': ['Numbers', 'Colors and Animals', 'Family and Greetings', 'Present Simple', 'Present Continuous', 'Past Simple (was/were)', 'Vocabulary: Daily Routines', 'Vocabulary: School Subjects', 'Vocabulary: Food and Drinks']
            }
        };

        const curso = selectedStudent?.grade_level || '4º Primaria';
        const asignatura = selectedSubject.name;

        return KHAN_EXERCISES_POR_CURSO[curso]?.[asignatura] || [];
    };



    const VITE_GEMINI_API_KEY = getEnv('VITE_GEMINI_API_KEY');
    const hasAIKey = localStorage.getItem('GEMINI_API_KEY') || localStorage.getItem('OPENROUTER_API_KEY') || VITE_GEMINI_API_KEY;

    if (loading) return <div className="min-h-screen flex items-center justify-center"><Loader2 className="animate-spin text-purple-600 w-8 h-8" /></div>;

    if (!user) return <div className="min-h-screen flex flex-col items-center justify-center p-4 text-center"><AlertCircle className="w-12 h-12 text-red-500 mb-4" /><h2 className="text-2xl font-bold text-gray-800 mb-2">Acceso Requerido</h2><AuthPage /></div>;

    return (
        <div className="min-h-screen bg-slate-50 font-sans pb-20">
            {/* Header Hero (Unified Style) */}
            <div className="bg-gradient-to-br from-indigo-700 via-blue-800 to-slate-900 text-white py-20 px-6 overflow-hidden relative">
                {/* Decorative Blobs */}
                <div className="absolute top-0 right-0 w-[500px] h-[500px] bg-blue-400/10 rounded-full blur-[100px] -mr-40 -mt-40 animate-pulse"></div>
                <div className="absolute bottom-0 left-0 w-[300px] h-[300px] bg-indigo-500/10 rounded-full blur-[80px] -ml-20 -mb-20"></div>

                <div className="max-w-6xl mx-auto relative z-10 text-center md:text-left">
                    <div className="inline-flex items-center gap-2 px-4 py-2 bg-white/10 backdrop-blur-md rounded-full border border-white/20 mb-8 animate-in fade-in slide-in-from-top-4 duration-500">
                        <Sparkles className="w-4 h-4 text-yellow-300" />
                        <span className="text-xs font-bold uppercase tracking-widest text-blue-100">Generador IA</span>
                    </div>

                    <div className="flex flex-col md:flex-row items-center gap-8 mb-8">
                        <div className="p-5 bg-white shadow-2xl shadow-indigo-500/20 rounded-3xl transform -rotate-3 hover:rotate-0 transition-transform duration-500">
                            <Wand2 className="w-10 h-10 text-indigo-600" />
                        </div>
                        <div>
                            <h1 className="text-5xl md:text-6xl font-extrabold tracking-tight mb-4">Estudio Inteligente</h1>
                            <p className="text-xl text-blue-100/80 max-w-2xl font-medium leading-relaxed">
                                Crea fichas de estudio personalizadas y planes de examen adaptados al perfil cognitivo de tu hijo/a.
                            </p>
                        </div>
                    </div>
                </div>
            </div>

            <div className="max-w-6xl mx-auto">
                {/* Header & Mode Switcher */}
                {/* Header: Title + Unified Controls */}
                <div className="max-w-6xl mx-auto px-6 -mt-10 mb-10 relative z-20 flex flex-col items-center gap-6">

                    {/* Unified Control Row: Students + Modes */}
                    <div className="bg-white p-2 rounded-[20px] shadow-lg border border-slate-100 flex flex-col md:flex-row items-center gap-2 md:gap-6">

                        {/* Student Selector Group */}
                        {students.length > 0 && (
                            <div className="flex items-center gap-2 p-1 bg-slate-50/50 rounded-xl">
                                {students.map(s => (
                                    <button
                                        key={s.id}
                                        onClick={() => {
                                            setSelectedStudent(s);
                                            setChallengeLevel(s.challenge_level || 'standard');
                                            setTextbook(s.editorial_math || 'Santillana');
                                        }}
                                        className={`px-5 py-2.5 rounded-xl text-xs font-black uppercase tracking-wider transition-all flex items-center gap-2 ${selectedStudent?.id === s.id ? 'bg-indigo-600 text-white shadow-md' : 'text-slate-400 hover:bg-white hover:shadow-sm'}`}
                                    >
                                        <User className="w-3 h-3" />
                                        {s.full_name?.split(' ')[0] || 'Estudiante'}
                                    </button>
                                ))}
                            </div>
                        )}

                        {/* Divider */}
                        <div className="hidden md:block w-px h-8 bg-slate-200"></div>

                        {/* Mode Switcher Group */}
                        <div className="flex items-center gap-2 p-1">
                            <button
                                onClick={() => setMode('WORKSHEET')}
                                className={`px-5 py-2.5 rounded-xl text-xs font-black uppercase tracking-wider transition-all flex items-center gap-2 ${mode === 'WORKSHEET' ? 'bg-indigo-600 text-white shadow-md' : 'text-slate-400 hover:bg-slate-50'}`}
                            >
                                <Wand2 className="w-3 h-3" />
                                Fichas
                            </button>
                            <button
                                onClick={() => setMode('ROADMAP')}
                                className={`px-5 py-2.5 rounded-xl text-xs font-black uppercase tracking-wider transition-all flex items-center gap-2 ${mode === 'ROADMAP' ? 'bg-purple-600 text-white shadow-md' : 'text-slate-400 hover:bg-slate-50'}`}
                            >
                                <Calendar className="w-3 h-3" />
                                Exámenes
                            </button>
                        </div>

                    </div>
                </div>

                {mode === 'ROADMAP' ? (
                    <div>
                        <ExamRoadmap key={selectedStudent?.id || 'no-student'} preSelectedStudent={selectedStudent} />
                    </div>
                ) : (
                    <div className="grid lg:grid-cols-12 gap-8">
                        {/* LEFT: Subject Selector */}
                        <div className="lg:col-span-4 space-y-6">


                            <div className="bg-white rounded-[40px] shadow-xl border border-gray-100 overflow-hidden">
                                <div className="p-4 bg-gradient-to-r from-blue-500 to-purple-500 flex justify-between items-center">
                                    <h2 className="font-bold text-white flex items-center gap-2"><Book className="w-5 h-5" /> Asignatura</h2>
                                    <button onClick={() => setAddingSubject(true)} className="p-1.5 rounded-full hover:bg-white/20 text-white"><Plus className="w-5 h-5" /></button>
                                </div>
                                {addingSubject && (
                                    <div className="p-3 bg-purple-50 flex gap-2">
                                        <input autoFocus type="text" value={newSubjectName} onChange={e => setNewSubjectName(e.target.value)} className="flex-1 p-2 text-sm border rounded-lg" placeholder="Nombre..." onKeyDown={e => e.key === 'Enter' && handleAddSubject()} />
                                        <button onClick={handleAddSubject} className="p-2 bg-purple-600 text-white rounded"><Check className="w-4 h-4" /></button>
                                    </div>
                                )}
                                <div className="p-2 max-h-[400px] overflow-y-auto">
                                    {subjects
                                        .filter(sub => sub.education_level === selectedStudent?.education_level || !selectedStudent)
                                        .map(sub => (
                                            <div key={sub.id} className={`group flex justify-between items-center p-3 rounded-xl cursor-pointer transition-all ${selectedSubject?.id === sub.id ? 'bg-blue-50 border-blue-200 border-2' : 'hover:bg-gray-50 border-2 border-transparent'}`}>
                                                <div onClick={() => setSelectedSubject(sub)} className="flex-1 flex justify-between items-center">
                                                    <span className={`font-medium ${selectedSubject?.id === sub.id ? 'text-blue-700' : 'text-gray-700'}`}>{sub.name}</span>
                                                    {selectedSubject?.id === sub.id && <Check className="w-5 h-5 text-blue-500 mr-2" />}
                                                </div>
                                                <button onClick={(e) => handleDeleteSubject(e, sub.id)} className="p-1.5 text-gray-400 hover:text-red-500 hover:bg-red-50 rounded-lg opacity-0 group-hover:opacity-100 transition-all">
                                                    <Trash2 className="w-4 h-4" />
                                                </button>
                                            </div>
                                        ))}
                                    {subjects.filter(sub => sub.education_level === selectedStudent?.education_level || !selectedStudent).length === 0 && (
                                        <div className="p-8 text-center">
                                            <Loader2 className="animate-spin w-6 h-6 mx-auto text-slate-300 mb-2" />
                                            <p className="text-slate-400 text-[10px] uppercase font-bold">Cargando asignaturas...</p>
                                        </div>
                                    )}
                                </div>
                            </div>

                            {/* Info Card: LOMLOE Guarantee */}
                            <div className="bg-white rounded-2xl shadow-sm border border-green-200 p-6">
                                <h3 className="font-bold text-green-800 mb-2 flex items-center gap-2">
                                    <span className="text-xl">⚖️</span>
                                    Garantía Curricular LOMLOE
                                </h3>
                                <p className="text-sm leading-relaxed text-slate-600">
                                    Todo el contenido generado se adapta rigurosamente a los <strong>Saberes Básicos</strong> y <strong>Criterios de Evaluación</strong> de la ley educativa vigente en España.
                                </p>
                            </div>
                        </div>

                        {/* RIGHT: Generator */}
                        <div className="lg:col-span-8 space-y-6">
                            <div className="bg-white rounded-2xl shadow-lg border border-gray-200 p-8">
                                <h2 className="font-bold text-gray-900 flex items-center gap-2 mb-6 text-xl"><Settings className="text-purple-600 w-6 h-6" /> Generar Ejercicios</h2>

                                <div className="space-y-6">
                                    {/* Topic Dropdown */}
                                    <div>
                                        <label className="block text-sm font-bold text-gray-700 mb-2">📖 Tema a Trabajar <span className="text-red-500">*</span></label>
                                        {selectedSubject ? (
                                            <select
                                                value={topic}
                                                onChange={e => setTopic(e.target.value)}
                                                className="w-full p-4 bg-gray-50 border border-gray-300 rounded-xl focus:ring-2 focus:ring-purple-500 focus:border-purple-500 text-lg font-medium cursor-pointer"
                                            >
                                                <option value="">-- Selecciona un tema --</option>
                                                {getAvailableTopics().map(t => (
                                                    <option key={t} value={t}>{t}</option>
                                                ))}
                                            </select>
                                        ) : (
                                            <div className="w-full p-4 bg-gray-100 border border-gray-300 rounded-xl text-gray-400 text-lg">
                                                Primero selecciona una asignatura
                                            </div>
                                        )}
                                    </div>

                                    {/* Personalización Deep (IA) */}
                                    <div className="space-y-6">
                                        {/* MODOS DE GENERACIÓN (4 Core Modes) */}
                                        <div>
                                            <label className="block text-sm font-bold text-gray-700 mb-3">📍 Objetivo de la Sesión</label>
                                            <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
                                                {[
                                                    { id: 'aprender', label: 'Aprender', icon: '🧠', desc: 'Teoría y Mapas Mentales' },
                                                    { id: 'practicar', label: 'Practicar', icon: '✏️', desc: 'Ejercicios con pistas' },
                                                    { id: 'examen', label: 'Examen', icon: '⏱️', desc: 'Simulacro sin ayuda' },
                                                    { id: 'proyecto', label: 'Proyecto', icon: '🚀', desc: 'Misión del mundo real' }
                                                ].map(mode => (
                                                    <button
                                                        key={mode.id}
                                                        onClick={() => setActivityType(mode.id)}
                                                        className={`p-3 rounded-xl border-2 transition-all text-left relative overflow-hidden group ${activityType === mode.id
                                                            ? 'border-purple-600 bg-purple-50 ring-2 ring-purple-200 ring-offset-1'
                                                            : 'border-slate-100 bg-white hover:border-slate-300 hover:shadow-md'
                                                            }`}
                                                    >
                                                        <div className="text-2xl mb-1 group-hover:scale-110 transition-transform">{mode.icon}</div>
                                                        <div className={`font-black text-sm uppercase ${activityType === mode.id ? 'text-purple-700' : 'text-slate-600'}`}>{mode.label}</div>
                                                        <div className="text-[10px] text-slate-400 leading-tight mt-1">{mode.desc}</div>
                                                    </button>
                                                ))}
                                            </div>
                                        </div>
                                        <div>
                                            <label className="block text-sm font-bold text-gray-700 mb-2">🌟 Intereses del Niño/a</label>
                                            <input
                                                type="text"
                                                value={customerInterest}
                                                onChange={e => setCustomerInterest(e.target.value)}
                                                placeholder="Minecraft, Fútbol, Espacio..."
                                                className="w-full p-3 bg-gray-50 border border-gray-200 rounded-xl focus:ring-2 focus:ring-purple-500 text-sm"
                                            />
                                        </div>
                                    </div>



                                    {/* Nivel de Reto (Sostenibilidad y Personalización) */}
                                    <div>
                                        <label className="block text-sm font-bold text-gray-700 mb-3">🚀 Nivel de Reto Educativo</label>
                                        <div className="grid grid-cols-3 gap-3">
                                            {[
                                                { id: 'refuerzo', label: 'Refuerzo', desc: 'Conceptos base', color: 'border-blue-200 bg-blue-50 text-blue-700' },
                                                { id: 'standard', label: 'Estándar', desc: 'Nivel oficial', color: 'border-slate-200 bg-slate-50 text-slate-700' },
                                                { id: 'ampliacion', label: 'Ampliación', desc: 'Reto avanzado', color: 'border-purple-200 bg-purple-50 text-purple-700' }
                                            ].map(lvl => (
                                                <button
                                                    key={lvl.id}
                                                    onClick={() => setChallengeLevel(lvl.id)}
                                                    className={`p-3 border-2 rounded-xl transition-all text-center ${challengeLevel === lvl.id ? lvl.color + ' ring-2 ring-offset-2 ring-indigo-500 scale-105 shadow-sm' : 'border-gray-100 bg-white text-gray-400 hover:bg-gray-50'}`}
                                                >
                                                    <div className="font-black text-xs uppercase mb-1">{lvl.label}</div>
                                                    <div className="text-[9px] opacity-70 leading-tight">{lvl.desc}</div>
                                                </button>
                                            ))}
                                        </div>
                                        <p className="text-[10px] text-gray-400 mt-2 italic">
                                            * El modo <b>Ampliación</b> usa criterios de evaluación por desempeño avanzados.
                                        </p>
                                    </div>

                                    {/* Num Questions */}
                                    <div>
                                        <label className="block text-sm font-bold text-gray-700 mb-2">🎯 Número de Ejercicios: <span className="text-purple-600 font-bold">{numQuestions}</span></label>
                                        <input
                                            type="range"
                                            min="5"
                                            max="10"
                                            step="5"
                                            value={numQuestions}
                                            onChange={e => setNumQuestions(parseInt(e.target.value))}
                                            className="w-full h-3 bg-gray-200 rounded-lg appearance-none cursor-pointer accent-purple-600"
                                        />
                                        <div className="flex justify-between text-xs text-gray-500 mt-1">
                                            <span>5</span>
                                            <span>10 (Max)</span>
                                        </div>
                                    </div>

                                    <button
                                        onClick={handleGenerate}
                                        disabled={generating || !topic || !selectedSubject}
                                        className="w-full py-4 bg-gradient-to-r from-purple-600 to-blue-600 text-white font-bold rounded-xl shadow-lg hover:shadow-xl hover:scale-[1.02] transition-all flex items-center justify-center gap-3 text-lg disabled:opacity-50 disabled:cursor-not-allowed"
                                    >
                                        <Wand2 className={`w-6 h-6 ${generating ? 'animate-spin' : 'animate-pulse'}`} />
                                        {generating ? 'Generando ejercicios...' : '✨ Generar Ficha'}
                                    </button>

                                    {selectedSubject && (
                                        <div className="p-4 bg-blue-50 border border-blue-200 rounded-xl">
                                            <p className="text-sm text-blue-800">
                                                <span className="font-bold">Asignatura seleccionada:</span> {selectedSubject.name}
                                            </p>
                                            <p className="text-xs text-blue-600 mt-1">
                                                💡 Los ejercicios se generarán específicamente para esta asignatura
                                            </p>
                                        </div>
                                    )}
                                </div>
                            </div>

                            {/* RESULT */}
                            {generatedContent && (
                                <div className="bg-white rounded-2xl shadow-lg border border-gray-200 p-8 animate-fade-in">
                                    {/* Source Badge */}
                                    {generatedContent.source === 'INTEF_OFFICIAL' && (
                                        <div className="mb-6 p-4 bg-green-50 border-2 border-green-200 rounded-xl flex items-center gap-3">
                                            <div className="flex-shrink-0 w-10 h-10 bg-green-500 rounded-full flex items-center justify-center">
                                                <span className="text-white text-xl">🇪🇸</span>
                                            </div>
                                            <div className="flex-1">
                                                <p className="font-bold text-green-800">Contenido Oficial INTEF</p>
                                                <p className="text-xs text-green-600">Recursos del Ministerio de Educación • Currículo LOMLOE</p>
                                            </div>
                                            <div className="text-xs bg-green-100 text-green-700 px-3 py-1 rounded-full font-medium">
                                                💰 Coste: €0
                                            </div>
                                        </div>
                                    )}
                                    {generatedContent.source !== 'INTEF_OFFICIAL' && (
                                        <div className="mb-6 p-4 bg-purple-50 border-2 border-purple-200 rounded-xl flex items-center gap-3">
                                            <div className="flex-shrink-0 w-10 h-10 bg-purple-500 rounded-full flex items-center justify-center">
                                                <Sparkles className="w-5 h-5 text-white" />
                                            </div>
                                            <div className="flex-1">
                                                <p className="font-bold text-purple-800">Generado con IA</p>
                                                <p className="text-xs text-purple-600">Contenido personalizado con AI • Basado en LOMLOE</p>
                                            </div>
                                        </div>
                                    )}

                                    <InteractiveWorksheet data={generatedContent} onCorrect={handleLocalCorrection} />
                                    <div className="mt-8 flex gap-4 border-t border-gray-200 pt-6">
                                        <button onClick={() => window.print()} className="flex items-center gap-2 px-6 py-3 border-2 border-gray-300 rounded-xl hover:bg-gray-50 font-medium transition-all">
                                            <Printer className="w-5 h-5" /> Imprimir
                                        </button>
                                        <button onClick={handleSaveWorksheet} disabled={saving} className="flex items-center gap-2 px-6 py-3 bg-green-600 text-white rounded-xl hover:bg-green-700 ml-auto font-medium transition-all disabled:opacity-50">
                                            {saving ? <Loader2 className='animate-spin w-5 h-5' /> : <Save className="w-5 h-5" />}
                                            {saving ? 'Guardando...' : '💾 Guardar en Biblioteca'}
                                        </button>
                                    </div>
                                </div>
                            )}
                        </div>
                    </div>
                )}
            </div>
        </div>
    );
};

export default WorksheetGenerator;
