// MEJORAS EN FEEDBACK PERSONALIZADO
// Extensión de taxonomia-errores-avanzada.js con personalización por estilo de aprendizaje

import {
    PATRONES_ERROR_TIER1,
    obtenerCriterioLOMLOE,
    ESTILOS_APRENDIZAJE,
    seleccionarRecurso
} from './taxonomia-errores-avanzada';

/**
 * Generar feedback PERSONALIZADO de excelencia vinculado a LOMLOE
 * Versión mejorada que incluye el estilo de aprendizaje del estudiante
 * 
 * @param {Object} analisisRespuesta - Análisis completo de la respuesta
 * @param {Object} perfil - Perfil del estudiante (incluye estiloAprendizaje)
 * @returns {string} - Feedback personalizado en markdown
 */
export function generarFeedbackPersonalizado(analisisRespuesta, perfil = {}) {
    const { patron, criterio, pregunta, respuestaUsuario, respuestaCorrecta, similitud } = analisisRespuesta;

    // Obtener estilo de aprendizaje (default: VISUAL)
    const estiloAprendizaje = perfil.estiloAprendizaje || 'VISUAL';
    const nombreEstudiante = perfil.nombre || 'alumno/a';

    const patronInfo = PATRONES_ERROR_TIER1[patron];
    const criterioInfo = criterio ? obtenerCriterioLOMLOE(criterio.asignatura, criterio.curso, criterio.codigo) : null;

    let feedback = '';

    // ENCABEZADO
    feedback += `${patronInfo.icono} **${patronInfo.nombre}**\\n\\n`;

    // 1. DIAGNÓSTICO DEL ERROR (Mejorado con similitud)
    if (patron === 'EC') {
        feedback += `Tu error no es de aplicación ni de procedimiento. El problema está en la comprensión del concepto fundamental.\\n\\n`;
    } else if (patron === 'EP') {
        feedback += `Tu error no es conceptual. Has identificado bien el concepto, pero el fallo está en el procedimiento o secuencia de pasos.\\n\\n`;
    } else if (patron === 'EAC') {
        feedback += `Tu error no es ni conceptual ni procedimental. El problema está en aplicar tu conocimiento a este contexto específico.\\n\\n`;
    } else if (patron === 'ETF') {
        if (similitud >= 0.95) {
            feedback += `¡Casi lo logras! Tu respuesta es casi perfecta. Es un error muy menor de transcripción o formato.\\n\\n`;
        } else {
            feedback += `Tu respuesta es fundamentalmente correcta, pero tiene un error menor de forma o presentación.\\n\\n`;
        }
    }

    // 2. COMPARACIÓN DE RESPUESTAS
    feedback += `**Tu respuesta:** \"${respuestaUsuario}\"\\n`;
    feedback += `**Respuesta correcta:** \"${respuestaCorrecta}\"\\n\\n`;

    // 3. CRITERIO LOMLOE AFECTADO
    if (criterioInfo) {
        feedback += `📋 **Criterio LOMLOE afectado:** ${criterioInfo.codigo}\\n`;
        feedback += `${criterioInfo.descripcion}\\n\\n`;
    }

    // 4. PLAN DE REFUERZO PERSONALIZADO (⭐ PREMIUM ⭐)
    feedback += `\\n🎯 **PLAN DE REFUERZO PERSONALIZADO** (Estilo ${estiloAprendizaje}):\\n\\n`;

    // Recurso pedagógico específico según patrón y estilo
    const recursoPersonalizado = seleccionarRecurso(patron, estiloAprendizaje, similitud || 0);
    feedback += `${recursoPersonalizado}\\n\\n`;

    // 5. PLAN DE ACCIÓN FÍSICO (Duración/Frecuencia)
    if (patronInfo.intervencion && patron !== 'ETF') {
        feedback += `⏰ **Compromiso recomendado:**\\n`;
        feedback += `• Duración de sesión: ${patronInfo.intervencion.duracion}\\n`;
        feedback += `• Frecuencia: ${patronInfo.intervencion.frecuencia}\\n`;

        const prioridadLabel = patronInfo.intervencion.prioridad === 1 ? '🚨 ALTA' :
            patronInfo.intervencion.prioridad === 2 ? '⚠️ MEDIA' :
                '✅ BAJA';
        feedback += `• Prioridad: ${prioridadLabel}\\n\\n`;
    }

    // 6. COMPETENCIAS VINCULADAS
    if (criterioInfo && criterioInfo.competencias) {
        feedback += `\\n🎯 **Competencias clave trabajadas:** ${criterioInfo.competencias.join(', ')}`;
    }

    return feedback;
}

/**
 * Obtener recomendaciones multidimensionales según perfil completo
 * Combina: Patrón + Estilo + Historial + Contexto
 */
export function generarRecomendacionesMultidimensionales(analisis, perfil, historial = []) {
    const recomendaciones = [];

    // 1. Recomendación principal según patrón y estilo
    const recurso = seleccionarRecurso(analisis.patron, perfil.estiloAprendizaje, analisis.similitud);
    recomendaciones.push({
        tipo: 'recurso_principal',
        titulo: 'Recurso Recomendado para Ti',
        descripcion: recurso,
        prioridad: 1
    });

    // 2. Si hay historial, añadir contexto
    if (historial.length > 0) {
        const patronesHistoricos = historial
            .filter(h => h.erroresPorPatron)
            .map(h => Object.keys(h.erroresPorPatron))
            .flat();

        const patronMasComun = patronesHistoricos
            .reduce((acc, p) => {
                acc[p] = (acc[p] || 0) + 1;
                return acc;
            }, {});

        const patronDominante = Object.entries(patronMasComun)
            .sort((a, b) => b[1] - a[1])[0]?.[0];

        if (patronDominante && patronDominante === analisis.patron) {
            recomendaciones.push({
                tipo: 'patrón_recurrente',
                titulo: 'Patrón Recurrente Detectado',
                descripcion: `Este es el ${patronMasComun[patronDominante]}º error de tipo ${PATRONES_ERROR_TIER1[patronDominante].nombre}. Es momento de hacer un refuerzo intensivo con tu profesor.`,
                prioridad: 1
            });
        }
    }

    // 3. Recomendación de método de estudio
    const metodoEstudio = {
        'VISUAL': 'Crea un mapa conceptual o diagrama del tema completo.',
        'AUDITIVO': 'Grábate explicando el concepto y escúchalo varias veces.',
        'KINESTESICO': 'Enseña el concepto a alguien más - es la mejor forma de aprender haciendo.'
    };

    recomendaciones.push({
        tipo: 'metodo_estudio',
        titulo: `Método de Estudio ${perfil.estiloAprendizaje}`,
        descripcion: metodoEstudio[perfil.estiloAprendizaje] || metodoEstudio.VISUAL,
        prioridad: 2
    });

    return recomendaciones.sort((a, b) => a.prioridad - b.prioridad);
}

export default {
    generarFeedbackPersonalizado,
    generarRecomendacionesMultidimensionales
};
