// TAXONOMÍA DE ERRORES DE ALTO NIVEL - TIER 1
// Sistema profesional de diagnóstico pedagógico vinculado a LOMLOE

/**
 * TIER 1: TAXONOMÍA DE ERRORES PEDAGÓGICOS
 * Clasificación de alto nivel según la naturaleza del fallo
 */
export const PATRONES_ERROR_TIER1 = {
    EC: {
        id: 'EC',
        nombre: 'Error Conceptual',
        descripcion: 'Falta de comprensión de la definición, principio o teoría fundamental',
        gravedad: 'CRÍTICA',
        color: '#EF4444', // rojo
        icono: '🧠',
        impacto: 'Alto - Requiere intervención inmediata',
        ejemplos: {
            matematicas: 'No sabe qué es un número primo o confunde área con perímetro',
            lengua: 'No diferencia entre sujeto y predicado',
            ciencias: 'Confunde fotosíntesis con respiración celular',
            sociales: 'No comprende la diferencia entre monarquía y república'
        },
        intervencion: {
            prioridad: 1,
            tipo: 'Refuerzo conceptual profundo',
            metodo: 'Explicación desde cero con ejemplos visuales y manipulativos',
            duracion: 'Sesiones largas (45-60 min)',
            frecuencia: 'Diaria hasta dominio'
        }
    },

    EP: {
        id: 'EP',
        nombre: 'Error Procedimental',
        descripcion: 'El concepto es correcto, pero hay fallo en la secuencia de pasos o algoritmo',
        gravedad: 'MEDIA',
        color: '#F59E0B', // naranja
        icono: '⚙️',
        impacto: 'Medio - Necesita práctica guiada',
        ejemplos: {
            matematicas: 'Usa la fórmula correcta pero se equivoca en la secuencia de operaciones',
            lengua: 'Conoce las reglas de acentuación pero falla al aplicar el orden',
            ciencias: 'Sabe el método científico pero lo aplica en orden incorrecto',
            sociales: 'Conoce los acontecimientos pero los ordena mal cronológicamente'
        },
        intervencion: {
            prioridad: 2,
            tipo: 'Práctica de procedimientos',
            metodo: 'Ejercicios paso a paso con supervisión, listas de verificación',
            duracion: 'Sesiones medias (30-45 min)',
            frecuencia: '3-4 veces por semana'
        }
    },

    EAC: {
        id: 'EAC',
        nombre: 'Error de Aplicación/Contexto',
        descripcion: 'Concepto y procedimiento correctos, pero no logra transferir a contexto nuevo',
        gravedad: 'MEDIA-BAJA',
        color: '#3B82F6', // azul
        icono: '🎯',
        impacto: 'Medio-Bajo - Necesita práctica contextual',
        ejemplos: {
            matematicas: 'Resuelve ecuaciones pero falla al aplicarlas a problemas de la vida real',
            lengua: 'Conoce el registro formal pero no lo usa correctamente en un ensayo',
            ciencias: 'Sabe la teoría pero no la aplica en experimentos prácticos',
            sociales: 'Conoce los hechos históricos pero no los relaciona con el presente'
        },
        intervencion: {
            prioridad: 3,
            tipo: 'Práctica contextualizada',
            metodo: 'Problemas de aplicación en diferentes contextos, casos prácticos',
            duracion: 'Sesiones cortas-medias (20-30 min)',
            frecuencia: '2-3 veces por semana'
        }
    },

    ETF: {
        id: 'ETF',
        nombre: 'Error Transversal/Forma',
        descripcion: 'Errores menores o formales que no afectan el núcleo de la competencia',
        gravedad: 'BAJA',
        color: '#10B981', // verde
        icono: '📝',
        impacto: 'Bajo - Mejoras formales',
        ejemplos: {
            matematicas: 'Error de cálculo aritmético simple, copia mal un número',
            lengua: 'Error ortográfico simple que no era el foco del ejercicio',
            ciencias: 'Nomenclatura incorrecta pero concepto correcto',
            sociales: 'Fecha equivocada pero contexto histórico correcto'
        },
        intervencion: {
            prioridad: 4,
            tipo: 'Atención a detalles',
            metodo: 'Revisión, checklists, autocorrección',
            duracion: 'Sesiones cortas (10-15 min)',
            frecuencia: 'Ocasional, cuando aparezca'
        }
    }
};

/**
 * TIER 2: CRITERIOS DE EVALUACIÓN LOMLOE
 * Estructura por asignatura y curso
 */
export const CRITERIOS_LOMLOE = {
    // MATEMÁTICAS
    'Matemáticas': {
        '4º Primaria': {
            'MAT_PRI4_C1.1': {
                codigo: 'MAT_PRI4_C1.1',
                descripcion: 'Resuelve problemas con operaciones básicas',
                competencias: ['STEM', 'CD'],
                saberes: ['Sentido numérico', 'Operaciones'],
                nivel_bloom: 'APLICAR'
            },
            'MAT_PRI4_C1.2': {
                codigo: 'MAT_PRI4_C1.2',
                descripcion: 'Comprende el concepto de fracción',
                competencias: ['STEM'],
                saberes: ['Sentido numérico', 'Fracciones'],
                nivel_bloom: 'COMPRENDER'
            },
            'MAT_PRI4_C2.1': {
                codigo: 'MAT_PRI4_C2.1',
                descripcion: 'Calcula área y perímetro de figuras básicas',
                competencias: ['STEM', 'CD'],
                saberes: ['Sentido espacial', 'Medida'],
                nivel_bloom: 'APLICAR'
            }
        },
        '5º Primaria': {
            'MAT_PRI5_C1.1': {
                codigo: 'MAT_PRI5_C1.1',
                descripcion: 'Opera con números decimales',
                competencias: ['STEM', 'CD'],
                saberes: ['Sentido numérico', 'Decimales'],
                nivel_bloom: 'APLICAR'
            },
            'MAT_PRI5_C1.2': {
                codigo: 'MAT_PRI5_C1.2',
                descripcion: 'Calcula porcentajes y aplica a situaciones reales',
                competencias: ['STEM', 'CPSAA'],
                saberes: ['Sentido numérico', 'Porcentajes'],
                nivel_bloom: 'APLICAR'
            },
            'MAT_PRI5_C2.1': {
                codigo: 'MAT_PRI5_C2.1',
                descripcion: 'Identifica múltiplos y divisores',
                competencias: ['STEM'],
                saberes: ['Sentido numérico', 'Divisibilidad'],
                nivel_bloom: 'RECORDAR'
            }
        },
        '1º ESO': {
            'MAT_ESO1_C1.1': {
                codigo: 'MAT_ESO1_C1.1',
                descripcion: 'Resuelve problemas con números enteros',
                competencias: ['STEM', 'CD'],
                saberes: ['Sentido numérico', 'Números enteros'],
                nivel_bloom: 'APLICAR'
            },
            'MAT_ESO1_C2.3': {
                codigo: 'MAT_ESO1_C2.3',
                descripcion: 'Modelización y resolución de problemas',
                competencias: ['STEM', 'CPSAA', 'CE'],
                saberes: ['Sentido algebraico', 'Resolución de problemas'],
                nivel_bloom: 'ANALIZAR'
            }
        }
    },

    // LENGUA CASTELLANA
    'Lengua Castellana y Literatura': {
        '4º Primaria': {
            'LCL_PRI4_C1.1': {
                codigo: 'LCL_PRI4_C1.1',
                descripcion: 'Comprende textos orales y escritos',
                competencias: ['CCL', 'CD'],
                saberes: ['Comunicación', 'Comprensión lectora'],
                nivel_bloom: 'COMPRENDER'
            },
            'LCL_PRI4_C2.1': {
                codigo: 'LCL_PRI4_C2.1',
                descripcion: 'Aplica reglas de ortografía',
                competencias: ['CCL'],
                saberes: ['Reflexión sobre la lengua', 'Ortografía'],
                nivel_bloom: 'APLICAR'
            },
            'LCL_PRI4_C3.1': {
                codigo: 'LCL_PRI4_C3.1',
                descripcion: 'Identifica sujeto y predicado',
                competencias: ['CCL'],
                saberes: ['Reflexión sobre la lengua', 'Sintaxis'],
                nivel_bloom: 'RECORDAR'
            }
        },
        '5º Primaria': {
            'LCL_PRI5_C1.1': {
                codigo: 'LCL_PRI5_C1.1',
                descripcion: 'Comprende textos complejos',
                competencias: ['CCL', 'CD', 'CPSAA'],
                saberes: ['Comunicación', 'Comprensión lectora'],
                nivel_bloom: 'ANALIZAR'
            },
            'LCL_PRI5_C2.1': {
                codigo: 'LCL_PRI5_C2.1',
                descripcion: 'Aplica reglas de acentuación',
                competencias: ['CCL'],
                saberes: ['Reflexión sobre la lengua', 'Acentuación'],
                nivel_bloom: 'APLICAR'
            },
            'LCL_PRI5_C3.1': {
                codigo: 'LCL_PRI5_C3.1',
                descripcion: 'Analiza la estructura oracional',
                competencias: ['CCL'],
                saberes: ['Reflexión sobre la lengua', 'Sintaxis'],
                nivel_bloom: 'ANALIZAR'
            }
        }
    },

    // CIENCIAS SOCIALES
    'Ciencias Sociales': {
        '4º Primaria': {
            'CS_PRI4_C1.1': {
                codigo: 'CS_PRI4_C1.1',
                descripcion: 'Identifica climas de España',
                competencias: ['CC', 'STEM'],
                saberes: ['Geografía física', 'Clima'],
                nivel_bloom: 'RECORDAR'
            },
            'CS_PRI4_C2.1': {
                codigo: 'CS_PRI4_C2.1',
                descripcion: 'Relaciona clima con actividades económicas',
                competencias: ['CC', 'STEM', 'CE'],
                saberes: ['Geografía humana', 'Economía'],
                nivel_bloom: 'ANALIZAR'
            }
        },
        '5º Primaria': {
            'CS_PRI5_C1.1': {
                codigo: 'CS_PRI5_C1.1',
                descripcion: 'Comprende la Edad Moderna en España',
                competencias: ['CC', 'CCEC'],
                saberes: ['Historia de España', 'Edad Moderna'],
                nivel_bloom: 'COMPRENDER'
            },
            'CS_PRI5_C2.1': {
                codigo: 'CS_PRI5_C2.1',
                descripcion: 'Analiza causas y consecuencias históricas',
                competencias: ['CC', 'CPSAA'],
                saberes: ['Pensamiento histórico'],
                nivel_bloom: 'ANALIZAR'
            }
        }
    },

    // CIENCIAS DE LA NATURALEZA
    'Ciencias de la Naturaleza': {
        '4º Primaria': {
            'CN_PRI4_C1.1': {
                codigo: 'CN_PRI4_C1.1',
                descripcion: 'Identifica seres vivos y sus características',
                competencias: ['STEM', 'CD'],
                saberes: ['Seres vivos', 'Clasificación'],
                nivel_bloom: 'RECORDAR'
            },
            'CN_PRI4_C2.1': {
                codigo: 'CN_PRI4_C2.1',
                descripcion: 'Comprende la fotosíntesis',
                competencias: ['STEM'],
                saberes: ['Funciones vitales', 'Nutrición'],
                nivel_bloom: 'COMPRENDER'
            }
        },
        '5º Primaria': {
            'CN_PRI5_C1.1': {
                codigo: 'CN_PRI5_C1.1',
                descripcion: 'Comprende los 5 reinos de seres vivos',
                competencias: ['STEM', 'CD'],
                saberes: ['Biodiversidad', 'Clasificación'],
                nivel_bloom: 'COMPRENDER'
            },
            'CN_PRI5_C2.1': {
                codigo: 'CN_PRI5_C2.1',
                descripcion: 'Explica el ciclo de la materia',
                competencias: ['STEM', 'CPSAA'],
                saberes: ['Materia y energía'],
                nivel_bloom: 'COMPRENDER'
            }
        }
    }
};

/**
 * Obtener criterio LOMLOE específico
 */
export function obtenerCriterioLOMLOE(asignatura, curso, codigoCriterio) {
    try {
        return CRITERIOS_LOMLOE[asignatura]?.[curso]?.[codigoCriterio] || null;
    } catch (error) {
        console.warn(`Criterio LOMLOE no encontrado: ${asignatura} - ${curso} - ${codigoCriterio}`);
        return null;
    }
}

/**
 * Inferir criterio LOMLOE desde el tema de la pregunta
 */
export function inferirCriterioDesdePregunta(pregunta, asignatura, curso) {
    // Mapeo simple basado en palabras clave
    const texto = pregunta.pregunta?.toLowerCase() || '';

    // Matemáticas
    if (asignatura === 'Matemáticas') {
        if (curso === '4º Primaria') {
            if (texto.includes('área') || texto.includes('perímetro')) return 'MAT_PRI4_C2.1';
            if (texto.includes('fracción') || texto.includes('fraccion')) return 'MAT_PRI4_C1.2';
            return 'MAT_PRI4_C1.1'; // Default
        }
        if (curso === '5º Primaria') {
            if (texto.includes('decimal')) return 'MAT_PRI5_C1.1';
            if (texto.includes('porcentaje') || texto.includes('%')) return 'MAT_PRI5_C1.2';
            if (texto.includes('múltiplo') || texto.includes('divisor')) return 'MAT_PRI5_C2.1';
        }
    }

    // Lengua
    if (asignatura.includes('Lengua')) {
        if (curso === '4º Primaria') {
            if (texto.includes('sujeto') || texto.includes('predicado')) return 'LCL_PRI4_C3.1';
            if (texto.includes('ortografía') || texto.includes('escribe')) return 'LCL_PRI4_C2.1';
            return 'LCL_PRI4_C1.1';
        }
        if (curso === '5º Primaria') {
            if (texto.includes('acent') || texto.includes('tilde')) return 'LCL_PRI5_C2.1';
            if (texto.includes('oración') || texto.includes('sintaxis')) return 'LCL_PRI5_C3.1';
            return 'LCL_PRI5_C1.1';
        }
    }

    // Ciencias Sociales
    if (asignatura === 'Ciencias Sociales') {
        if (curso === '4º Primaria') {
            if (texto.includes('clima')) return 'CS_PRI4_C1.1';
            return 'CS_PRI4_C2.1';
        }
        if (curso === '5º Primaria') {
            if (texto.includes('edad moderna') || texto.includes('historia')) return 'CS_PRI5_C1.1';
            return 'CS_PRI5_C2.1';
        }
    }

    // Ciencias Naturales
    if (asignatura === 'Ciencias de la Naturaleza' || asignatura.includes('Ciencias Naturales')) {
        if (curso === '4º Primaria') {
            if (texto.includes('seres vivos') || texto.includes('animales') || texto.includes('plantas')) return 'CN_PRI4_C1.1';
            if (texto.includes('fotosíntesis')) return 'CN_PRI4_C2.1';
        }
        if (curso === '5º Primaria') {
            if (texto.includes('reino')) return 'CN_PRI5_C1.1';
            if (texto.includes('materia') || texto.includes('energía')) return 'CN_PRI5_C2.1';
        }
    }

    return null; // No se pudo inferir
}

/**
 * FUNCIONES AUXILIARES MEJORADAS PARA DETECCIÓN DE PATRONES
 */

/**
 * Calcula la similitud entre la respuesta del usuario y la respuesta correcta.
 * Usa diferentes estrategias según el tipo de dato (numérico vs textual).
 * @param {string} resUsuario - Respuesta del alumno.
 * @param {string} resCorrecta - Respuesta esperada.
 * @returns {number} Un valor entre 0 y 1 (donde 1 es idéntico).
 */
export function calcularSimilitud(resUsuario, resCorrecta) {
    if (!resUsuario || !resCorrecta) return 0;

    // 1. Normalizar: Convertir a minúsculas y quitar signos de puntuación
    const normUsuario = resUsuario.toLowerCase().replace(/[.,\/#!$%\^&\*;:{}=\-_`~()¿?¡!]/g, "").trim();
    const normCorrecta = resCorrecta.toLowerCase().replace(/[.,\/#!$%\^&\*;:{}=\-_`~()¿?¡!]/g, "").trim();

    // 2. Si la respuesta es numérica, usar similitud porcentual
    if (!isNaN(parseFloat(normUsuario)) && !isNaN(parseFloat(normCorrecta))) {
        const numUsuario = parseFloat(normUsuario);
        const numCorrecta = parseFloat(normCorrecta);

        // Similitud porcentual: 1 - (diferencia absoluta / valor correcto)
        if (numCorrecta === 0) return numUsuario === 0 ? 1 : 0;

        const diferenciaRelativa = Math.abs(numUsuario - numCorrecta) / Math.abs(numCorrecta);
        return Math.max(0, 1 - diferenciaRelativa);
    }

    // 3. Para texto, usar Coeficiente de Jaccard simplificado
    const palabrasUsuario = normUsuario.split(/\s+/).filter(p => p.length > 0);
    const palabrasCorrecta = normCorrecta.split(/\s+/).filter(p => p.length > 0);

    if (palabrasUsuario.length === 0 || palabrasCorrecta.length === 0) return 0;

    // Calcular intersección (palabras comunes)
    const setUsuario = new Set(palabrasUsuario);
    const setCorrecta = new Set(palabrasCorrecta);

    let interseccion = 0;
    setUsuario.forEach(palabra => {
        if (setCorrecta.has(palabra)) {
            interseccion++;
        }
    });

    // Coeficiente de Jaccard: intersección / unión
    const union = setUsuario.size + setCorrecta.size - interseccion;
    return interseccion / union;
}

/**
 * Comprueba si la respuesta del usuario coincide con el tipo de dato esperado.
 * @param {string} resUsuario - Respuesta del alumno.
 * @param {string} resCorrecta - Respuesta esperada (para inferir el tipo).
 * @returns {boolean} True si los tipos de dato coinciden (ej. ambos son números).
 */
export function mismoTipoDato(resUsuario, resCorrecta) {
    if (!resUsuario || !resCorrecta) return false;

    const isNumCorrecta = !isNaN(parseFloat(resCorrecta)) && isFinite(parseFloat(resCorrecta));
    const isNumUsuario = !isNaN(parseFloat(resUsuario)) && isFinite(parseFloat(resUsuario));

    // Caso 1: Se espera un número (Cálculo)
    if (isNumCorrecta) {
        // Si el usuario da un número, el tipo coincide (probable EP o ETF)
        return isNumUsuario;
    }

    // Caso 2: Se espera texto (Definición, Concepto)
    if (!isNumCorrecta) {
        // Si ambos son texto, el tipo coincide
        return !isNumUsuario;
    }

    return false;
}

/**
 * Detectar patrón de error (TIER 1) mediante análisis MEJORADO de la respuesta
 */
export function detectarPatronError(pregunta, respuestaUsuario, respuestaCorrecta, contexto = {}) {
    const texto = (respuestaUsuario || '').toLowerCase().trim();
    const correcta = (respuestaCorrecta || '').toLowerCase().trim();

    // Sin respuesta = Error de atención/forma
    if (!texto) {
        return {
            patron: 'ETF',
            confianza: 1.0,
            razon: 'No respondió'
        };
    }

    // --- PASO 1: Calcular métricas auxiliares ---
    const similitud = calcularSimilitud(respuestaUsuario, respuestaCorrecta);
    const mismoTipo = mismoTipoDato(respuestaUsuario, respuestaCorrecta);

    // --- NUEVAS HEURÍSTICAS DE ALTA CONFIANZA ---

    // HEURÍSTICA MEJORADA 1: Error de Forma (ETF)
    // Si la similitud es muy alta (>= 0.85), es probablemente un ETF
    if (similitud >= 0.85) {
        return {
            patron: 'ETF',
            confianza: 0.90,
            razon: 'Respuesta casi correcta, error menor de forma',
            similitud: similitud
        };
    }

    // HEURÍSTICA MEJORADA 2: Error Procedimental (EP) en Cálculos
    // Si la pregunta requiere CÁLCULO Y el usuario dio el TIPO DE DATO CORRECTO (número),
    // pero la respuesta es incorrecta y no es un ETF, es muy probable que haya fallado un paso (EP)
    if (
        (pregunta.nivelBloom === 'APLICAR' ||
            pregunta.tipo === 'calculo' ||
            pregunta.pregunta?.includes('calcula') ||
            pregunta.pregunta?.includes('resuelve')) &&
        mismoTipo === true
    ) {
        return {
            patron: 'EP',
            confianza: 0.85,
            razon: 'Tipo de dato correcto pero valor incorrecto - Error en procedimiento',
            similitud: similitud
        };
    }

    // --- HEURÍSTICAS ANTERIORES (COMO FALLBACK) ---

    // HEURÍSTICA 3: Error Conceptual (EC) en Definiciones
    if (
        pregunta.tipo === 'definition' ||
        pregunta.pregunta?.includes('qué es') ||
        pregunta.pregunta?.includes('define') ||
        pregunta.nivelBloom === 'RECORDAR' ||
        pregunta.nivelBloom === 'COMPRENDER'
    ) {
        // Si falló y no fue un EP o ETF claro, se asume EC en preguntas de definición
        return {
            patron: 'EC',
            confianza: 0.80,
            razon: 'Fallo en pregunta de definición o concepto fundamental',
            similitud: similitud
        };
    }

    // HEURÍSTICA 4: Error de Aplicación/Contexto (EAC)
    if (
        pregunta.tipo === 'problema' ||
        pregunta.pregunta?.includes('problema') ||
        pregunta.pregunta?.includes('situación') ||
        pregunta.nivelBloom === 'ANALIZAR'
    ) {
        if (similitud > 0.3 && similitud < 0.7) {
            return {
                patron: 'EAC',
                confianza: 0.75,
                razon: 'Dificultad para aplicar conocimiento al contexto',
                similitud: similitud
            };
        }
    }

    // HEURÍSTICA 5: EC si similitud es muy baja
    if (similitud < 0.3) {
        return {
            patron: 'EC',
            confianza: 0.70,
            razon: 'Respuesta muy alejada de lo esperado - Posible falta de comprensión conceptual',
            similitud: similitud
        };
    }

    // Por defecto, asumir el error menos severo si la confianza es baja
    return {
        patron: 'ETF',
        confianza: 0.60,
        razon: 'Patrón de error no claro, asumiendo error menor',
        similitud: similitud
    };
}

/**
 * Función auxiliar de compatibilidad (deprecated - usar calcularSimilitud)
 */
function calcularSimilitudTexto(texto1, texto2) {
    return calcularSimilitud(texto1, texto2);
}

/**
 * ESTILOS DE APRENDIZAJE
 * Clasificación según modelo VAK (Visual, Auditivo, Kinestésico)
 */
export const ESTILOS_APRENDIZAJE = {
    VISUAL: {
        id: 'VISUAL',
        nombre: 'Visual',
        descripcion: 'Aprende mejor viendo información: diagramas, gráficos, vídeos, esquemas',
        icono: '👁️',
        preferencias: ['Diagramas', 'Vídeos', 'Infografías', 'Mapas mentales', 'Gráficos']
    },
    AUDITIVO: {
        id: 'AUDITIVO',
        nombre: 'Auditivo',
        descripcion: 'Aprende mejor escuchando: explicaciones verbales, audio, podcasts',
        icono: '👂',
        preferencias: ['Explicaciones verbales', 'Podcasts', 'Audios', 'Discusiones', 'Narración']
    },
    KINESTESICO: {
        id: 'KINESTESICO',
        nombre: 'Kinestésico',
        descripcion: 'Aprende mejor haciendo: práctica activa, manipulación, experimentos',
        icono: '✋',
        preferencias: ['Práctica activa', 'Experimentos', 'Simulaciones', 'Ejercicios interactivos', 'Casos prácticos']
    }
};

/**
 * Seleccionar recurso pedagógico según patrón de error y estilo de aprendizaje
 * Esta es la función PREMIUM que personaliza el feedback
 */
export function seleccionarRecurso(patron, estilo = 'VISUAL', similitud = 0) {
    let recomendacion = "";
    const estiloInfo = ESTILOS_APRENDIZAJE[estilo] || ESTILOS_APRENDIZAJE.VISUAL;

    if (patron === 'EC') {
        // Refuerzo Conceptual - Necesita comprensión profunda
        if (estilo === 'VISUAL') {
            recomendacion = `${estiloInfo.icono} **Enfoque Visual:** Te recomendamos ver el vídeo explicativo del tema con diagramas y ejemplos visuales. Crea tu propio mapa conceptual dibujando las relaciones entre las ideas principales.`;
        } else if (estilo === 'AUDITIVO') {
            recomendacion = `${estiloInfo.icono} **Enfoque Auditivo:** Escucha la explicación en audio del concepto mientras sigues el texto. Explícale el concepto a otra persona en voz alta - enseñar es la mejor forma de aprender.`;
        } else if (estilo === 'KINESTESICO') {
            recomendacion = `${estiloInfo.icono} **Enfoque Kinestésico:** Usa tarjetas de memoria (flashcards) físicas y organízalas por categorías. Crea modelos o representaciones físicas del concepto si es posible.`;
        }

    } else if (patron === 'EP') {
        // Refuerzo Procedimental - Necesita práctica de pasos
        if (estilo === 'VISUAL') {
            recomendacion = `${estiloInfo.icono} **Enfoque Visual:** Revisa el vídeo tutorial paso a paso del procedimiento. Crea un diagrama de flujo visual de los pasos que debes seguir y tenlo visible mientras practicas.`;
        } else if (estilo === 'AUDITIVO') {
            recomendacion = `${estiloInfo.icono} **Enfoque Auditivo:** Escucha las instrucciones narradas de cada paso. Repite en voz alta cada paso mientras lo realizas para reforzar la secuencia correcta.`;
        } else if (estilo === 'KINESTESICO') {
            recomendacion = `${estiloInfo.icono} **Enfoque Kinestésico:** Realiza ejercicios prácticos paso a paso con nuestra herramienta interactiva. Practica el procedimiento 5 veces seguidas para automatizar los pasos.`;
        }

    } else if (patron === 'EAC') {
        // Error de Aplicación/Contexto - Necesita casos prácticos
        if (estilo === 'VISUAL') {
            recomendacion = `${estiloInfo.icono} **Enfoque Visual:** Observa ejemplos resueltos de problemas similares en diferentes contextos. Compara visualmente las diferencias entre cada contexto.`;
        } else if (estilo === 'AUDITIVO') {
            recomendacion = `${estiloInfo.icono} **Enfoque Auditivo:** Escucha varios ejemplos de cómo aplicar este conocimiento en diferentes situaciones. Discute con alguien cuándo usar cada estrategia.`;
        } else if (estilo === 'KINESTESICO') {
            recomendacion = `${estiloInfo.icono} **Enfoque Kinestésico:** Resuelve 10 problemas de aplicación en contextos diferentes. La variedad de práctica es clave para dominar la transferencia del conocimiento.`;
        }

    } else if (patron === 'ETF') {
        // Error de Forma - Solo necesita atención
        if (similitud >= 0.95) {
            recomendacion = `${estiloInfo.icono} ¡Casi perfecto! Solo necesitas revisar con más calma antes de enviar. Tu comprensión es excelente.`;
        } else {
            recomendacion = `${estiloInfo.icono} Tu enfoque es correcto. Revisa los detalles de formato y presentación con una checklist de verificación.`;
        }
    }

    return recomendacion;
}

/**
 * Generar feedback de excelencia vinculado a LOMLOE Y PERSONALIZADO por estilo de aprendizaje
 */
export function generarFeedbackExcelencia(analisisRespuesta, perfil = {}) {
    const { patron, criterio, pregunta, respuestaUsuario, respuestaCorrecta } = analisisRespuesta;

    const patronInfo = PATRONES_ERROR_TIER1[patron];
    const criterioInfo = criterio ? obtenerCriterioLOMLOE(criterio.asignatura, criterio.curso, criterio.codigo) : null;

    let feedback = '';

    // Encabezado según patrón
    feedback += `${patronInfo.icono} **${patronInfo.nombre}**\n\n`;

    // Análisis específico
    if (patron === 'EC') {
        feedback += `Tu error no es de aplicación ni de procedimiento. El problema está en la comprensión del concepto fundamental.\n\n`;
        feedback += `**Tu respuesta:** "${respuestaUsuario}"\n`;
        feedback += `**Respuesta correcta:** "${respuestaCorrecta}"\n\n`;

        if (criterioInfo) {
            feedback += `**Criterio LOMLOE afectado:** ${criterioInfo.codigo} - ${criterioInfo.descripcion}\n\n`;
            feedback += `📚 **Plan de acción:**\n`;
            feedback += `1. Revisa la definición básica de este concepto con tu profesor o padre/madre\n`;
            feedback += `2. Practica con ejemplos visuales y concretos\n`;
            feedback += `3. No avances hasta dominar completamente el concepto\n`;
        }

    } else if (patron === 'EP') {
        feedback += `Tu error no es conceptual. Has identificado bien el concepto, pero el fallo está en el procedimiento o secuencia de pasos.\n\n`;
        feedback += `**Tu respuesta:** "${respuestaUsuario}"\n`;
        feedback += `**Respuesta correcta:** "${respuestaCorrecta}"\n\n`;

        if (criterioInfo) {
            feedback += `**Criterio LOMLOE afectado:** ${criterioInfo.codigo} - ${criterioInfo.descripcion}\n\n`;
            feedback += `⚙️ **Plan de acción:**\n`;
            feedback += `1. Revisa los pasos del procedimiento uno por uno\n`;
            feedback += `2. Usa una lista de verificación (checklist)\n`;
            feedback += `3. Practica con ejercicios similares supervisados\n`;
        }

    } else if (patron === 'EAC') {
        feedback += `Tu error no es ni conceptual ni procedimental. El problema está en aplicar tu conocimiento a este contexto específico.\n\n`;
        feedback += `**Tu respuesta:** "${respuestaUsuario}"\n`;
        feedback += `**Respuesta correcta:** "${respuestaCorrecta}"\n\n`;

        if (criterioInfo) {
            feedback += `**Criterio LOMLOE afectado:** ${criterioInfo.codigo} - ${criterioInfo.descripcion}\n\n`;
            feedback += `🎯 **Plan de acción:**\n`;
            feedback += `1. Practica con problemas de aplicación en diferentes contextos\n`;
            feedback += `2. Identifica qué conceptos usar en cada situación\n`;
            feedback += `3. Trabaja con casos prácticos de la vida real\n`;
        }

    } else if (patron === 'ETF') {
        feedback += `Tu respuesta es fundamentalmente correcta, pero tiene un error menor de forma o presentación.\n\n`;
        feedback += `**Tu respuesta:** "${respuestaUsuario}"\n`;
        feedback += `**Respuesta exacta:** "${respuestaCorrecta}"\n\n`;
        feedback += `📝 **Consejo:** Revisa tu trabajo con calma antes de entregarlo.\n`;
    }

    // Competencias vinculadas
    if (criterioInfo && criterioInfo.competencias) {
        feedback += `\n🎯 **Competencias clave:** ${criterioInfo.competencias.join(', ')}`;
    }

    return feedback;
}


export default {
    PATRONES_ERROR_TIER1,
    CRITERIOS_LOMLOE,
    ESTILOS_APRENDIZAJE,
    obtenerCriterioLOMLOE,
    inferirCriterioDesdePregunta,
    detectarPatronError,
    generarFeedbackExcelencia,
    calcularSimilitud,
    mismoTipoDato,
    seleccionarRecurso
};
